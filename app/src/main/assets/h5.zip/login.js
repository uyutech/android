/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 102);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(3);

/***/ }),

/***/ 102:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(80);

__webpack_require__(73);

var _Login = __webpack_require__(52);

var _Login2 = _interopRequireDefault(_Login);

var _Other = __webpack_require__(53);

var _Other2 = _interopRequireDefault(_Other);

var _animaQuerystring = __webpack_require__(0);

var _animaQuerystring2 = _interopRequireDefault(_animaQuerystring);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var search = _animaQuerystring2.default.parse(location.search.replace(/^\?/, ''));
var goto = search.goto;

jsBridge.ready(function () {
  jsBridge.on('back', function (e) {
    e.preventDefault();
    jsBridge.moveTaskToBack();
  });

  var con = migi.render(migi.createVd("div", [["class", "con"]], [migi.createVd("div", [["class", "niang"]], [migi.createVd("div", [["class", "bg"]], []), migi.createVd("div", [["class", "tip fn-hide"]], [])]), migi.createCp(_Login2.default, [["ref", "login"], ["goto", goto]])]), document.body);
  var login = con.find(_Login2.default);
  var $bg = $(con.element).find('.bg');
  var $tip = $(con.element).find('.tip');
  login.on('change', function () {
    $bg.toggleClass('alt');
    $tip.addClass('fn-hide');
    $tip.html('');
  });
  login.on('tip', function (ok, mes) {
    if (ok) {
      $tip.addClass('fn-hide');
      $tip.html('');
    } else {
      $tip.removeClass('fn-hide');
      $tip.html(mes);
    }
  });
  requestAnimationFrame(function () {
    $bg.addClass('alt');
  });

  migi.render(migi.createCp(_Other2.default, [["goto", goto]]), document.body);
});

/***/ }),

/***/ 3:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// QueryString
// ---------------
// This module provides utilities for dealing with query strings.
//
// Thanks to:
//  - http://nodejs.org/docs/v0.4.7/api/querystring.html
//  - http://developer.yahoo.com/yui/3/api/QueryString.html
//  - https://github.com/lifesinger/dew/tree/master/lib/querystring


// var QueryString = exports;

var QueryString = {};

// The escape/unescape function used by stringify/parse, provided so that it
// could be overridden if necessary. This is important in cases where
// non-standard delimiters are used, if the delimiters would not normally be
// handled properly by the built-in (en|de)codeURIComponent functions.
QueryString.escape = encodeURIComponent;

QueryString.unescape = function (s) {
    // The + character is interpreted as a space on the server side as well as
    // generated by forms with spaces in their fields.
    return decodeURIComponent(s.replace(/\+/g, ' '));
};

/**
 * Serialize an object to a query string. Optionally override the default
 * separator and assignment characters.
 *
 * stringify({foo: 'bar'})
 *   // returns 'foo=bar'
 *
 * stringify({foo: 'bar', baz: 'bob'}, ';', ':')
 *   // returns 'foo:bar;baz:bob'
 */
QueryString.stringify = function (obj, sep, eq, arrayKey) {
    if (!isPlainObject(obj)) return '';

    sep = sep || '&';
    eq = eq || '=';
    arrayKey = arrayKey || false;

    var buf = [],
        key,
        val;
    var escape = QueryString.escape;

    for (key in obj) {
        if (!hasOwnProperty.call(obj, key)) continue;

        val = obj[key];
        key = QueryString.escape(key);

        // val is primitive value
        if (isPrimitive(val)) {
            buf.push(key, eq, escape(val + ''), sep);
        }
        // val is not empty array
        else if (isArray(val) && val.length) {
                for (var i = 0; i < val.length; i++) {
                    if (isPrimitive(val[i])) {
                        buf.push(key, (arrayKey ? escape('[]') : '') + eq, escape(val[i] + ''), sep);
                    }
                }
            }
            // ignore other cases, including empty array, Function, RegExp, Date etc.
            else {
                    buf.push(key, eq, sep);
                }
    }

    buf.pop();
    return buf.join('');
};

/**
 * Deserialize a query string to an object. Optionally override the default
 * separator and assignment characters.
 *
 * parse('a=b&c=d')
 *   // returns {a: 'b', c: 'c'}
 */
QueryString.parse = function (str, sep, eq) {
    var ret = {};

    if (typeof str !== 'string' || trim(str).length === 0) {
        return ret;
    }

    var pairs = str.split(sep || '&');
    eq = eq || '=';
    var unescape = QueryString.unescape;

    for (var i = 0; i < pairs.length; i++) {

        var pair = pairs[i].split(eq);
        var key = unescape(trim(pair[0]));
        var val = unescape(trim(pair.slice(1).join(eq)));

        var m = key.match(/^(\w+)\[\]$/);
        if (m && m[1]) {
            key = m[1];
        }

        if (hasOwnProperty.call(ret, key)) {
            if (!isArray(ret[key])) {
                ret[key] = [ret[key]];
            }
            ret[key].push(val);
        } else {
            ret[key] = m ? [val] : val;
        }
    }

    return ret;
};

// Helpers

var toString = Object.prototype.toString;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var isArray = Array.isArray || function (val) {
    return toString.call(val) === '[object Array]';
};
var trim = String.prototype.trim ? function (str) {
    return str == null ? '' : String.prototype.trim.call(str);
} : function (str) {
    return str == null ? '' : str.toString().replace(/^\s+/, '').replace(/\s+$/, '');
};

/**
 * Checks to see if an object is a plain object (created using "{}" or
 * "new Object()" or "new FunctionClass()").
 */
function isPlainObject(o) {
    /**
     * NOTES:
     * isPlainObject(node = document.getElementById("xx")) -> false
     * toString.call(node):
     *   ie678 === '[object Object]', other === '[object HTMLElement]'
     * 'isPrototypeOf' in node:
     *   ie678 === false, other === true
     */
    return o && toString.call(o) === '[object Object]' && 'isPrototypeOf' in o;
}

/**
 * If the type of o is null, undefined, number, string, boolean,
 * return true.
 */
function isPrimitive(o) {
    return o !== Object(o);
}

module.exports = QueryString;

/***/ }),

/***/ 52:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var timeout = void 0;
var sendDelay = 0;

var Login = function (_migi$Component) {
  _inherits(Login, _migi$Component);

  function Login() {
    var _ref;

    _classCallCheck(this, Login);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Login.__proto__ || Object.getPrototypeOf(Login)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Login, [{
    key: 'click',
    value: function click(e, vd, tvd) {
      var $li = $(tvd.element);
      if (!$li.hasClass('cur')) {
        var $ul = $li.parent();
        $ul.find('.cur').removeClass('cur');
        $li.addClass('cur');
        var rel = tvd.props.rel;
        if (rel == 0) {
          $(this.ref.reg.element).addClass('fn-hide');
          $(this.ref.lgn.element).removeClass('fn-hide');
        } else {
          $(this.ref.lgn.element).addClass('fn-hide');
          $(this.ref.reg.element).removeClass('fn-hide');
        }
        this.emit('change', rel);
      }
    }
  }, {
    key: 'clear',
    value: function clear(e, vd) {
      var $vd = $(vd.element);
      if (!$vd.hasClass('fn-hidden')) {
        var $input = $vd.parent().find('input');
        $input.val('');
      }
    }
  }, {
    key: 'eye',
    value: function eye(e, vd) {
      var $eye = $(vd.element);
      var $input = $eye.parent().find('input');
      if ($eye.hasClass('alt')) {
        $input.attr('type', 'password');
      } else {
        $input.attr('type', 'text');
      }
      $eye.toggleClass('alt');
    }
  }, {
    key: 'keyDown',
    value: function keyDown(e) {
      var keyCode = e.keyCode;
      if (keyCode == 8 || keyCode == 9 || keyCode == 46 || keyCode >= 48 && keyCode <= 57 || keyCode >= 96 && keyCode <= 105) {
        // console.log('in');
      } else {
        // console.log('out');
        e.preventDefault();
      }
    }
  }, {
    key: 'inputName',
    value: function inputName(e, vd) {
      var $input = $(vd.element);
      var s = $input.val();
      if (s.length > 11) {
        $input.val(s.slice(0, 11));
      }
      var $clear = $input.parent().find('.clear');
      if (s.length) {
        $clear.removeClass('fn-hidden');
      } else {
        $clear.addClass('fn-hidden');
      }
      if (vd.props.ref == 'name') {
        this.checkLoginButton();
      } else {
        this.checkRegisterButton();
      }
    }
  }, {
    key: 'inputPass',
    value: function inputPass(e, vd) {
      var $input = $(vd.element);
      var s = $input.val();
      var $clear = $input.parent().find('.clear');
      if (s.length) {
        $clear.removeClass('fn-hidden');
      } else {
        $clear.addClass('fn-hidden');
      }
      if (vd.props.ref == 'pass') {
        this.checkLoginButton();
      } else {
        this.checkRegisterButton();
      }
    }
  }, {
    key: 'inputValid',
    value: function inputValid(e, vd) {
      var $input = $(vd.element);
      var s = $input.val();
      if (s.length > 6) {
        $input.val(s.slice(0, 6));
      }
      this.checkRegisterButton();
    }
  }, {
    key: 'checkLoginButton',
    value: function checkLoginButton() {
      var self = this;
      self.clearDelayShow();
      var userNameText = $(self.ref.name.element).val();
      var userPassText = $(self.ref.pass.element).val();
      var valid = true;
      // 空则提示需要用户名
      if (userNameText == '') {
        timeout = setTimeout(function () {
          self.emit('tip', false, '请输入<span>用户名</span>');
        }, 500);
        valid = false;
      } else if (!/^1[356789]\d{9}$/.test(userNameText)) {
        timeout = setTimeout(function () {
          self.emit('tip', false, '<span>用户名</span>格式不正确哟');
        }, 500);
        valid = false;
      }
      // 用户名如果正确合法，则判断密码输入状态
      if (valid) {
        // 空则提示需要密码
        if (userPassText == '') {
          timeout = setTimeout(function () {
            self.emit('tip', false, '请输入<span>密码</span>');
          }, 500);
          valid = false;
        } else if (userPassText.length < 8) {
          timeout = setTimeout(function () {
            self.emit('tip', false, '密码至少<span>8</span>位哟');
          }, 500);
          valid = false;
        }
      }
      // 设置按钮禁用状态
      var $loginButton = $(this.ref.loginButton.element);
      if (valid) {
        $loginButton.removeClass('dis');
        self.emit('tip', true);
      } else {
        $loginButton.addClass('dis');
      }
    }
  }, {
    key: 'checkRegisterButton',
    value: function checkRegisterButton() {
      var self = this;
      self.clearDelayShow();
      var userNameText = $(self.ref.name2.element).val();
      var userPassText = $(self.ref.pass2.element).val();
      var valid = true;
      // 空则提示需要用户名
      if (userNameText == '') {
        timeout = setTimeout(function () {
          self.emit('tip', false, '请输入<span>用户名</span>');
        }, 500);
        valid = false;
      } else if (!/^1[356789]\d{9}$/.test(userNameText)) {
        timeout = setTimeout(function () {
          self.emit('tip', false, '<span>用户名</span>格式不正确哟');
        }, 500);
        valid = false;
      }
      // 用户名如果正确合法，则判断密码输入状态
      if (valid) {
        // 空则提示需要密码
        if (userPassText == '') {
          timeout = setTimeout(function () {
            self.emit('tip', false, '请输入<span>密码</span>');
          }, 500);
          valid = false;
        } else if (userPassText.length < 8) {
          timeout = setTimeout(function () {
            self.emit('tip', false, '密码至少<span>8</span>位哟');
          }, 500);
          valid = false;
        }
      }
      // 密码也正确，放开发送验证码按钮
      var $sendValid = $(this.ref.sendValid.element);
      if (valid) {
        // 可能上次发送没结束，判断是否倒计时到0秒
        if (sendDelay == 0) {
          $sendValid.removeClass('dis');
        } else {
          $sendValid.addClass('dis');
        }
      } else {
        $sendValid.addClass('dis');
      }
      // 判断输入验证码里的内容
      var $valid = $(this.ref.valid.element);
      if (valid) {
        // 是否可用
        if ($valid.hasClass('dis')) {
          timeout = setTimeout(function () {
            self.emit('tip', false, '请先发送<span>验证码</span>');
          }, 500);
          valid = false;
        } else {
          var userValidText = $(self.ref.valid.element).val();
          if (userValidText == '') {
            timeout = setTimeout(function () {
              self.emit('tip', false, '请输入<span>验证码</span>');
            }, 500);
            valid = false;
          } else if (userValidText.length != 6) {
            timeout = setTimeout(function () {
              self.emit('tip', false, '验证码是<span>6</span>位哟');
            }, 500);
            valid = false;
          }
        }
      }
      // 设置按钮禁用状态
      var $registerButton = $(this.ref.registerButton.element);
      if (valid) {
        $registerButton.removeClass('dis');
        self.emit('tip', true);
      } else {
        $registerButton.addClass('dis');
      }
    }
  }, {
    key: 'clearDelayShow',
    value: function clearDelayShow() {
      if (timeout) {
        clearTimeout(timeout);
      }
    }
  }, {
    key: 'clickLogin',
    value: function clickLogin(e, vd) {
      var self = this;
      var $button = $(vd.element);
      if (!$button.hasClass('dis')) {
        var User_Phone = $(self.ref.name.element).val();
        var User_Pwd = $(self.ref.pass.element).val();
        jsBridge.showLoading('登录中...');
        util.postJSON('api/Users/Login', { User_Phone: User_Phone, User_Pwd: User_Pwd }, function (res) {
          jsBridge.hideLoading();
          if (res.success) {
            var sessionid = res.data.sessionid;
            jsBridge.setPreference('sessionid', sessionid, function () {
              var regStat = res.data.User_Reg_Stat;
              if (regStat >= 4) {
                var goto = self.props.goto;
                if (goto) {
                  location.replace(goto);
                  return;
                }
                location.replace('index.html');
              } else {
                var AuthorName = res.data.AuthorName;
                location.replace('guide.html?step=' + regStat + '&authorName=' + encodeURIComponent(AuthorName));
              }
            });
          } else {
            jsBridge.toast(res.message || util.ERROR_MESSAGE);
          }
        }, function () {
          jsBridge.hideLoading();
          jsBridge.toast(util.ERROR_MESSAGE);
        });
      }
    }
  }, {
    key: 'clickSend',
    value: function clickSend(e, vd) {
      var $sendValid = $(vd.element);
      if ($sendValid.hasClass('dis')) {
        return;
      }
      $sendValid.addClass('dis');
      var $validGroup = $(this.ref.validGroup.element);
      $validGroup.removeClass('dis');
      var $valid = $(this.ref.valid.element);
      $valid.removeAttr('readOnly');
      $valid.removeClass('dis');
      sendDelay = 60;
      $sendValid.text(sendDelay + '秒后刷新');
      this.checkRegisterButton();
      var self = this;
      var interval = setInterval(function () {
        sendDelay--;
        if (sendDelay == 0) {
          $sendValid.text('重新发送');
          $sendValid.removeClass('dis');
          clearInterval(interval);
          self.checkRegisterButton();
        } else {
          $sendValid.text(sendDelay + '秒后刷新');
        }
      }, 1000);
      var User_Phone = $(this.ref.name2.element).val();
      util.postJSON('api/Users/SendCode', { User_Phone: User_Phone, SendSource: 'Regist' }, function (res) {
        if (res.success) {
          jsBridge.toast('发送成功');
        } else {
          jsBridge.toast(res.message || util.ERROR_MESSAGE);
        }
      }, function () {
        jsBridge.toast(util.ERROR_MESSAGE);
      });
    }
  }, {
    key: 'clickRegister',
    value: function clickRegister(e, vd) {
      var self = this;
      var $button = $(vd.element);
      if (!$button.hasClass('dis')) {
        jsBridge.showLoading();
        var User_Phone = $(self.ref.name2.element).val();
        var User_Pwd = $(self.ref.pass2.element).val();
        var YZMCode = $(self.ref.valid.element).val();
        util.postJSON('api/Users/Regist', { User_Phone: User_Phone, User_Pwd: User_Pwd, YZMCode: YZMCode }, function (res) {
          jsBridge.hideLoading();
          if (res.success) {
            var sessionid = res.data.sessionid;
            jsBridge.setPreference('sessionid', sessionid, function () {
              var regStat = res.data.User_Reg_Stat;
              if (regStat >= 4) {
                var goto = self.props.goto;
                if (goto) {
                  location.replace(goto);
                  return;
                }
                location.replace('index.html');
              } else {
                var AuthorName = res.data.AuthorName;
                location.replace('guide.html?step=' + regStat + '&authorName=' + encodeURIComponent(AuthorName));
              }
            });
          } else {
            jsBridge.toast(res.message || util.ERROR_MESSAGE);
          }
        }, function () {
          jsBridge.hideLoading();
          jsBridge.toast(util.ERROR_MESSAGE);
        });
      }
    }
  }, {
    key: 'clickForget',
    value: function clickForget(e) {
      e.preventDefault();
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "login_forget"]], [migi.createVd("div", [["ref", "login_panel"]], [migi.createVd("ul", [["class", "tab"], ["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.click)]]]], [migi.createVd("li", [["class", "cur"], ["rel", "0"]], ["登录"]), migi.createVd("li", [["rel", "1"]], ["注册"])]), migi.createVd("div", [["class", "lgn fn-hide1"], ["ref", "lgn"]], [migi.createVd("div", [["class", "line phone"]], [migi.createVd("b", [["class", "icon"]]), migi.createVd("input", [["type", "number"], ["ref", "name"], ["maxlength", "11"], ["placeholder", "请输入手机号"], ["onKeyDown", new migi.Cb(this, this.keyDown)], ["onInput", new migi.Cb(this, this.inputName)], ["value", "15921858411"]]), migi.createVd("b", [["class", "clear fn-hidden"], ["onClick", new migi.Cb(this, this.clear)]])]), migi.createVd("div", [["class", "line pass"]], [migi.createVd("b", [["class", "icon"]]), migi.createVd("input", [["type", "password"], ["ref", "pass"], ["maxlength", "16"], ["placeholder", "请输入密码"], ["onInput", new migi.Cb(this, this.inputPass)], ["value", "aaaaaaa"]]), migi.createVd("b", [["class", "clear fn-hidden"], ["onClick", new migi.Cb(this, this.clear)]]), migi.createVd("b", [["class", "eye"], ["onClick", new migi.Cb(this, this.eye)]])]), migi.createVd("div", [["class", "forget"]], [migi.createVd("a", [["href", "#"], ["onClick", new migi.Cb(this, this.clickForget)]], ["忘记密码"])]), migi.createVd("button", [["class", "ok dis"], ["ref", "loginButton"], ["onClick", new migi.Cb(this, this.clickLogin)]], ["登录"])]), migi.createVd("div", [["class", "reg fn-hide"], ["ref", "reg"]], [migi.createVd("div", [["class", "line phone"]], [migi.createVd("b", [["class", "icon"]]), migi.createVd("input", [["type", "number"], ["ref", "name2"], ["maxlength", "11"], ["placeholder", "请输入手机号"], ["onKeyDown", new migi.Cb(this, this.keyDown)], ["onInput", new migi.Cb(this, this.inputName)]]), migi.createVd("b", [["class", "clear fn-hidden"], ["onClick", new migi.Cb(this, this.clear)]])]), migi.createVd("div", [["class", "line pass"]], [migi.createVd("b", [["class", "icon"]]), migi.createVd("input", [["type", "password"], ["ref", "pass2"], ["maxlength", "16"], ["placeholder", "请输入密码"], ["onInput", new migi.Cb(this, this.inputPass)]]), migi.createVd("b", [["class", "clear fn-hidden"], ["onClick", new migi.Cb(this, this.clear)]]), migi.createVd("b", [["class", "eye"], ["onClick", new migi.Cb(this, this.eye)]])]), migi.createVd("div", [["class", "line2"]], [migi.createVd("div", [["class", "valid dis"], ["ref", "validGroup"]], [migi.createVd("b", [["class", "icon"]]), migi.createVd("input", [["type", "number"], ["class", "dis"], ["ref", "valid"], ["maxlength", "6"], ["placeholder", "请输入验证码"], ["readOnly", "readOnly"], ["onInput", new migi.Cb(this, this.inputValid)]])]), migi.createVd("button", [["class", "send dis"], ["ref", "sendValid"], ["onClick", new migi.Cb(this, this.clickSend)]], ["发送验证码"])]), migi.createVd("button", [["class", "ok dis"], ["ref", "registerButton"], ["onClick", new migi.Cb(this, this.clickRegister)]], ["注册"])])]), migi.createVd("div", [["class", "forget_panel fn-hide"]], [])]);
    }
  }]);

  return Login;
}(migi.Component);

migi.name(Login, "Login");exports.default = Login;

/***/ }),

/***/ 53:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Other = function (_migi$Component) {
  _inherits(Other, _migi$Component);

  function Other() {
    var _ref;

    _classCallCheck(this, Other);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Other.__proto__ || Object.getPrototypeOf(Other)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Other, [{
    key: 'weibo',
    value: function weibo() {
      var self = this;
      jsBridge.showLoading('打开微博中...');
      jsBridge.loginWeibo(function (res) {
        jsBridge.hideLoading();
        if (res.success) {
          jsBridge.showLoading('登录中...');
          util.postJSON('api/Users/WeiboLogin', { mAccessTokenuid: res.openId, access_token: res.token }, function (res2) {
            jsBridge.hideLoading();
            if (res2.success) {
              var sessionid = res2.data.sessionid;
              jsBridge.setPreference('sessionid', sessionid, function () {
                var regStat = res2.data.User_Reg_Stat;
                if (regStat >= 4) {
                  var goto = self.props.goto;
                  if (goto) {
                    location.replace(goto);
                    return;
                  }
                  location.replace('index.html');
                } else {
                  var authorName = res2.data.AuthorName;
                  location.replace('guide.html?step=' + regStat + '&authorName=' + encodeURIComponent(authorName));
                }
              });
            } else {
              jsBridge.toast(res2.message || util.ERROR_MESSAGE);
            }
          }, function () {
            jsBridge.hideLoading();
            jsBridge.toast(util.ERROR_MESSAGE);
          });
        } else {
          jsBridge.toast(res.message);
        }
      });
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "other"]], [migi.createVd("h5", [], [migi.createVd("b", [], []), migi.createVd("span", [], ["其它账号登陆"]), migi.createVd("b", [], [])]), migi.createVd("ul", [], [migi.createVd("li", [], [migi.createVd("b", [["class", "weibo"], ["onClick", new migi.Cb(this, this.weibo)]], [])])])]);
    }
  }]);

  return Other;
}(migi.Component);

migi.name(Other, "Other");exports.default = Other;

/***/ }),

/***/ 73:
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ 80:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "login.html";

/***/ })

/******/ });