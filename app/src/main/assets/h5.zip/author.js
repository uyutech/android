/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 88);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(3);

/***/ }),

/***/ 10:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var NOT_LOADED = 0;
var IS_LOADING = 1;
var HAS_LOADED = 2;
var subLoadHash = {};
var subSkipHash = {};
var Take = 10;

var Comment = function (_migi$Component) {
  _inherits(Comment, _migi$Component);

  function Comment() {
    var _ref;

    _classCallCheck(this, Comment);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Comment.__proto__ || Object.getPrototypeOf(Comment)).call.apply(_ref, [this].concat(data)));

    var self = _this;
    self.on(migi.Event.DOM, function () {
      $(self.ref.list.element).on('click', '.more', function () {
        var $message = $(this);
        var rid = $message.attr('rid');
        $message.removeClass('more').text('读取中...');
        util.postJSON('api/author/GetTocomment_T_List', { RootID: rid, Skip: subSkipHash[rid], Take: Take }, function (res) {
          if (res.success) {
            var _data = res.data;
            if (_data.data.length) {
              subSkipHash[rid] = _data.data[_data.data.length - 1].Send_ID;
              var s = '';
              _data.data.forEach(function (item) {
                s += self.genChildComment(item);
              });
              var $ul = $message.prev();
              $ul.append(s);
              if (_data.data.length < Take) {
                $message.addClass('fn-hide');
              } else {
                $message.addClass('more').text('点击加载更多');
              }
            } else {
              $message.addClass('fn-hide');
            }
          } else {
            $message.addClass('more').text(res.message || util.ERROR_MESSAGE);
          }
        }, function (res) {
          $message.addClass('more').text(res.message || util.ERROR_MESSAGE);
        });
      });
    });
    return _this;
  }

  _createClass(Comment, [{
    key: 'switchType',
    value: function switchType(e, vd) {
      var $ul = $(vd.element);
      $ul.toggleClass('alt');
      $ul.find('li').toggleClass('cur');
    }
  }, {
    key: 'slide',
    value: function slide(e, vd, tvd) {
      var $slide = $(tvd.element);
      var $li = $slide.closest('li');
      var $list2 = $li.find('.list2');
      var $ul = $list2.find('ul');
      var $message = $list2.find('.message');
      var rid = tvd.props.rid;
      if ($slide.hasClass('on')) {
        $slide.removeClass('on');
        $list2.css('height', 0);
      } else {
        $slide.addClass('on');
        var state = subLoadHash[rid];
        if (state === HAS_LOADED || state === IS_LOADING) {
          $list2.css('height', 'auto');
        } else {
          $list2.css('height', 'auto');
          subLoadHash[rid] = IS_LOADING;
          util.postJSON('api/author/GetTocomment_T_List', { RootID: rid, Skip: -1, Take: Take }, function (res) {
            if (res.success) {
              subLoadHash[rid] = HAS_LOADED;
              var s = '';
              var data = res.data;
              data.data.forEach(function (item) {
                s += migi.createVd("li", [], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["cid", item.Send_ID], ["class", 'zan' + (item.IsLike ? ' has' : '')]], [migi.createVd("small", [], [item.LikeCount])])]), migi.createVd("div", [["class", "profile"], ["cid", item.Send_ID], ["rid", item.RootID], ["name", item.Send_UserName]], [migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name2"]], [item.Send_ToUserName]), migi.createVd("b", [["class", "arrow"]]), migi.createVd("small", [["class", "time"]], [item.Send_Time]), migi.createVd("span", [["class", "name"]], [item.Send_UserName])]), migi.createVd("p", [], [item.sign])]), migi.createVd("img", [["class", "pic"], ["src", item.Send_UserHeadUrl || 'src/common/blank.png']])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [["cid", item.Send_ID], ["rid", item.RootID], ["name", item.Send_UserName]], [item.Send_Content])])]);
              });
              $ul.html(s);
              if (data.data.length >= data.Size) {
                $message.addClass('fn-hide');
              } else {
                $message.addClass('more').text('点击加载更多');
                subSkipHash[rid] = data.data[data.data.length - 1].Send_ID;
              }
              $ul.removeClass('fn-hide');
              $list2.css('height', 'auto');
            } else {
              subLoadHash[rid] = NOT_LOADED;
              jsBridge.toast(res.message || util.ERROR_MESSAGE);
            }
          }, function (res) {
            subLoadHash[rid] = NOT_LOADED;
            jsBridge.toast(res.message || util.ERROR_MESSAGE);
          });
        }
      }
    }
  }, {
    key: 'clickZan',
    value: function clickZan(e, vd, tvd) {
      var $span = $(tvd.element);
      var CommentID = tvd.props.cid;
      util.postJSON('api/works/AddWorkCommentLike', { CommentID: CommentID }, function (res) {
        if (res.success) {
          var data = res.data;
          if (data.State === 211) {
            $span.addClass('has');
          } else {
            $span.removeClass('has');
          }
          $span.find('small').text(data.LikeCount);
        } else {
          jsBridge.toast(res.message || util.ERROR_MESSAGE);
        }
      });
    }
  }, {
    key: 'clickCmt',
    value: function clickCmt(e, vd, tvd) {
      this.emit('chooseSubComment', tvd.props.rid, tvd.props.cid, tvd.props.name);
    }
  }, {
    key: 'genComment',
    value: function genComment(item) {
      return migi.createVd("li", [["id", 'comment_' + item.Send_ID]], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "profile"], ["cid", item.Send_ID], ["rid", item.RootID], ["name", item.Send_UserName]], [migi.createVd("img", [["class", "pic"], ["src", item.Send_UserHeadUrl || 'src/common/blank.png']]), migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name"]], [item.Send_UserName]), migi.createVd("small", [["class", "time"]], [item.Send_Time])]), migi.createVd("p", [], [item.sign])])]), migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["cid", item.Send_ID], ["class", 'zan' + (item.IsLike ? ' has' : '')]], [migi.createVd("small", [], [item.LikeCount])])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [["cid", item.Send_ID], ["rid", item.RootID], ["name", item.Send_UserName]], [item.Send_Content, migi.createVd("span", [["class", "placeholder"]])]), migi.createVd("div", [["class", "slide"], ["cid", item.Send_ID], ["rid", item.RootID]], [migi.createVd("small", [], [item.sub_Count]), migi.createVd("span", [], ["收起"])])]), migi.createVd("div", [["class", "list2"]], [migi.createVd("ul", [["class", "fn-hide"]]), migi.createVd("p", [["class", "message"], ["cid", item.Send_ID], ["rid", item.Send_ID]], ["读取中..."])])]);
    }
  }, {
    key: 'addNew',
    value: function addNew(item) {
      if (this.list.length) {
        var li = this.genComment(item);
        li.prependTo(this.ref.list.element);
      } else {
        this.list.unshift(item);
        this.message = '';
      }
    }
  }, {
    key: 'addMore',
    value: function addMore(data) {
      var self = this;
      var s = '';
      data.forEach(function (item) {
        var li = self.genComment(item);
        s += li.toString();
      });
      $(self.ref.list.element).append(s);
    }
  }, {
    key: 'genChildComment',
    value: function genChildComment(item) {
      return migi.createVd("li", [], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["cid", item.Send_ID], ["class", 'zan' + (item.IsLike ? ' has' : '')]], [migi.createVd("small", [], [item.LikeCount])])]), migi.createVd("div", [["class", "profile"], ["cid", item.Send_ID], ["rid", item.RootID], ["name", item.Send_UserName]], [migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name2"]], [item.Send_ToUserName]), migi.createVd("b", [["class", "arrow"]]), migi.createVd("small", [["class", "time"]], [item.Send_Time]), migi.createVd("span", [["class", "name"]], [item.Send_UserName])]), migi.createVd("p", [], [item.sign])]), migi.createVd("img", [["class", "pic"], ["src", item.Send_UserHeadUrl || 'src/common/blank.png']])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [["cid", item.Send_ID], ["rid", item.RootID], ["name", item.Send_UserName]], [item.Send_Content])])]);
    }
  }, {
    key: 'addChild',
    value: function addChild(item) {
      var li = this.genChildComment(item);
      var $comment = $('#comment_' + item.RootID);
      var $list2 = $comment.find('.list2');
      var $ul = $list2.find('ul');
      li.prependTo($ul[0]);
      $list2.css('height', $ul.height());
      var $num = $comment.find('.slide small');
      $num.text((parseInt($num.text()) || 0) + 1);
    }
  }, {
    key: 'addMoreChild',
    value: function addMoreChild(item) {}
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "cp_comment"]], [migi.createVd("div", [["class", "bar fn-clear"]], [migi.createVd("ul", [["class", "type fn-clear"], ["onClick", new migi.Cb(this, this.switchType)]], [migi.createVd("li", [["class", "cur"]], [migi.createVd("span", [], ["最热"])]), migi.createVd("li", [], [migi.createVd("span", [], ["最新"])])])]), migi.createVd("ul", [["class", "list"], ["ref", "list"], ["onClick", [[{ ".slide": { "_v": true } }, new migi.Cb(this, this.slide)], [{ ".zan": { "_v": true } }, new migi.Cb(this, this.clickZan)], [{ "pre": { "_v": true } }, new migi.Cb(this, this.clickCmt)], [{ ".profile": { "_v": true } }, new migi.Cb(this, this.clickCmt)]]]], [new migi.Obj("list", this, function () {
        return (this.list || []).map(function (item) {
          return migi.createVd("li", [["id", 'comment_' + item.Send_ID]], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "profile"], ["cid", item.Send_ID], ["rid", item.Send_ID], ["name", item.Send_UserName]], [migi.createVd("img", [["class", "pic"], ["src", item.Send_UserHeadUrl || 'src/common/blank.png']]), migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name"]], [item.Send_UserName]), migi.createVd("small", [["class", "time"]], [item.Send_Time])]), migi.createVd("p", [], [item.sign])])]), migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["cid", item.Send_ID], ["class", 'zan' + (item.IsLike ? ' has' : '')]], [migi.createVd("small", [], [item.LikeCount])])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [["cid", item.Send_ID], ["rid", item.Send_ID], ["name", item.Send_UserName]], [item.Send_Content, migi.createVd("span", [["class", "placeholder"]])]), migi.createVd("div", [["class", "slide"], ["cid", item.Send_ID], ["rid", item.Send_ID]], [migi.createVd("small", [], [item.sub_Count]), migi.createVd("span", [], ["收起"])])]), migi.createVd("div", [["class", "list2"]], [migi.createVd("ul", [["class", "fn-hide"]]), migi.createVd("p", [["class", "message"], ["cid", item.Send_ID], ["rid", item.Send_ID]], ["读取中..."])])]);
        });
      })]), migi.createVd("p", [["class", new migi.Obj("message", this, function () {
        return 'message' + (this.message ? '' : ' fn-hide');
      })]], [new migi.Obj("message", this, function () {
        return this.message;
      })])]);
    }
  }, {
    key: 'list',
    set: function set(v) {
      this.__setBind("list", v);this.__data("list");
    },
    get: function get() {
      if (this.__initBind("list")) this.__setBind("list", []);return this.__getBind("list");
    }
  }, {
    key: 'message',
    set: function set(v) {
      this.__setBind("message", v);this.__data("message");
    },
    get: function get() {
      if (this.__initBind("message")) this.__setBind("message", '读取中...');return this.__getBind("message");
    }
  }]);

  return Comment;
}(migi.Component);

migi.name(Comment, "Comment");exports.default = Comment;

/***/ }),

/***/ 11:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dynamics = function (_migi$Component) {
  _inherits(Dynamics, _migi$Component);

  function Dynamics() {
    var _ref;

    _classCallCheck(this, Dynamics);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Dynamics.__proto__ || Object.getPrototypeOf(Dynamics)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Dynamics, [{
    key: "click",
    value: function click(e, vd, tvd) {
      var url = tvd.props.href;
      jsBridge.openUri(url);
    }
  }, {
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "cp_dynamic"]], [migi.createVd("ul", [["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.click)]]]], [new migi.Obj("list", this, function () {
        return this.list.map(function (item) {
          return migi.createVd("li", [["href", item.DynamicUrl]], [migi.createVd("div", [["class", "con"]], [migi.createVd("div", [["class", "user"]], [migi.createVd("div", [["class", "head fn-clear"]], [migi.createVd("img", [["src", item.AuthorHeadUrl]])]), migi.createVd("div", [["class", "name"]], [migi.createVd("p", [], [item.AuthorName]), migi.createVd("small", [], [item.SendTime])])]), migi.createVd("p", [["class", "info"]], [migi.createVd("b", [["class", "weibo"]]), item.DynamicContent])]), migi.createVd("div", [["class", "preview"]], [migi.createVd("img", [["src", item.DynamicPic]])])]);
          var info = void 0;
          var preview = void 0;
          if (item.type == 'song') {
            info = migi.createVd("p", [["class", "info"]], [migi.createVd("b", [["class", "zq"]]), item.action, migi.createVd("a", [["href", "#"]], [item.song])]);
            preview = migi.createVd("div", [["class", "preview"]], [migi.createVd("img", [["src", item.pic]])]);
          } else if (item.type == 'weibo') {
            info = migi.createVd("p", [["class", "info"]], [migi.createVd("b", [["class", "wb"]]), item.action, migi.createVd("a", [["href", "#"]], [item.txt])]);
          }
          return migi.createVd("li", [], [migi.createVd("div", [["class", "con"]], [migi.createVd("div", [["class", "user"]], [migi.createVd("div", [["class", "head n" + item.imgs.length + " fn-clear"]], [item.imgs.map(function (item2) {
            return migi.createVd("img", [["src", item2]]);
          })]), migi.createVd("div", [["class", "name"]], [migi.createVd("p", [], [item.names.join('、')]), migi.createVd("small", [], [item.time])])]), info]), preview]);
        });
      })])]);
    }
  }, {
    key: "list",
    set: function set(v) {
      this.__setBind("list", v);this.__data("list");
    },
    get: function get() {
      if (this.__initBind("list")) this.__setBind("list", []);return this.__getBind("list");
    }
  }]);

  return Dynamics;
}(migi.Component);

migi.name(Dynamics, "Dynamics");exports.default = Dynamics;

/***/ }),

/***/ 12:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var PlayList = function (_migi$Component) {
  _inherits(PlayList, _migi$Component);

  function PlayList() {
    var _ref;

    _classCallCheck(this, PlayList);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = PlayList.__proto__ || Object.getPrototypeOf(PlayList)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(PlayList, [{
    key: 'switchType',
    value: function switchType(e, vd) {
      var $ul = $(vd.element);
      $ul.toggleClass('alt');
      $ul.find('li').toggleClass('cur');
    }
  }, {
    key: 'click',
    value: function click(e, vd, tvd) {
      var id = tvd.props.workId;
      jsBridge.pushWindow('works.html?id=' + id, {
        transparentTitle: true,
        titleBgColor: '#99000000'
      });
    }
  }, {
    key: 'setData',
    value: function setData(data) {
      this.list = data.data || [];
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "cp_playlist"]], [migi.createVd("div", [["class", "bar"]], [migi.createVd("ul", [["class", "btn fn-clear"]], [migi.createVd("li", [["class", "all"]], ["播放全部"]), migi.createVd("li", [["class", "audio"]], []), migi.createVd("li", [["class", "video"]], [])]), migi.createVd("ul", [["class", "type fn-clear"], ["onClick", new migi.Cb(this, this.switchType)]], [migi.createVd("li", [["class", "cur"]], [migi.createVd("span", [], ["最热"])]), migi.createVd("li", [], [migi.createVd("span", [], ["最新"])])])]), migi.createVd("ul", [["class", "list"], ["onClick", [[{ ".pic": { "_v": true } }, new migi.Cb(this, this.click)], [{ ".txt": { "_v": true } }, new migi.Cb(this, this.click)]]]], [new migi.Obj("list", this, function () {
        return this.list.map(function (item) {
          return migi.createVd("li", [], [migi.createVd("div", [["workId", item.WorksID], ["class", "pic"], ["style", 'background:url(' + item.cover_Pic + ')']]), migi.createVd("div", [["class", "txt"], ["workId", item.WorksID]], [migi.createVd("div", [["class", "name"]], [item.Title]), migi.createVd("p", [["class", "intro"]], [item.sub_Title])])]
          // item.type.map(function(item2) {
          //   return <b class={ item2 }/>;
          // })

          );
        });
      })])]);
    }
  }, {
    key: 'list',
    set: function set(v) {
      this.__setBind("list", v);this.__data("list");
    },
    get: function get() {
      if (this.__initBind("list")) this.__setBind("list", []);return this.__getBind("list");
    }
  }]);

  return PlayList;
}(migi.Component);

migi.name(PlayList, "PlayList");exports.default = PlayList;

/***/ }),

/***/ 125:
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ 13:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var isStart = void 0;
var startX = void 0;

var HotAlbum = function (_migi$Component) {
  _inherits(HotAlbum, _migi$Component);

  function HotAlbum() {
    var _ref;

    _classCallCheck(this, HotAlbum);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = HotAlbum.__proto__ || Object.getPrototypeOf(HotAlbum)).call.apply(_ref, [this].concat(data)));

    _this.list2 = _this.props.list || [];
    return _this;
  }

  _createClass(HotAlbum, [{
    key: 'autoWidth',
    value: function autoWidth() {
      this.$root = $(this.element);
      this.list = this.ref.list.element;
      this.$list = $(this.list);
      var $c = this.$list.find('.c');
      $c.width('css', '9999rem');
      var $ul = $c.find('ul');
      $c.css('width', $ul.width() + 1);
    }
  }, {
    key: 'start',
    value: function start(e) {
      if (e.touches.length != 1) {
        isStart = false;
      } else {
        isStart = true;
        startX = e.touches[0].pageX;
        this.$list.addClass('no_trans');
        this.$list.removeAttr('style');
        jsBridge.swipeRefresh(false);
      }
    }
  }, {
    key: 'move',
    value: function move(e) {
      if (isStart) {
        var x = e.touches[0].pageX;
        if (x > startX) {
          var left = this.list.scrollLeft;
          if (left == 0) {
            e.preventDefault();
            var diff = x - startX;
            this.$list.css('transform', 'translate3d(' + diff + 'px,0,0)');
            this.$list.css('-webkit-transform', 'translate3d(' + diff + 'px,0,0)');
          }
        }
      }
    }
  }, {
    key: 'end',
    value: function end(e) {
      this.$list.removeClass('no_trans');
      this.$list.removeAttr('style');
      jsBridge.swipeRefresh(true);
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "hot_album"]], [migi.createVd("h3", [], [this.props.title]), migi.createVd("div", [["class", "list"], ["ref", "list"]], [migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [], [new migi.Obj("list2", this, function () {
        return this.list2.map(function (item) {
          if (item.type == 'audio') {
            return migi.createVd("li", [], [migi.createVd("div", [["class", "pic"]], [migi.createVd("div", [["class", "bg3"]]), migi.createVd("div", [["class", "bg2"]]), migi.createVd("div", [["class", "bg"]]), migi.createVd("div", [["class", "mask"]]), migi.createVd("div", [["class", "num"]], [migi.createVd("b", [["class", "audio"]]), "66w"]), migi.createVd("div", [["class", "ath"]], [item.author])]), migi.createVd("p", [["class", "txt"]], ["名字"])]);
          }
          return migi.createVd("li", [], [migi.createVd("div", [["class", "pic"]], [migi.createVd("div", [["class", "bg3"]]), migi.createVd("div", [["class", "bg2"]]), migi.createVd("div", [["class", "bg"]]), migi.createVd("img", [["src", item.img]]), migi.createVd("div", [["class", "mask"]]), migi.createVd("div", [["class", "num"]], [migi.createVd("b", [["class", "video"]]), item.num]), migi.createVd("div", [["class", "ath"]], [item.author])]), migi.createVd("p", [["class", "txt"]], [item.name])]);
        });
      })])])])]);
    }
  }, {
    key: 'list2',
    set: function set(v) {
      this.__setBind("list2", v);this.__data("list2");
    },
    get: function get() {
      return this.__getBind("list2");
    }
  }]);

  return HotAlbum;
}(migi.Component);

migi.name(HotAlbum, "HotAlbum");exports.default = HotAlbum;

/***/ }),

/***/ 3:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// QueryString
// ---------------
// This module provides utilities for dealing with query strings.
//
// Thanks to:
//  - http://nodejs.org/docs/v0.4.7/api/querystring.html
//  - http://developer.yahoo.com/yui/3/api/QueryString.html
//  - https://github.com/lifesinger/dew/tree/master/lib/querystring


// var QueryString = exports;

var QueryString = {};

// The escape/unescape function used by stringify/parse, provided so that it
// could be overridden if necessary. This is important in cases where
// non-standard delimiters are used, if the delimiters would not normally be
// handled properly by the built-in (en|de)codeURIComponent functions.
QueryString.escape = encodeURIComponent;

QueryString.unescape = function (s) {
    // The + character is interpreted as a space on the server side as well as
    // generated by forms with spaces in their fields.
    return decodeURIComponent(s.replace(/\+/g, ' '));
};

/**
 * Serialize an object to a query string. Optionally override the default
 * separator and assignment characters.
 *
 * stringify({foo: 'bar'})
 *   // returns 'foo=bar'
 *
 * stringify({foo: 'bar', baz: 'bob'}, ';', ':')
 *   // returns 'foo:bar;baz:bob'
 */
QueryString.stringify = function (obj, sep, eq, arrayKey) {
    if (!isPlainObject(obj)) return '';

    sep = sep || '&';
    eq = eq || '=';
    arrayKey = arrayKey || false;

    var buf = [],
        key,
        val;
    var escape = QueryString.escape;

    for (key in obj) {
        if (!hasOwnProperty.call(obj, key)) continue;

        val = obj[key];
        key = QueryString.escape(key);

        // val is primitive value
        if (isPrimitive(val)) {
            buf.push(key, eq, escape(val + ''), sep);
        }
        // val is not empty array
        else if (isArray(val) && val.length) {
                for (var i = 0; i < val.length; i++) {
                    if (isPrimitive(val[i])) {
                        buf.push(key, (arrayKey ? escape('[]') : '') + eq, escape(val[i] + ''), sep);
                    }
                }
            }
            // ignore other cases, including empty array, Function, RegExp, Date etc.
            else {
                    buf.push(key, eq, sep);
                }
    }

    buf.pop();
    return buf.join('');
};

/**
 * Deserialize a query string to an object. Optionally override the default
 * separator and assignment characters.
 *
 * parse('a=b&c=d')
 *   // returns {a: 'b', c: 'c'}
 */
QueryString.parse = function (str, sep, eq) {
    var ret = {};

    if (typeof str !== 'string' || trim(str).length === 0) {
        return ret;
    }

    var pairs = str.split(sep || '&');
    eq = eq || '=';
    var unescape = QueryString.unescape;

    for (var i = 0; i < pairs.length; i++) {

        var pair = pairs[i].split(eq);
        var key = unescape(trim(pair[0]));
        var val = unescape(trim(pair.slice(1).join(eq)));

        var m = key.match(/^(\w+)\[\]$/);
        if (m && m[1]) {
            key = m[1];
        }

        if (hasOwnProperty.call(ret, key)) {
            if (!isArray(ret[key])) {
                ret[key] = [ret[key]];
            }
            ret[key].push(val);
        } else {
            ret[key] = m ? [val] : val;
        }
    }

    return ret;
};

// Helpers

var toString = Object.prototype.toString;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var isArray = Array.isArray || function (val) {
    return toString.call(val) === '[object Array]';
};
var trim = String.prototype.trim ? function (str) {
    return str == null ? '' : String.prototype.trim.call(str);
} : function (str) {
    return str == null ? '' : str.toString().replace(/^\s+/, '').replace(/\s+$/, '');
};

/**
 * Checks to see if an object is a plain object (created using "{}" or
 * "new Object()" or "new FunctionClass()").
 */
function isPlainObject(o) {
    /**
     * NOTES:
     * isPlainObject(node = document.getElementById("xx")) -> false
     * toString.call(node):
     *   ie678 === '[object Object]', other === '[object HTMLElement]'
     * 'isPrototypeOf' in node:
     *   ie678 === false, other === true
     */
    return o && toString.call(o) === '[object Object]' && 'isPrototypeOf' in o;
}

/**
 * If the type of o is null, undefined, number, string, boolean,
 * return true.
 */
function isPrimitive(o) {
    return o !== Object(o);
}

module.exports = QueryString;

/***/ }),

/***/ 37:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Comment = __webpack_require__(10);

var _Comment2 = _interopRequireDefault(_Comment);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var init = void 0;
var Skip = -1;
var Take = 10;
var Size = 0;
var loadingMore = void 0;
var isShow = void 0;
var scrollCb = void 0;

var AuthorComment = function (_migi$Component) {
  _inherits(AuthorComment, _migi$Component);

  function AuthorComment() {
    var _ref;

    _classCallCheck(this, AuthorComment);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = AuthorComment.__proto__ || Object.getPrototypeOf(AuthorComment)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(AuthorComment, [{
    key: 'show',
    value: function show() {
      var self = this;
      isShow = true;
      $(self.element).show();
      if (!init) {
        init = true;
        self.load();
        self.ref.comment.on('chooseSubComment', function (rid, cid, name) {
          self.rootId = rid;
          self.replayId = cid;
          self.replayName = name;
        });
      }
    }
  }, {
    key: 'hide',
    value: function hide() {
      isShow = false;
      $(this.element).hide();
    }
  }, {
    key: 'load',
    value: function load() {
      var self = this;
      util.postJSON('api/author/GetToAuthorMessage_List', { AuthorID: self.props.authorId, Skip: Skip, Take: Take }, function (res) {
        if (res.success) {
          var data = res.data;
          self.ref.comment.list = data.data || [];
          Size = data.Size;
          if (data.data.length) {
            Skip = data.data[data.data.length - 1].Send_ID;
            if (data.data.length >= Size) {
              self.ref.comment.message = '';
            } else {
              scrollCb = function scrollCb() {
                self.checkMore();
              };
              $(window).on('scroll', scrollCb);
            }
          } else {
            self.ref.comment.message = '暂无评论';
          }
        } else {
          jsBridge.toast(res.message || util.ERROR_MESSAGE);
        }
      }, function (res) {
        jsBridge.toast(res.message || util.ERROR_MESSAGE);
      });
    }
  }, {
    key: 'checkMore',
    value: function checkMore() {
      var self = this;
      var $window = $(window);
      var $body = $(document.body);
      var WIN_HEIGHT = $window.height();
      if (isShow && !loadingMore && $body.scrollTop() + WIN_HEIGHT + 30 > $body.height()) {
        loadingMore = true;
        util.postJSON('api/author/GetToAuthorMessage_List', { AuthorID: self.props.authorId, Skip: Skip, Take: Take }, function (res) {
          if (res.success) {
            var data = res.data;
            if (data.data.length) {
              Skip = data.data[data.data.length - 1].Send_ID;
              self.ref.comment.addMore(data.data);
              if (data.data.length < Take) {
                self.ref.comment.message = '';
                $window.off('scroll', scrollCb);
              }
            } else {
              self.ref.comment.message = '';
              $window.off('scroll', scrollCb);
            }
          } else {
            jsBridge.toast(res.message || util.ERROR_MESSAGE);
          }
          loadingMore = false;
        }, function () {
          loadingMore = false;
        });
      }
    }
  }, {
    key: 'clickReplay',
    value: function clickReplay() {
      this.replayId = null;
      this.replayName = null;
    }
  }, {
    key: 'input',
    value: function input(e, vd) {
      var v = $(vd.element).val().trim();
      this.hasContent = v.length > 0;
    }
  }, {
    key: 'click',
    value: function click(e) {
      e.preventDefault();
      var self = this;
      if (self.hasContent) {
        var $input = $(this.ref.input.element);
        var Content = $input.val();
        var ParentID = self.replayId !== null ? self.replayId : -1;
        var RootID = self.rootId !== null ? self.rootId : -1;
        self.loading = true;
        util.postJSON('api/comment/AddComment', {
          ParentID: ParentID,
          RootID: RootID,
          Content: Content,
          commentType: 2,
          commentTypeID: self.props.authorId
        }, function (res) {
          if (res.success) {
            $input.val('');
            if (RootID === -1) {
              self.ref.comment.addNew(res.data);
            } else {
              self.ref.comment.addChild(res.data);
            }
          } else {
            jsBridge.toast(res.message || util.ERROR_MESSAGE);
          }
          self.loading = false;
        }, function (res) {
          jsBridge.toast(res.message || util.ERROR_MESSAGE);
          self.loading = false;
        });
      }
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "comments"]], [migi.createCp(_Comment2.default, [["ref", "comment"]]), migi.createVd("div", [["class", "form"]], [migi.createVd("div", [["class", new migi.Obj("replayId", this, function () {
        return 'reply' + (this.replayId ? '' : ' fn-hide');
      })], ["onClick", new migi.Cb(this, this.clickReplay)]], [new migi.Obj("replayName", this, function () {
        return this.replayName;
      })]), migi.createVd("div", [["class", "inputs"]], [migi.createVd("input", [["ref", "input"], ["type", "text"], ["placeholder", "回复..."], ["onInput", new migi.Cb(this, this.input)]])]), migi.createVd("button", [["onClick", new migi.Cb(this, this.click)], ["class", new migi.Obj(["hasContent", "loading"], this, function () {
        return this.hasContent && !this.loading ? '' : 'dis';
      })]], ["确定"])])]);
    }
  }, {
    key: 'rootId',
    set: function set(v) {
      this.__setBind("rootId", v);this.__data("rootId");
    },
    get: function get() {
      if (this.__initBind("rootId")) this.__setBind("rootId", null);return this.__getBind("rootId");
    }
  }, {
    key: 'replayId',
    set: function set(v) {
      this.__setBind("replayId", v);this.__data("replayId");
    },
    get: function get() {
      if (this.__initBind("replayId")) this.__setBind("replayId", null);return this.__getBind("replayId");
    }
  }, {
    key: 'replayName',
    set: function set(v) {
      this.__setBind("replayName", v);this.__data("replayName");
    },
    get: function get() {
      return this.__getBind("replayName");
    }
  }, {
    key: 'hasContent',
    set: function set(v) {
      this.__setBind("hasContent", v);this.__data("hasContent");
    },
    get: function get() {
      return this.__getBind("hasContent");
    }
  }, {
    key: 'loading',
    set: function set(v) {
      this.__setBind("loading", v);this.__data("loading");
    },
    get: function get() {
      return this.__getBind("loading");
    }
  }]);

  return AuthorComment;
}(migi.Component);

migi.name(AuthorComment, "AuthorComment");exports.default = AuthorComment;

/***/ }),

/***/ 38:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _HotAlbum = __webpack_require__(13);

var _HotAlbum2 = _interopRequireDefault(_HotAlbum);

var _HotWork = __webpack_require__(91);

var _HotWork2 = _interopRequireDefault(_HotWork);

var _HotAuthor = __webpack_require__(90);

var _HotAuthor2 = _interopRequireDefault(_HotAuthor);

var _Dynamic = __webpack_require__(11);

var _Dynamic2 = _interopRequireDefault(_Dynamic);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var hotAlbum = [{
  id: 1,
  img: 'http://bbs.xiguo.net/zq/zj/z002.jpg',
  name: '漱愿记',
  num: '33w'
}];

var list = [{
  imgs: ['http://bbs.xiguo.net/zq/zz/03.png', 'http://bbs.xiguo.net/zq/zz/02.png'],
  pic: 'http://bbs.xiguo.net/zq/zp/01.jpg',
  names: ['慕寒', '司夏'],
  time: '1小时前',
  type: 'song',
  action: '发布了歌曲',
  song: '《明月舟》'
}, {
  imgs: ['http://bbs.xiguo.net/zq/zz/02.png'],
  pic: 'http://bbs.xiguo.net/zq/zp/04.jpg',
  names: ['司夏'],
  time: '1天前',
  type: 'song',
  action: '发布了歌曲',
  song: '《送郎君》'
}, {
  imgs: ['http://bbs.xiguo.net/zq/zz/02.png'],
  pic: 'http://bbs.xiguo.net/zq/zp/04.jpg',
  names: ['司夏'],
  time: '3天前',
  type: 'weibo',
  action: '发布了微博',
  txt: '小伙伴们高考加油！'
}];

var Home = function (_migi$Component) {
  _inherits(Home, _migi$Component);

  function Home() {
    var _ref;

    _classCallCheck(this, Home);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Home.__proto__ || Object.getPrototypeOf(Home)).call.apply(_ref, [this].concat(data)));

    _this.on(migi.Event.DOM, function () {
      this.ref.hotAlbum.autoWidth();
    });
    return _this;
  }

  _createClass(Home, [{
    key: 'show',
    value: function show() {
      this.element.style.display = 'block';
    }
  }, {
    key: 'hide',
    value: function hide() {
      this.element.style.display = 'none';
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "home"]], [migi.createCp(_HotWork2.default, [["authorId", this.props.authorId], ["ref", "hotWork"], ["title", "热门作品"]]), migi.createCp(_HotAlbum2.default, [["ref", "hotAlbum"], ["list", hotAlbum], ["title", "专辑"]]), migi.createCp(_HotAuthor2.default, [["ref", "hotAuthor"], ["title", "关系"]]), migi.createVd("h5", [["class", "dynamic"]], ["作者动态"]), migi.createCp(_Dynamic2.default, [["list", list]])]);
    }
  }]);

  return Home;
}(migi.Component);

migi.name(Home, "Home");exports.default = Home;

/***/ }),

/***/ 39:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Profile = __webpack_require__(85);

var _Profile2 = _interopRequireDefault(_Profile);

var _Link = __webpack_require__(84);

var _Link2 = _interopRequireDefault(_Link);

var _Tags = __webpack_require__(86);

var _Tags2 = _interopRequireDefault(_Tags);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Nav = function (_migi$Component) {
  _inherits(Nav, _migi$Component);

  function Nav() {
    var _ref;

    _classCallCheck(this, Nav);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Nav.__proto__ || Object.getPrototypeOf(Nav)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Nav, [{
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "nav"]], [migi.createVd("div", [["class", "bg"]]), migi.createCp(_Profile2.default, [["ref", "profile"], ["authorId", this.props.authorId]]), migi.createCp(_Link2.default, [["ref", "link"]]), migi.createCp(_Tags2.default, [["ref", "tags"]])]);
    }
  }]);

  return Nav;
}(migi.Component);

migi.name(Nav, "Nav");exports.default = Nav;

/***/ }),

/***/ 40:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Tags = __webpack_require__(87);

var _Tags2 = _interopRequireDefault(_Tags);

var _PlayList = __webpack_require__(12);

var _PlayList2 = _interopRequireDefault(_PlayList);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var init = void 0;
var last = '';
var ajax = void 0;

var Works = function (_migi$Component) {
  _inherits(Works, _migi$Component);

  function Works() {
    var _ref;

    _classCallCheck(this, Works);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Works.__proto__ || Object.getPrototypeOf(Works)).call.apply(_ref, [this].concat(data)));

    var self = _this;
    self.on(migi.Event.DOM, function () {
      self.ref.tag.on('change', function (lA, lB) {
        // self.ref.playlist.load(lA, lB);
        var Parameter = lA.concat(lB);
        Parameter = Parameter.length ? JSON.stringify(Parameter) : '';
        if (last !== Parameter) {
          last = Parameter;
          if (ajax) {
            ajax.abort();
          }
          ajax = util.postJSON('api/author/SearchWorks', { AuthorID: this.props.authorId, Parameter: Parameter, Skip: 1, Take: 10 }, function (res) {
            if (res.success) {
              self.ref.playlist.setData(res.data);
            }
          });
        }
      });
    });
    return _this;
  }

  _createClass(Works, [{
    key: 'show',
    value: function show() {
      $(this.element).show();
      if (!init) {
        init = true;
        this.load();
      }
    }
  }, {
    key: 'hide',
    value: function hide() {
      $(this.element).hide();
    }
  }, {
    key: 'load',
    value: function load() {
      var self = this;
      util.postJSON('api/author/GetAuthorWorks', { AuthorID: this.props.authorId }, function (res) {
        if (res.success) {
          var data = res.data;
          self.ref.tag.tagList = data;
          self.ref.tag.autoWidth();
        }
      });
      ajax = util.postJSON('api/author/SearchWorks', { AuthorID: this.props.authorId, Parameter: '', Skip: 1, Take: 10 }, function (res) {
        if (res.success) {
          self.ref.playlist.setData(res.data);
        }
      });
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "works"]], [migi.createCp(_Tags2.default, [["authorId", this.props.authorId], ["ref", "tag"]]), migi.createCp(_PlayList2.default, [["ref", "playlist"]])]);
    }
  }]);

  return Works;
}(migi.Component);

migi.name(Works, "Works");exports.default = Works;

/***/ }),

/***/ 69:
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ 77:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "author.html";

/***/ }),

/***/ 84:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Link = function (_migi$Component) {
  _inherits(Link, _migi$Component);

  function Link() {
    var _ref;

    _classCallCheck(this, Link);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Link.__proto__ || Object.getPrototypeOf(Link)).call.apply(_ref, [this].concat(data)));

    _this.on(migi.Event.DOM, function () {
      this.autoWidth();
    });
    return _this;
  }

  _createClass(Link, [{
    key: 'autoWidth',
    value: function autoWidth() {
      var $root = $(this.element);
      var $c = $root.find('.c');
      var $ul = $c.find('ul');
      $c.css('width', $ul.width() + 1);
    }
  }, {
    key: 'click',
    value: function click(e, vd, tvd) {
      e.preventDefault();
      var href = tvd.props.href;
      jsBridge.pushWindow(href);
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "link"]], [migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [["onClick", [[{ "a": { "_v": true } }, new migi.Cb(this, this.click)]]]], [migi.createVd("li", [], [migi.createVd("a", [["href", new migi.Obj("_5SingUrl", this, function () {
        return this._5SingUrl;
      })], ["class", new migi.Obj("_5SingUrl", this, function () {
        return this._5SingUrl ? '' : 'fn-hide';
      })]], [migi.createVd("span", [], ["5sing"])])]), migi.createVd("li", [], [migi.createVd("a", [["href", new migi.Obj("_BilibiliUrl", this, function () {
        return this._BilibiliUrl;
      })], ["class", new migi.Obj("_BilibiliUrl", this, function () {
        return this._BilibiliUrl ? 'bili' : 'fn-hide';
      })]], [migi.createVd("span", [], ["b站"])])]), migi.createVd("li", [], [migi.createVd("a", [["href", new migi.Obj("_BaiduUrl", this, function () {
        return this._BaiduUrl;
      })], ["class", new migi.Obj("_BaiduUrl", this, function () {
        return this._BaiduUrl ? 'baidu' : 'fn-hide';
      })]], [migi.createVd("span", [], ["百度"])])]), migi.createVd("li", [], [migi.createVd("a", [["href", new migi.Obj("_WangyiUrl", this, function () {
        return this._WangyiUrl;
      })], ["class", new migi.Obj("_WangyiUrl", this, function () {
        return this._WangyiUrl ? 'wangyi' : 'fn-hide';
      })]], [migi.createVd("span", [], ["网易"])])]), migi.createVd("li", [], [migi.createVd("a", [["href", new migi.Obj("_WeiboUrl", this, function () {
        return this._WeiboUrl;
      })], ["class", new migi.Obj("_WeiboUrl", this, function () {
        return this._WeiboUrl ? 'weibo' : 'fn-hide';
      })]], [migi.createVd("span", [], ["微博"])])])])])]);
    }
  }, {
    key: '_5SingUrl',
    set: function set(v) {
      this.__setBind("_5SingUrl", v);this.__data("_5SingUrl");
    },
    get: function get() {
      return this.__getBind("_5SingUrl");
    }
  }, {
    key: '_BilibiliUrl',
    set: function set(v) {
      this.__setBind("_BilibiliUrl", v);this.__data("_BilibiliUrl");
    },
    get: function get() {
      return this.__getBind("_BilibiliUrl");
    }
  }, {
    key: '_BaiduUrl',
    set: function set(v) {
      this.__setBind("_BaiduUrl", v);this.__data("_BaiduUrl");
    },
    get: function get() {
      return this.__getBind("_BaiduUrl");
    }
  }, {
    key: '_WangyiUrl',
    set: function set(v) {
      this.__setBind("_WangyiUrl", v);this.__data("_WangyiUrl");
    },
    get: function get() {
      return this.__getBind("_WangyiUrl");
    }
  }, {
    key: '_WeiboUrl',
    set: function set(v) {
      this.__setBind("_WeiboUrl", v);this.__data("_WeiboUrl");
    },
    get: function get() {
      return this.__getBind("_WeiboUrl");
    }
  }]);

  return Link;
}(migi.Component);

migi.name(Link, "Link");exports.default = Link;

/***/ }),

/***/ 85:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _authorTemplate = __webpack_require__(9);

var _authorTemplate2 = _interopRequireDefault(_authorTemplate);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Profile = function (_migi$Component) {
  _inherits(Profile, _migi$Component);

  function Profile() {
    var _ref;

    _classCallCheck(this, Profile);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Profile.__proto__ || Object.getPrototypeOf(Profile)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Profile, [{
    key: "click",
    value: function click(e) {
      e.preventDefault();
      var self = this;
      self.loading = true;
      if (self.isLike) {
        util.postJSON('api/author/RemoveAuthorToUser', { Author: self.props.authorId }, function (res) {
          if (res.success) {
            self.isLike = false;
            self.fansNumber = res.data.followCount;
            jsBridge.toast('取关成功');
          } else {
            jsBridge.toast(res.message || util.ERROR_MESSAGE);
          }
          self.loading = false;
        }, function (res) {
          jsBridge.toast(res.message || util.ERROR_MESSAGE);
          self.loading = false;
        });
      } else {
        util.postJSON('api/author/SaveAuthorToUser', { Author: self.props.authorId }, function (res) {
          if (res.success) {
            self.isLike = true;
            self.fansNumber = res.data.followCount;
            jsBridge.toast('关注成功');
          } else {
            jsBridge.toast(res.message || util.ERROR_MESSAGE);
          }
          self.loading = false;
        }, function (res) {
          jsBridge.toast(res.message || util.ERROR_MESSAGE);
          self.loading = false;
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "profile"]], [migi.createVd("div", [["class", "pic"]], [migi.createVd("img", [["src", new migi.Obj("headUrl", this, function () {
        return this.headUrl || 'src/common/blank.png';
      })]]), migi.createVd("b", [["class", "v"]])]), migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [["class", "n"]], [migi.createVd("h3", [], [new migi.Obj("authorName", this, function () {
        return this.authorName || '&nbsp;';
      })]), new migi.Obj("authorType", this, function () {
        return this.authorType.map(function (item) {
          return migi.createVd("span", [["class", "cp_author_type_" + item]], []);
        });
      })]), migi.createVd("p", [["class", "intro"]], [new migi.Obj("sign", this, function () {
        return this.sign || '&nbsp;';
      })]), migi.createVd("div", [["class", "o"]], [migi.createVd("div", [["class", "fans"]], [migi.createVd("strong", [], [new migi.Obj("fansNumber", this, function () {
        return this.fansNumber || '0';
      })]), migi.createVd("span", [], ["粉丝"])]), migi.createVd("div", [["class", "hot"]], [migi.createVd("div", [["class", "line"]], [migi.createVd("b", [["class", "progress"]]), migi.createVd("b", [["class", "point"]])]), migi.createVd("span", [], ["热度"])]), migi.createVd("a", [["href", "#"], ["class", new migi.Obj(["isLike", "loading"], this, function () {
        return (this.isLike ? 'support' : 'follow') + (this.loading ? ' loading' : '');
      })], ["onClick", new migi.Cb(this, this.click)]], [new migi.Obj("isLike", this, function () {
        return this.isLike ? '应援' : '关注';
      })])])])]);
    }
  }, {
    key: "authorName",
    set: function set(v) {
      this.__setBind("authorName", v);this.__data("authorName");
    },
    get: function get() {
      return this.__getBind("authorName");
    }
  }, {
    key: "sign",
    set: function set(v) {
      this.__setBind("sign", v);this.__data("sign");
    },
    get: function get() {
      return this.__getBind("sign");
    }
  }, {
    key: "authorType",
    set: function set(v) {
      this.__setBind("authorType", v);this.__data("authorType");
    },
    get: function get() {
      if (this.__initBind("authorType")) this.__setBind("authorType", []);return this.__getBind("authorType");
    }
  }, {
    key: "headUrl",
    set: function set(v) {
      this.__setBind("headUrl", v);this.__data("headUrl");
    },
    get: function get() {
      return this.__getBind("headUrl");
    }
  }, {
    key: "fansNumber",
    set: function set(v) {
      this.__setBind("fansNumber", v);this.__data("fansNumber");
    },
    get: function get() {
      return this.__getBind("fansNumber");
    }
  }, {
    key: "isLike",
    set: function set(v) {
      this.__setBind("isLike", v);this.__data("isLike");
    },
    get: function get() {
      return this.__getBind("isLike");
    }
  }, {
    key: "loading",
    set: function set(v) {
      this.__setBind("loading", v);this.__data("loading");
    },
    get: function get() {
      if (this.__initBind("loading")) this.__setBind("loading", true);return this.__getBind("loading");
    }
  }, {
    key: "type",
    set: function set(v) {
      v = v || [];
      var hash = {};
      v.forEach(function (item) {
        var css = (0, _authorTemplate2.default)(item.AuthorTypeID).css;
        hash[css] = true;
      });
      this.authorType = Object.keys(hash);
    }
  }]);

  return Profile;
}(migi.Component);

migi.name(Profile, "Profile");exports.default = Profile;

/***/ }),

/***/ 86:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Tags = function (_migi$Component) {
  _inherits(Tags, _migi$Component);

  function Tags() {
    var _ref;

    _classCallCheck(this, Tags);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Tags.__proto__ || Object.getPrototypeOf(Tags)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Tags, [{
    key: 'click',
    value: function click(e, vd, tvd) {
      var $ul = $(this.element).find('ul');
      var $li = $(tvd.element);
      if ($li.hasClass('cur')) {
        return;
      }
      $ul.find('.cur').removeClass('cur');
      $li.addClass('cur');
      this.emit('change', $li.attr('rel'));
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "tags"]], [migi.createVd("ul", [["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.click)]]]], [migi.createVd("li", [["class", "item cur"], ["rel", "0"]], [migi.createVd("span", [], ["主页"])]), migi.createVd("li", [["class", "item"], ["rel", "1"]], [migi.createVd("span", [], ["作品"])]), migi.createVd("li", [["class", "item"], ["rel", "2"]], [migi.createVd("span", [], ["留言"])])])]);
    }
  }]);

  return Tags;
}(migi.Component);

migi.name(Tags, "Tags");exports.default = Tags;

/***/ }),

/***/ 87:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _authorTemplate = __webpack_require__(9);

var _authorTemplate2 = _interopRequireDefault(_authorTemplate);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var choosedL2 = {};

var Tags2 = function (_migi$Component) {
  _inherits(Tags2, _migi$Component);

  function Tags2() {
    var _ref;

    _classCallCheck(this, Tags2);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Tags2.__proto__ || Object.getPrototypeOf(Tags2)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Tags2, [{
    key: 'clickL1',
    value: function clickL1(e, vd, tvd) {
      e.preventDefault();
      var $ul = $(vd.element);
      var $li = $(tvd.element);
      $li.toggleClass('on');
      var $lis = $ul.find('.on');
      var list = [];
      var hash = {};
      // 都没选为全部
      if (!$lis[0]) {
        this.tagList.forEach(function (item) {
          item.FilterlevelB.forEach(function (item2) {
            var key = 'id' + item2.ID + ',type' + item2.TagType;
            if (!hash.hasOwnProperty(key)) {
              hash[key] = true;
              list.push(item2);
            }
          });
        });
      } else {
        var choosed = {};
        $lis.each(function (index, li) {
          choosed[$(li).attr('rel')] = true;
        });
        this.tagList.forEach(function (item, i) {
          if (choosed.hasOwnProperty(i)) {
            item.FilterlevelB.forEach(function (item2) {
              var key = 'id' + item2.ID + ',type' + item2.TagType;
              if (!hash.hasOwnProperty(key)) {
                hash[key] = true;
                list.push(item2);
              }
            });
          }
        });
      }
      // 和上次没变化不改变
      var hasChange = false;
      if (list.length !== this.tagList2.length) {
        hasChange = true;
      } else {
        for (var i = 0, len = list.length; i < len; i++) {
          if (list[i].ID !== this.tagList2[i].ID && list[i].TagType !== this.tagList2[i].TagType) {
            hasChange = true;
            break;
          }
        }
      }
      if (hasChange) {
        this.tagList2 = list;
        this.autoWidth2();
        this.checkL2();
        this.change();
      }
    }
  }, {
    key: 'clickL2',
    value: function clickL2(e, vd, tvd) {
      e.preventDefault();
      var key = 'id' + tvd.props.id + ',type' + tvd.props.tagType;
      var $li = $(tvd.element);
      choosedL2[key] = !$li.hasClass('on');
      this.tagList2 = this.tagList2;
      this.change();
    }
  }, {
    key: 'checkL2',
    value: function checkL2() {
      // 遍历l2标签，chossed中没有的删除
      var hash = {};
      this.tagList2.forEach(function (item) {
        var key = 'id' + item.ID + ',type' + item.TagType;
        hash[key] = true;
      });
      Object.keys(choosedL2).forEach(function (key) {
        if (!hash[key]) {
          choosedL2[key] = false;
        }
      });
    }
  }, {
    key: 'autoWidth',
    value: function autoWidth() {
      var $li = $(this.ref.l1.element);
      var $c = $li.find('.c');
      $c.css('width', '9999rem');
      var $ul = $c.find('ul');
      $c.css('width', $ul.width() + 1);
    }
  }, {
    key: 'autoWidth2',
    value: function autoWidth2() {
      var $li = $(this.ref.l2.element);
      var $c = $li.find('.c');
      $c.css('width', '9999rem');
      var $ul = $c.find('ul');
      $c.css('width', $ul.width() + 1);
    }
  }, {
    key: 'change',
    value: function change() {
      var self = this;
      var $lis = $(self.ref.l1.element).find('li.on');
      var lA = [];
      $lis.each(function (i, li) {
        var index = $(li).attr('rel');
        var item = self.tagList[index];
        lA.push({
          ID: item.ID,
          TagType: 0,
          Filterlevel: 'A'
        });
      });
      var lB = [];
      this.tagList2.forEach(function (item) {
        var key = 'id' + item.ID + ',type' + item.TagType;
        if (choosedL2[key]) {
          lB.push({
            ID: item.ID,
            TagType: item.TagType,
            Filterlevel: item.Filterlevel
          });
        }
      });
      this.emit('change', lA, lB);
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "tags"]], [migi.createVd("div", [["class", "l1"], ["ref", "l1"], ["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.clickL1)]]]], [migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [], [new migi.Obj("tagList", this, function () {
        return this.tagList.map(function (item, i) {
          return migi.createVd("li", [["rel", i]], [migi.createVd("a", [["href", "#"]], [migi.createVd("span", [], [(0, _authorTemplate2.default)(item.ID).name])])]);
        });
      })])])]), migi.createVd("div", [["class", "l2"], ["ref", "l2"], ["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.clickL2)]]]], [migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [], [new migi.Obj("tagList2", this, function () {
        return this.tagList2.map(function (item) {
          var key = 'id' + item.ID + ',type' + item.TagType;
          return migi.createVd("li", [["tagType", item.TagType], ["id", item.ID], ["class", choosedL2[key] ? 'on' : '']], [migi.createVd("a", [["href", "#"]], [migi.createVd("span", [], [item.TagName])])]);
        });
      })])])])]);
    }
  }, {
    key: 'tagList',
    get: function get() {
      return this._tagList || [];
    },
    set: function set(v) {
      this._tagList = v;
      var list = [];
      var hash = {};
      v.forEach(function (item) {
        item.FilterlevelB.forEach(function (item2) {
          var key = 'id' + item2.ID + ',type' + item2.TagType;
          if (!hash.hasOwnProperty(key)) {
            hash[key] = true;
            list.push(item2);
          }
        });
      });
      this.tagList2 = list;
      this.autoWidth2();
      ;this.__array("tagList", v);this.__data("tagList");
    }
  }, {
    key: 'tagList2',
    get: function get() {
      return this._tagList2 || [];
    },
    set: function set(v) {
      this._tagList2 = v;
      // let param = v.map(function(item) {
      //   return {
      //     ID: item.ID,
      //     TagType: item.TagType
      //   };
      // });
      // util.postJSON('api/author/SearchWorks', { AuthorID: this.props.authorId, Parameter: JSON.stringify(param), Skip: 1, Take: 10 }, function (res) {
      //
      // });
      ;this.__array("tagList2", v);this.__data("tagList2");
    }
  }]);

  return Tags2;
}(migi.Component);

migi.name(Tags2, "Tags2");exports.default = Tags2;

/***/ }),

/***/ 88:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(77);

__webpack_require__(69);

var _animaQuerystring = __webpack_require__(0);

var _animaQuerystring2 = _interopRequireDefault(_animaQuerystring);

var _Nav = __webpack_require__(39);

var _Nav2 = _interopRequireDefault(_Nav);

var _Home = __webpack_require__(38);

var _Home2 = _interopRequireDefault(_Home);

var _Works = __webpack_require__(40);

var _Works2 = _interopRequireDefault(_Works);

var _AuthorComment = __webpack_require__(37);

var _AuthorComment2 = _interopRequireDefault(_AuthorComment);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var search = _animaQuerystring2.default.parse(location.search.replace(/^\?/, ''));
var id = search.id;

jsBridge.ready(function () {
  var nav = migi.render(migi.createCp(_Nav2.default, [["authorId", id]]), document.body);
  var profile = nav.ref.profile;
  var link = nav.ref.link;
  var tags = nav.ref.tags;

  var home = migi.render(migi.createCp(_Home2.default, [["authorId", id]]), document.body);
  var hotWork = home.ref.hotWork;
  var hotAuthor = home.ref.hotAuthor;

  var works = migi.render(migi.createCp(_Works2.default, [["authorId", id]]), document.body);
  var authorComment = migi.render(migi.createCp(_AuthorComment2.default, [["authorId", id]]), document.body);
  tags.on('change', function (i) {
    home && home.hide();
    works && works.hide();
    authorComment && authorComment.hide();
    switch (i) {
      case '0':
        home.show();
        break;
      case '1':
        works.show();
        break;
      case '2':
        authorComment.show();
        break;
    }
  });
  // tags.emit('change', '2');

  if (id) {
    util.postJSON('api/author/GetAuthorDetails', { AuthorID: id }, function (res) {
      if (res.success) {
        var data = res.data;

        profile.headUrl = data.Head_url;
        profile.authorName = data.AuthorName;
        profile.type = data.Authortype;
        profile.sign = data.Sign;
        profile.fansNumber = data.FansNumber;
        profile.isLike = data.IsLike;
        profile.loading = false;

        link._5SingUrl = data._5SingUrl;
        link._BilibiliUrl = data._BilibiliUrl;
        link._BaiduUrl = data._BaiduUrl;
        link._WangyiUrl = data._WangyiUrl;
        link._WeiboUrl = data._WeiboUrl;
        link.autoWidth();
      } else {
        jsBridge.toast(util.ERROR_MESSAGE);
      }
    });
    util.postJSON('api/author/GetAuthorHomePage', { AuthorID: id }, function (res) {
      if (res.success) {
        var data = res.data;
        hotWork.dataList = data.Hot_Works_Items;
        hotWork.autoWidth();
        hotAuthor.dataList = data.AuthorToAuthor;
        hotAuthor.autoWidth();
      } else {
        jsBridge.toast(util.ERROR_MESSAGE);
      }
    });
  }
});

/***/ }),

/***/ 89:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

__webpack_require__(125);

var TYPE = {
  111: '演唱',
  112: '和声',
  113: '伴唱',
  114: '戏腔',
  121: '作曲',
  122: '编曲',
  123: '和声编写',
  131: '混音',
  132: '母带',
  133: '录音',
  134: '修音',
  135: '剧情混音',
  141: '乐器实录',
  151: '配音',
  211: '视频',
  212: '合成',
  213: '压制',
  311: '立绘',
  312: 'CG',
  313: '场景',
  314: 'logo设计',
  315: '线稿',
  316: '上色',
  317: '手绘',
  321: '3D建模',
  322: '打光',
  323: '动画',
  324: '骨骼绑定',
  331: '设计',
  332: '海报',
  333: 'logo',
  334: '分镜',
  341: '漫画',
  411: '作词',
  421: '文案',
  422: '剧本',
  423: '小说'
};

var CODE = {
  '演唱': 111
};

exports.default = {
  TYPE: TYPE,
  CODE: CODE
};

/***/ }),

/***/ 9:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (authorType) {
  switch (authorType) {
    case 111:
      return {
        name: '演唱',
        abbr: '唱',
        css: 'chang',
        labelType: 11
      };
    case 121:
      return {
        name: '作曲',
        abbr: '曲',
        css: 'qu',
        labelType: 12
      };
    case 122:
      return {
        name: '编曲',
        abbr: '曲',
        css: 'qu',
        labelType: 13
      };
    case 411:
      return {
        name: '作词',
        abbr: '文',
        css: 'wen',
        labelType: 14
      };
    case 131:
      return {
        name: '混音',
        abbr: '混',
        css: 'hun',
        labelType: 15
      };
    default:
      return {
        name: authorType,
        abbr: authorType,
        css: authorType,
        labelType: -1
      };
  }
};

; /**
   * Created by army8735 on 2017/8/13.
   */

/***/ }),

/***/ 90:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var HotAuthor = function (_migi$Component) {
  _inherits(HotAuthor, _migi$Component);

  function HotAuthor() {
    var _ref;

    _classCallCheck(this, HotAuthor);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = HotAuthor.__proto__ || Object.getPrototypeOf(HotAuthor)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(HotAuthor, [{
    key: 'autoWidth',
    value: function autoWidth() {
      this.$root = $(this.element);
      this.list = this.ref.list.element;
      this.$list = $(this.list);
      var $c = this.$list.find('.c');
      $c.width('css', '9999rem');
      var $ul = $c.find('ul');
      $c.css('width', $ul.width() + 1);
    }
  }, {
    key: 'click',
    value: function click(e, vd, tvd) {
      var AuthorID = tvd.props.AuthorID;
      if (AuthorID) {
        location.href = 'author.html?id=' + AuthorID;
      }
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "cp_hotauthor"]], [migi.createVd("h3", [], [this.props.title]), migi.createVd("div", [["class", "list"], ["ref", "list"]], [migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.click)]]]], [new migi.Obj("dataList", this, function () {
        return this.dataList.map(function (item) {
          var types = item.WorksType || [];
          return migi.createVd("li", [["AuthorID", item.AuthorID]], [migi.createVd("div", [["class", "pic"], ["style", 'background:url(' + (item.Head_url || 'src/common/blank.png') + ')']], [types.slice(0, 2).map(function (item) {
            return migi.createVd("b", [["class", 'cp_author_type' + item]]);
          })]), migi.createVd("div", [["class", "txt"]], [item.AuthorName]), migi.createVd("div", [["class", "info"]], ["合作", item.CooperationTimes, "次"])]);
        });
      })])])])]);
    }
  }, {
    key: 'dataList',
    set: function set(v) {
      this.__setBind("dataList", v);this.__data("dataList");
    },
    get: function get() {
      if (this.__initBind("dataList")) this.__setBind("dataList", []);return this.__getBind("dataList");
    }
  }]);

  return HotAuthor;
}(migi.Component);

migi.name(HotAuthor, "HotAuthor");exports.default = HotAuthor;

/***/ }),

/***/ 91:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _AuthorType = __webpack_require__(89);

var _AuthorType2 = _interopRequireDefault(_AuthorType);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var HotWork = function (_migi$Component) {
  _inherits(HotWork, _migi$Component);

  function HotWork() {
    var _ref;

    _classCallCheck(this, HotWork);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = HotWork.__proto__ || Object.getPrototypeOf(HotWork)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(HotWork, [{
    key: 'autoWidth',
    value: function autoWidth() {
      this.list = this.ref.list.element;
      this.$list = $(this.list);
      var $c = this.$list.find('.c');
      $c.width('css', '9999rem');
      var $ul = $c.find('ul');
      $c.css('width', $ul.width() + 1);
    }
  }, {
    key: 'click',
    value: function click(e, vd, tvd) {
      var worksID = tvd.props.WorksID;
      if (worksID) {
        jsBridge.pushWindow('works.html?id=' + worksID);
      }
    }
  }, {
    key: 'render',
    value: function render() {
      var authorId = this.props.authorId;
      return migi.createVd("div", [["class", "cp_hotwork"]], [migi.createVd("h3", [], [this.props.title]), migi.createVd("div", [["class", "list"], ["ref", "list"]], [migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.click)]]]], [new migi.Obj("dataList", this, function () {
        return this.dataList.map(function (item) {
          var myAuthor = void 0;
          var workAuthors = '';
          var authorList = item.Works_Items[0].Works_Item_Author;
          authorList.forEach(function (item) {
            if (item.ID === authorId) {
              myAuthor = item;
            }
          });
          if (myAuthor) {
            // 如果是歌手，将其它歌手&链接并加上with
            if (myAuthor.WorksAuthorType === _AuthorType2.default.CODE.演唱) {
              var authors = [];
              authorList.forEach(function (item) {
                if (item.ID !== authorId) {
                  authors.push(item.AuthName);
                }
              });
              if (authors.length) {
                workAuthors = 'with ' + authors.join('&');
              }
            }
            // 其它类型将歌手全部展示
            else {
                var _authors = [];
                authorList.forEach(function (item) {
                  if (item.ID !== authorId) {
                    _authors.push(item.AuthName);
                  }
                });
                if (_authors.length) {
                  workAuthors = _authors.join('&');
                }
              }
          }
          // 其它类型将歌手全部展示
          else {
              var _authors2 = [];
              authorList.forEach(function (item) {
                if (item.AuthorID !== authorId) {
                  _authors2.push(item.AuthName);
                }
              });
              if (_authors2.length) {
                workAuthors = _authors2.join('&');
              }
            }
          return migi.createVd("li", [["worksID", item.WorksID]], [migi.createVd("div", [["class", "pic"], ["style", 'background:url(' + (item.cover_Pic || 'src/common/blank.png') + ') no-repeat center']], [migi.createVd("div", [["class", "num"]], [migi.createVd("b", [["class", "audio"]]), item.Popular]), migi.createVd("div", [["class", "ath"]], [workAuthors])]), migi.createVd("p", [["class", "txt"]], [item.Title])]);
        });
      })])])])]);
    }
  }, {
    key: 'dataList',
    set: function set(v) {
      this.__setBind("dataList", v);this.__data("dataList");
    },
    get: function get() {
      if (this.__initBind("dataList")) this.__setBind("dataList", []);return this.__getBind("dataList");
    }
  }]);

  return HotWork;
}(migi.Component);

migi.name(HotWork, "HotWork");exports.default = HotWork;

/***/ })

/******/ });