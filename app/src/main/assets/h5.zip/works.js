/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 106);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(3);

/***/ }),

/***/ 10:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var NOT_LOADED = 0;
var IS_LOADING = 1;
var HAS_LOADED = 2;
var subLoadHash = {};
var subSkipHash = {};
var Take = 10;

var Comment = function (_migi$Component) {
  _inherits(Comment, _migi$Component);

  function Comment() {
    var _ref;

    _classCallCheck(this, Comment);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Comment.__proto__ || Object.getPrototypeOf(Comment)).call.apply(_ref, [this].concat(data)));

    var self = _this;
    self.on(migi.Event.DOM, function () {
      $(self.ref.list.element).on('click', '.more', function () {
        var $message = $(this);
        var rid = $message.attr('rid');
        $message.removeClass('more').text('读取中...');
        util.postJSON('api/author/GetTocomment_T_List', { RootID: rid, Skip: subSkipHash[rid], Take: Take }, function (res) {
          if (res.success) {
            var _data = res.data;
            if (_data.data.length) {
              subSkipHash[rid] = _data.data[_data.data.length - 1].Send_ID;
              var s = '';
              _data.data.forEach(function (item) {
                s += self.genChildComment(item);
              });
              var $ul = $message.prev();
              $ul.append(s);
              if (_data.data.length < Take) {
                $message.addClass('fn-hide');
              } else {
                $message.addClass('more').text('点击加载更多');
              }
            } else {
              $message.addClass('fn-hide');
            }
          } else {
            $message.addClass('more').text(res.message || util.ERROR_MESSAGE);
          }
        }, function (res) {
          $message.addClass('more').text(res.message || util.ERROR_MESSAGE);
        });
      });
    });
    return _this;
  }

  _createClass(Comment, [{
    key: 'switchType',
    value: function switchType(e, vd) {
      var $ul = $(vd.element);
      $ul.toggleClass('alt');
      $ul.find('li').toggleClass('cur');
    }
  }, {
    key: 'slide',
    value: function slide(e, vd, tvd) {
      var $slide = $(tvd.element);
      var $li = $slide.closest('li');
      var $list2 = $li.find('.list2');
      var $ul = $list2.find('ul');
      var $message = $list2.find('.message');
      var rid = tvd.props.rid;
      if ($slide.hasClass('on')) {
        $slide.removeClass('on');
        $list2.css('height', 0);
      } else {
        $slide.addClass('on');
        var state = subLoadHash[rid];
        if (state === HAS_LOADED || state === IS_LOADING) {
          $list2.css('height', 'auto');
        } else {
          $list2.css('height', 'auto');
          subLoadHash[rid] = IS_LOADING;
          util.postJSON('api/author/GetTocomment_T_List', { RootID: rid, Skip: -1, Take: Take }, function (res) {
            if (res.success) {
              subLoadHash[rid] = HAS_LOADED;
              var s = '';
              var data = res.data;
              data.data.forEach(function (item) {
                s += migi.createVd("li", [], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["cid", item.Send_ID], ["class", 'zan' + (item.IsLike ? ' has' : '')]], [migi.createVd("small", [], [item.LikeCount])])]), migi.createVd("div", [["class", "profile"], ["cid", item.Send_ID], ["rid", item.RootID], ["name", item.Send_UserName]], [migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name2"]], [item.Send_ToUserName]), migi.createVd("b", [["class", "arrow"]]), migi.createVd("small", [["class", "time"]], [item.Send_Time]), migi.createVd("span", [["class", "name"]], [item.Send_UserName])]), migi.createVd("p", [], [item.sign])]), migi.createVd("img", [["class", "pic"], ["src", item.Send_UserHeadUrl || 'src/common/blank.png']])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [["cid", item.Send_ID], ["rid", item.RootID], ["name", item.Send_UserName]], [item.Send_Content])])]);
              });
              $ul.html(s);
              if (data.data.length >= data.Size) {
                $message.addClass('fn-hide');
              } else {
                $message.addClass('more').text('点击加载更多');
                subSkipHash[rid] = data.data[data.data.length - 1].Send_ID;
              }
              $ul.removeClass('fn-hide');
              $list2.css('height', 'auto');
            } else {
              subLoadHash[rid] = NOT_LOADED;
              jsBridge.toast(res.message || util.ERROR_MESSAGE);
            }
          }, function (res) {
            subLoadHash[rid] = NOT_LOADED;
            jsBridge.toast(res.message || util.ERROR_MESSAGE);
          });
        }
      }
    }
  }, {
    key: 'clickZan',
    value: function clickZan(e, vd, tvd) {
      var $span = $(tvd.element);
      var CommentID = tvd.props.cid;
      util.postJSON('api/works/AddWorkCommentLike', { CommentID: CommentID }, function (res) {
        if (res.success) {
          var data = res.data;
          if (data.State === 211) {
            $span.addClass('has');
          } else {
            $span.removeClass('has');
          }
          $span.find('small').text(data.LikeCount);
        } else {
          jsBridge.toast(res.message || util.ERROR_MESSAGE);
        }
      });
    }
  }, {
    key: 'clickCmt',
    value: function clickCmt(e, vd, tvd) {
      this.emit('chooseSubComment', tvd.props.rid, tvd.props.cid, tvd.props.name);
    }
  }, {
    key: 'genComment',
    value: function genComment(item) {
      return migi.createVd("li", [["id", 'comment_' + item.Send_ID]], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "profile"], ["cid", item.Send_ID], ["rid", item.RootID], ["name", item.Send_UserName]], [migi.createVd("img", [["class", "pic"], ["src", item.Send_UserHeadUrl || 'src/common/blank.png']]), migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name"]], [item.Send_UserName]), migi.createVd("small", [["class", "time"]], [item.Send_Time])]), migi.createVd("p", [], [item.sign])])]), migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["cid", item.Send_ID], ["class", 'zan' + (item.IsLike ? ' has' : '')]], [migi.createVd("small", [], [item.LikeCount])])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [["cid", item.Send_ID], ["rid", item.RootID], ["name", item.Send_UserName]], [item.Send_Content, migi.createVd("span", [["class", "placeholder"]])]), migi.createVd("div", [["class", "slide"], ["cid", item.Send_ID], ["rid", item.RootID]], [migi.createVd("small", [], [item.sub_Count]), migi.createVd("span", [], ["收起"])])]), migi.createVd("div", [["class", "list2"]], [migi.createVd("ul", [["class", "fn-hide"]]), migi.createVd("p", [["class", "message"], ["cid", item.Send_ID], ["rid", item.Send_ID]], ["读取中..."])])]);
    }
  }, {
    key: 'addNew',
    value: function addNew(item) {
      if (this.list.length) {
        var li = this.genComment(item);
        li.prependTo(this.ref.list.element);
      } else {
        this.list.unshift(item);
        this.message = '';
      }
    }
  }, {
    key: 'addMore',
    value: function addMore(data) {
      var self = this;
      var s = '';
      data.forEach(function (item) {
        var li = self.genComment(item);
        s += li.toString();
      });
      $(self.ref.list.element).append(s);
    }
  }, {
    key: 'genChildComment',
    value: function genChildComment(item) {
      return migi.createVd("li", [], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["cid", item.Send_ID], ["class", 'zan' + (item.IsLike ? ' has' : '')]], [migi.createVd("small", [], [item.LikeCount])])]), migi.createVd("div", [["class", "profile"], ["cid", item.Send_ID], ["rid", item.RootID], ["name", item.Send_UserName]], [migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name2"]], [item.Send_ToUserName]), migi.createVd("b", [["class", "arrow"]]), migi.createVd("small", [["class", "time"]], [item.Send_Time]), migi.createVd("span", [["class", "name"]], [item.Send_UserName])]), migi.createVd("p", [], [item.sign])]), migi.createVd("img", [["class", "pic"], ["src", item.Send_UserHeadUrl || 'src/common/blank.png']])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [["cid", item.Send_ID], ["rid", item.RootID], ["name", item.Send_UserName]], [item.Send_Content])])]);
    }
  }, {
    key: 'addChild',
    value: function addChild(item) {
      var li = this.genChildComment(item);
      var $comment = $('#comment_' + item.RootID);
      var $list2 = $comment.find('.list2');
      var $ul = $list2.find('ul');
      li.prependTo($ul[0]);
      $list2.css('height', $ul.height());
      var $num = $comment.find('.slide small');
      $num.text((parseInt($num.text()) || 0) + 1);
    }
  }, {
    key: 'addMoreChild',
    value: function addMoreChild(item) {}
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "cp_comment"]], [migi.createVd("div", [["class", "bar fn-clear"]], [migi.createVd("ul", [["class", "type fn-clear"], ["onClick", new migi.Cb(this, this.switchType)]], [migi.createVd("li", [["class", "cur"]], [migi.createVd("span", [], ["最热"])]), migi.createVd("li", [], [migi.createVd("span", [], ["最新"])])])]), migi.createVd("ul", [["class", "list"], ["ref", "list"], ["onClick", [[{ ".slide": { "_v": true } }, new migi.Cb(this, this.slide)], [{ ".zan": { "_v": true } }, new migi.Cb(this, this.clickZan)], [{ "pre": { "_v": true } }, new migi.Cb(this, this.clickCmt)], [{ ".profile": { "_v": true } }, new migi.Cb(this, this.clickCmt)]]]], [new migi.Obj("list", this, function () {
        return (this.list || []).map(function (item) {
          return migi.createVd("li", [["id", 'comment_' + item.Send_ID]], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "profile"], ["cid", item.Send_ID], ["rid", item.Send_ID], ["name", item.Send_UserName]], [migi.createVd("img", [["class", "pic"], ["src", item.Send_UserHeadUrl || 'src/common/blank.png']]), migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name"]], [item.Send_UserName]), migi.createVd("small", [["class", "time"]], [item.Send_Time])]), migi.createVd("p", [], [item.sign])])]), migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["cid", item.Send_ID], ["class", 'zan' + (item.IsLike ? ' has' : '')]], [migi.createVd("small", [], [item.LikeCount])])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [["cid", item.Send_ID], ["rid", item.Send_ID], ["name", item.Send_UserName]], [item.Send_Content, migi.createVd("span", [["class", "placeholder"]])]), migi.createVd("div", [["class", "slide"], ["cid", item.Send_ID], ["rid", item.Send_ID]], [migi.createVd("small", [], [item.sub_Count]), migi.createVd("span", [], ["收起"])])]), migi.createVd("div", [["class", "list2"]], [migi.createVd("ul", [["class", "fn-hide"]]), migi.createVd("p", [["class", "message"], ["cid", item.Send_ID], ["rid", item.Send_ID]], ["读取中..."])])]);
        });
      })]), migi.createVd("p", [["class", new migi.Obj("message", this, function () {
        return 'message' + (this.message ? '' : ' fn-hide');
      })]], [new migi.Obj("message", this, function () {
        return this.message;
      })])]);
    }
  }, {
    key: 'list',
    set: function set(v) {
      this.__setBind("list", v);this.__data("list");
    },
    get: function get() {
      if (this.__initBind("list")) this.__setBind("list", []);return this.__getBind("list");
    }
  }, {
    key: 'message',
    set: function set(v) {
      this.__setBind("message", v);this.__data("message");
    },
    get: function get() {
      if (this.__initBind("message")) this.__setBind("message", '读取中...');return this.__getBind("message");
    }
  }]);

  return Comment;
}(migi.Component);

migi.name(Comment, "Comment");exports.default = Comment;

/***/ }),

/***/ 105:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _authorTemplate = __webpack_require__(9);

var _authorTemplate2 = _interopRequireDefault(_authorTemplate);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Author2 = function (_migi$Component) {
  _inherits(Author2, _migi$Component);

  function Author2() {
    var _ref;

    _classCallCheck(this, Author2);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Author2.__proto__ || Object.getPrototypeOf(Author2)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Author2, [{
    key: "setAuthor",
    value: function setAuthor(data) {
      var temp = [];
      data.forEach(function (item) {
        item.forEach(function (item2) {
          temp.push(migi.createVd("li", [["class", "label"]], [(0, _authorTemplate2.default)(item2.type).name]));
          item2.list.forEach(function (item3) {
            temp.push(migi.createVd("li", [["class", "item"], ["id", item3.ID]], [item3.AuthName]));
          });
        });
      });
      this.list = temp;
      var $c = $(this.ref.c.element);
      var $ul = $c.find('ul');
      $c.css('width', $ul.width() + 1);
    }
  }, {
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "author2"]], [migi.createVd("div", [["class", "c"], ["ref", "c"]], [migi.createVd("ul", [], [new migi.Obj("list", this, function () {
        return this.list;
      })])])]);
    }
  }, {
    key: "list",
    set: function set(v) {
      this.__setBind("list", v);this.__data("list");
    },
    get: function get() {
      if (this.__initBind("list")) this.__setBind("list", []);return this.__getBind("list");
    }
  }]);

  return Author2;
}(migi.Component);

migi.name(Author2, "Author2");exports.default = Author2;

/***/ }),

/***/ 106:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(83);

__webpack_require__(76);

var _animaQuerystring = __webpack_require__(0);

var _animaQuerystring2 = _interopRequireDefault(_animaQuerystring);

var _Media = __webpack_require__(61);

var _Media2 = _interopRequireDefault(_Media);

var _WorkType = __webpack_require__(41);

var _WorkType2 = _interopRequireDefault(_WorkType);

var _Video = __webpack_require__(25);

var _Video2 = _interopRequireDefault(_Video);

var _Audio = __webpack_require__(24);

var _Audio2 = _interopRequireDefault(_Audio);

var _Image = __webpack_require__(57);

var _Image2 = _interopRequireDefault(_Image);

var _Link = __webpack_require__(60);

var _Link2 = _interopRequireDefault(_Link);

var _Intro = __webpack_require__(59);

var _Intro2 = _interopRequireDefault(_Intro);

var _PlayList = __webpack_require__(62);

var _PlayList2 = _interopRequireDefault(_PlayList);

var _WorkComment = __webpack_require__(63);

var _WorkComment2 = _interopRequireDefault(_WorkComment);

var _ImageView = __webpack_require__(58);

var _ImageView2 = _interopRequireDefault(_ImageView);

var _itemTemplate = __webpack_require__(27);

var _itemTemplate2 = _interopRequireDefault(_itemTemplate);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var search = _animaQuerystring2.default.parse(location.search.replace(/^\?/, ''));
var id = search.id;

jsBridge.ready(function () {
  var media = migi.render(migi.createCp(_Media2.default, []), document.body);

  // let medias = migi.render(
  //   <div class="medias">
  //     <div class="c"/>
  //   </div>,
  //   document.body
  // );
  // let mediasC = medias.find('.c');
  // let $mediasC = $(mediasC.element);
  // let video, audio, image, link;
  // let mediasList = [];
  // let mediaSwitch = medias.find(MediaSwitch);
  // mediaSwitch.on('change', function(i) {
  //   let x = i * winWidth;
  //   $mediasC.css('-webkit-transform', `translate3d(${-x}px,0,0)`);
  //   $mediasC.css('transform', `translate3d(${-x}px,0,0)`);
  //   mediasList[i].show();
  // });
  // let medias = migi.render(
  //   <div class="medias">
  //     <div class="c">
  //       <Video/>
  //       <Audio/>
  //       <Image images={ images }/>
  //       <Link/>
  //     </div>
  //     <MediaSwitch/>
  //   </div>,
  //   document.body
  // );
  // let $mediasC = $(medias.element).children('.c');
  // let video = medias.find(Video);
  // video.on('playing', function() {
  //   menu.hide();
  // });
  // video.on('pause', function() {
  // });
  // let audio = medias.find(Audio);
  // let image = medias.find(Image);
  // let mediaSwitch = medias.find(MediaSwitch);
  // mediaSwitch.on('change', function(i) {
  //   let x = i * winWidth;
  //   $mediasC.css('-webkit-transform', `translate3d(${-x}px,0,0)`);
  //   $mediasC.css('transform', `translate3d(${-x}px,0,0)`);
  // });
  // // mediaSwitch.emit('change', 3);
  // let imageView = migi.render(
  //   <ImageView images={ images }/>,
  //   document.body
  // );
  // image.on('show', function(i) {
  //   imageView.show(i);
  // });

  var intro = migi.render(migi.createCp(_Intro2.default, []), document.body);
  var workComment = migi.render(migi.createCp(_WorkComment2.default, [["workId", id]]), document.body);
  media.on('tagChange', function (i) {
    intro && intro.hide();
    workComment && workComment.hide();
    switch (i) {
      case '0':
        intro.show();
        break;
      case '1':
        workComment.show();
        break;
    }
  });
  // media.emit('tagChange', '1');

  if (id) {
    util.postJSON('api/works/GetWorkDetails', { WorksID: id }, function (res) {
      if (res.success) {
        var data = res.data;

        jsBridge.setTitle(data.Title);
        jsBridge.setSubTitle(data.sub_Title || '小标题');

        media.setCover(data.cover_Pic);
        media.setWorks(data.Works_Items);
        media.popular = data.Popular;

        intro.tags = data.ReturnTagData || [];

        return;

        var workHash = {};
        var workList = [];

        data.Works_Items.forEach(function (item) {
          // 先按每个小作品类型排序其作者
          util.sort(item.Works_Item_Author, (0, _itemTemplate2.default)(item.ItemType).authorSort || function () {});
          // 将每个小作品根据小类型映射到大类型上，再归类
          var bigType = (0, _itemTemplate2.default)(item.ItemType).bigType;
          workHash[bigType] = workHash[bigType] || [];
          workHash[bigType].push(item);
        });

        Object.keys(workHash).forEach(function (k) {
          workList.push({
            bigType: k,
            value: workHash[k]
          });
        });
        util.sort(workList, function (a, b) {
          var aw = _WorkType2.default.Weight[a.bigType] || 0;
          var bw = _WorkType2.default.Weight[b.bigType] || 0;
          return aw < bw;
        });

        var count = 0;
        var authorList = [];
        workList.forEach(function (works) {
          var authors = [];
          works.value.forEach(function (work) {
            authors = authors.concat(work.Works_Item_Author);
          });
          // 去重
          var hash = {};
          for (var i = 0; i < authors.length; i++) {
            var author = authors[i];
            var key = author.ID + ',' + author.WorksAuthorType;
            if (hash[key]) {
              authors.splice(i--, 1);
              continue;
            } else {
              hash[key] = true;
            }
          }
          // 合并
          hash = {};
          var nAuthors = [];
          authors.forEach(function (author) {
            if (hash.hasOwnProperty(author.WorksAuthorType)) {
              nAuthors[hash[author.WorksAuthorType]].list.push(author);
            } else {
              hash[author.WorksAuthorType] = nAuthors.length;
              nAuthors.push({
                type: author.WorksAuthorType,
                list: [author]
              });
            }
          });
          authorList.push(nAuthors);
          // 按顺序放置媒体类型
          if (works.bigType == _WorkType2.default.Type.AUDIO) {
            var audioList = works.value.map(function (work) {
              return work.FileUrl;
            });
            audio = migi.render(migi.createCp(_Audio2.default, [["data", audioList]]), mediasC.element);
            mediasList.push(audio);
            count++;
          } else if (works.bigType == _WorkType2.default.Type.VIDEO) {
            var videoList = works.value.map(function (work) {
              return work.FileUrl;
            });
            video = migi.render(migi.createCp(_Video2.default, [["data", videoList]]), mediasC.element);
            mediasList.push(video);
            count++;
          }
        });

        // authors.setAuthor(authorList);
        authors.setAuthor(authorList);
        media.ref.authors.setAuthor(authorList);

        count = Math.max(1, count);
        $mediasC.css('width', count * 100 + '%');

        intro.tags = data.ReturnTagData || [];

        // return;
        //
        // let authorsList = [];
        // let linksList = [];
        //
        // function addAuthor(type, data) {
        //   if (data && data.length) {
        //     let arr = {
        //       type,
        //       list: []
        //     };
        //     data.forEach(function (author) {
        //       arr.list.push({
        //         id: author.ID,
        //         name: author.AuthName,
        //         img: author.HeadUrl,
        //       });
        //     });
        //     authorsList.push(arr);
        //   }
        // }
        //
        // if (data.Works_Music && data.Works_Music.length) {
        //   data.Works_Music.forEach(function (item) {
        //     addAuthor('歌手', item.Works_Music_Siger);
        //     addAuthor('作词', item.Works_Music_Lyricist);
        //     addAuthor('策划', item.Works_Music_Arrange);
        //     addAuthor('混音', item.Works_Music_Mixer);
        //     addAuthor('压缩', item.Works_Music_Composer);
        //
        //     if(item._5SingUrl) {
        //       linksList.push({
        //         type: '5sing',
        //         url: item._5SingUrl
        //       });
        //     }
        //   });
        //
        //   audio = migi.render(
        //     <Audio data={ data.Works_Music }/>,
        //     mediasC.element
        //   );
        //   if(count++ == 0) {
        //     audio.show();
        //   }
        //   mediasList.push(audio);
        // }
        //
        // if (authorsList.length) {
        //   authors.setAuthor(authorsList);
        // }
        // if(linksList.length) {
        //   link = migi.render(
        //     <Link data={ linksList }/>,
        //     mediasC.element
        //   );
        //   if(count++ == 0) {
        //     link.show();
        //   }
        //   mediasList.push(link);
        // }
        //
        // let width = Math.max(1, count);
        // $mediasC.css('width', width * 100 + '%');
        // mediaSwitch.init(mediasList);
        //
        // intro.tags = data.Tags || [];
      }
    });
  }
});

/***/ }),

/***/ 24:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var last = void 0;

var Audio = function (_migi$Component) {
  _inherits(Audio, _migi$Component);

  function Audio() {
    var _ref;

    _classCallCheck(this, Audio);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Audio.__proto__ || Object.getPrototypeOf(Audio)).call.apply(_ref, [this].concat(data)));

    _this.data = _this.props.data;
    _this.isLike = _this.data[0].ISLike;
    return _this;
  }

  _createClass(Audio, [{
    key: 'show',
    value: function show() {
      $(this.element).removeClass('fn-hide');
    }
  }, {
    key: 'hide',
    value: function hide() {
      $(this.element).addClass('fn-hide');
    }
  }, {
    key: 'timeupdate',
    value: function timeupdate(e) {
      this.emit('timeupdate', e.target.currentTime);
    }
  }, {
    key: 'loadedmetadata',
    value: function loadedmetadata(e) {
      var duration = e.target.duration;
      this.emit('loadedmetadata', {
        duration: duration
      });
    }
  }, {
    key: 'play',
    value: function play() {
      this.ref.audio.element.play();
    }
  }, {
    key: 'pause',
    value: function pause() {
      this.ref.audio.element.pause();
    }
  }, {
    key: 'currentTime',
    value: function currentTime(t) {
      this.ref.audio.element.currentTime = t;
    }
  }, {
    key: 'clickLike',
    value: function clickLike() {
      var self = this;
      if (last) {
        last.abort();
      }
      last = util.postJSON('api/works/AddLikeBehavior', { WorkItemsID: self.data[self.workIndex].ItemID }, function (res) {
        if (res.success) {
          self.isLike = res.data === 211;
        } else {
          jsBridge.toast(res.message || util.ERROR_MESSAGE);
        }
      }, function () {
        jsBridge.toast(res.message || util.ERROR_MESSAGE);
      });
    }
  }, {
    key: 'clickDownload',
    value: function clickDownload() {
      jsBridge.openUri(this.data[0].FileUrl);
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "audio"]], [migi.createVd("audio", [["ref", "audio"], ["onTimeupdate", new migi.Cb(this, this.timeupdate)], ["onLoadedmetadata", new migi.Cb(this, this.loadedmetadata)], ["preload", "meta"], ["src", this.data[0].FileUrl]], ["\
        your browser does not support the audio tag\
      "]), migi.createVd("ul", [["class", "btn"]], [migi.createVd("li", [["class", new migi.Obj("isLike", this, function () {
        return 'like' + (this.isLike ? ' is' : '');
      })], ["onClick", new migi.Cb(this, this.clickLike)]]), migi.createVd("li", [["class", "download"], ["onClick", new migi.Cb(this, this.clickDownload)]]), migi.createVd("li", [["class", "share"]]), migi.createVd("li", [["class", "origin"]])])]);
    }
  }, {
    key: 'isLike',
    set: function set(v) {
      this.__setBind("isLike", v);this.__data("isLike");
    },
    get: function get() {
      return this.__getBind("isLike");
    }
  }, {
    key: 'workIndex',
    set: function set(v) {
      this.__setBind("workIndex", v);this.__data("workIndex");
    },
    get: function get() {
      if (this.__initBind("workIndex")) this.__setBind("workIndex", 0);return this.__getBind("workIndex");
    }
  }]);

  return Audio;
}(migi.Component);

migi.name(Audio, "Audio");exports.default = Audio;

/***/ }),

/***/ 25:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Video = function (_migi$Component) {
  _inherits(Video, _migi$Component);

  function Video() {
    var _ref;

    _classCallCheck(this, Video);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Video.__proto__ || Object.getPrototypeOf(Video)).call.apply(_ref, [this].concat(data)));

    var self = _this;
    self.on(migi.Event.DOM, function () {
      var video = self.video = self.ref.video.element;
      var interval = setInterval(function () {
        if (video.readyState > 0) {
          clearInterval(interval);
          // console.log(video.readyState, video.duration);
        }
      }, 200);

      video.addEventListener('x5videoenterfullscreen', function () {
        self.emit('playing');
      });
      video.addEventListener('x5videoexitfullscreen', function () {
        self.emit('pause');
      });
      video.addEventListener('play', function () {});
      video.addEventListener('playing', function () {
        self.emit('playing');
      });
      video.addEventListener('pause', function () {
        self.emit('pause');
      });
    });
    return _this;
  }

  _createClass(Video, [{
    key: 'playing',
    value: function playing(e) {
      // $(this.ref.switch.element).hide();
    }
  }, {
    key: 'pause',
    value: function pause() {
      // let video = this.ref.video.element;
      // $(video).hide();
    }
  }, {
    key: 'loadedmetadata',
    value: function loadedmetadata(e) {
      var video = this.video;
      if (video.readyState > 0) {
        // console.log(video.readyState, video.duration);
      }
    }
  }, {
    key: 'togglePlay',
    value: function togglePlay(e, vd) {
      var $vd = $(vd.element);
      if ($vd.hasClass('pause')) {
        this.video.pause();
      } else {
        this.video.play();
      }
      $vd.toggleClass('pause');
    }
  }, {
    key: 'show',
    value: function show() {
      var $root = $(this.element);
      if ($root.hasClass('fn-hide')) {
        $root.removeClass('fn-hide');
      }
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "video"]], [migi.createVd("video", [["onPlaying", new migi.Cb(this, this.playing)], ["onPause", new migi.Cb(this, this.pause)], ["onLoadedmetadata", new migi.Cb(this, this.loadedmetadata)], ["ref", "video"], ["preload", "meta"], ["playsinline", "true"], ["webkit-playsinline", "true"], ["src", this.props.data[0].FileUrl]], ["\
        your browser does not support the video tag\
      "])]);
    }
  }]);

  return Video;
}(migi.Component);

migi.name(Video, "Video");exports.default = Video;

/***/ }),

/***/ 27:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (workType) {
  switch (workType) {
    case 1111:
      var weight = [111, 151, 112, 113, 114, 411, 121, 122, 123, 131, 132, 133, 134, 135, 141];
      return {
        bigType: 'audio',
        authorSort: function authorSort(a, b) {
          return weight.indexOf(a.WorksAuthorType) > weight.indexOf(b.WorksAuthorType);
        }
      };
    case 2222:
      return {
        bigType: 'video'
      };
    default:
      return {};
  }
};

; /**
   * Created by army8735 on 2017/8/13.
   */

/***/ }),

/***/ 3:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// QueryString
// ---------------
// This module provides utilities for dealing with query strings.
//
// Thanks to:
//  - http://nodejs.org/docs/v0.4.7/api/querystring.html
//  - http://developer.yahoo.com/yui/3/api/QueryString.html
//  - https://github.com/lifesinger/dew/tree/master/lib/querystring


// var QueryString = exports;

var QueryString = {};

// The escape/unescape function used by stringify/parse, provided so that it
// could be overridden if necessary. This is important in cases where
// non-standard delimiters are used, if the delimiters would not normally be
// handled properly by the built-in (en|de)codeURIComponent functions.
QueryString.escape = encodeURIComponent;

QueryString.unescape = function (s) {
    // The + character is interpreted as a space on the server side as well as
    // generated by forms with spaces in their fields.
    return decodeURIComponent(s.replace(/\+/g, ' '));
};

/**
 * Serialize an object to a query string. Optionally override the default
 * separator and assignment characters.
 *
 * stringify({foo: 'bar'})
 *   // returns 'foo=bar'
 *
 * stringify({foo: 'bar', baz: 'bob'}, ';', ':')
 *   // returns 'foo:bar;baz:bob'
 */
QueryString.stringify = function (obj, sep, eq, arrayKey) {
    if (!isPlainObject(obj)) return '';

    sep = sep || '&';
    eq = eq || '=';
    arrayKey = arrayKey || false;

    var buf = [],
        key,
        val;
    var escape = QueryString.escape;

    for (key in obj) {
        if (!hasOwnProperty.call(obj, key)) continue;

        val = obj[key];
        key = QueryString.escape(key);

        // val is primitive value
        if (isPrimitive(val)) {
            buf.push(key, eq, escape(val + ''), sep);
        }
        // val is not empty array
        else if (isArray(val) && val.length) {
                for (var i = 0; i < val.length; i++) {
                    if (isPrimitive(val[i])) {
                        buf.push(key, (arrayKey ? escape('[]') : '') + eq, escape(val[i] + ''), sep);
                    }
                }
            }
            // ignore other cases, including empty array, Function, RegExp, Date etc.
            else {
                    buf.push(key, eq, sep);
                }
    }

    buf.pop();
    return buf.join('');
};

/**
 * Deserialize a query string to an object. Optionally override the default
 * separator and assignment characters.
 *
 * parse('a=b&c=d')
 *   // returns {a: 'b', c: 'c'}
 */
QueryString.parse = function (str, sep, eq) {
    var ret = {};

    if (typeof str !== 'string' || trim(str).length === 0) {
        return ret;
    }

    var pairs = str.split(sep || '&');
    eq = eq || '=';
    var unescape = QueryString.unescape;

    for (var i = 0; i < pairs.length; i++) {

        var pair = pairs[i].split(eq);
        var key = unescape(trim(pair[0]));
        var val = unescape(trim(pair.slice(1).join(eq)));

        var m = key.match(/^(\w+)\[\]$/);
        if (m && m[1]) {
            key = m[1];
        }

        if (hasOwnProperty.call(ret, key)) {
            if (!isArray(ret[key])) {
                ret[key] = [ret[key]];
            }
            ret[key].push(val);
        } else {
            ret[key] = m ? [val] : val;
        }
    }

    return ret;
};

// Helpers

var toString = Object.prototype.toString;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var isArray = Array.isArray || function (val) {
    return toString.call(val) === '[object Array]';
};
var trim = String.prototype.trim ? function (str) {
    return str == null ? '' : String.prototype.trim.call(str);
} : function (str) {
    return str == null ? '' : str.toString().replace(/^\s+/, '').replace(/\s+$/, '');
};

/**
 * Checks to see if an object is a plain object (created using "{}" or
 * "new Object()" or "new FunctionClass()").
 */
function isPlainObject(o) {
    /**
     * NOTES:
     * isPlainObject(node = document.getElementById("xx")) -> false
     * toString.call(node):
     *   ie678 === '[object Object]', other === '[object HTMLElement]'
     * 'isPrototypeOf' in node:
     *   ie678 === false, other === true
     */
    return o && toString.call(o) === '[object Object]' && 'isPrototypeOf' in o;
}

/**
 * If the type of o is null, undefined, number, string, boolean,
 * return true.
 */
function isPrimitive(o) {
    return o !== Object(o);
}

module.exports = QueryString;

/***/ }),

/***/ 41:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var TypeHash = {
  1111: 'audio',
  2222: 'video'
};

var Type = {
  AUDIO: 'audio',
  VIDEO: 'video'
};

var Weight = {
  'audio': 10,
  'video': 9
};

exports.default = {
  TypeHash: TypeHash,
  Type: Type,
  Weight: Weight
};

/***/ }),

/***/ 57:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var isStart = void 0;
var isMove = void 0;
var startX = void 0;
var startY = void 0;

var Image = function (_migi$Component) {
  _inherits(Image, _migi$Component);

  function Image() {
    var _ref;

    _classCallCheck(this, Image);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Image.__proto__ || Object.getPrototypeOf(Image)).call.apply(_ref, [this].concat(data)));

    var datas = _this.props.images;
    _this.on(migi.Event.DOM, function () {
      var $list = $(this.ref.list.element);
      var imgs = this.ref.imgs;
      var $imgs = $list.find('.imgs');
      var height = Math.floor($imgs.height());
      datas.forEach(function (item, i) {
        var img = migi.createVd("img", [["index", i], ["src", item], ["style", "width:" + height + "px"]]);
        img.appendTo(imgs);
      });
      $list.css('width', (height + 2) * datas.length + 2);
    });
    return _this;
  }

  _createClass(Image, [{
    key: "start",
    value: function start(e) {
      if (e.touches.length != 1) {
        isStart = false;
      } else {
        isStart = true;
        startX = e.touches[0].pageX;
        startY = e.touches[0].pageY;
      }
    }
  }, {
    key: "end",
    value: function end() {
      jsBridge.swipeRefresh(true);
    }
  }, {
    key: "click",
    value: function click(e, vd, tvd) {
      this.emit('show', tvd.props.index);
    }
  }, {
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "image"], ["onTouchStart", new migi.Cb(this, this.start)], ["onTouchEnd", new migi.Cb(this, this.end)], ["onTouchCancel", new migi.Cb(this, this.end)]], [migi.createVd("div", [["class", "list"], ["ref", "list"]], [migi.createVd("div", [["class", "imgs"], ["ref", "imgs"], ["onClick", [[{ "img": { "_v": true } }, new migi.Cb(this, this.click)]]]])])]);
    }
  }]);

  return Image;
}(migi.Component);

migi.name(Image, "Image");exports.default = Image;

/***/ }),

/***/ 58:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var winWidth = $(window).width();

var ImageView = function (_migi$Component) {
  _inherits(ImageView, _migi$Component);

  function ImageView() {
    var _ref;

    _classCallCheck(this, ImageView);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = ImageView.__proto__ || Object.getPrototypeOf(ImageView)).call.apply(_ref, [this].concat(data)));

    var datas = _this.props.images;
    _this.length = datas.length;
    _this.on(migi.Event.DOM, function () {
      var list = this.ref.list.element;
      var $list = this.$list = $(list);
      datas.forEach(function (item, i) {
        var img = migi.createVd("img", [["index", i], ["src", item], ["style", "width:" + winWidth + "px;height:" + winWidth + "px"]]);
        img.appendTo(list);
      });
    });
    return _this;
  }

  _createClass(ImageView, [{
    key: "move",
    value: function move(e) {
      e.preventDefault();
    }
  }, {
    key: "left",
    value: function left() {
      if (this.index < this.length - 1) {
        this.index++;
        this.$list.css('-webkit-transform', "translate3d(-" + this.index * winWidth + "px,0,0)");
        this.$list.css('transform', "translate3d(-" + this.index * winWidth + "px,0,0)");
      }
    }
  }, {
    key: "right",
    value: function right() {
      if (this.index > 0) {
        this.index--;
        this.$list.css('-webkit-transform', "translate3d(-" + this.index * winWidth + "px,0,0)");
        this.$list.css('transform', "translate3d(-" + this.index * winWidth + "px,0,0)");
      }
    }
  }, {
    key: "show",
    value: function show(i) {
      this.index = i;
      this.$list.css('-webkit-transform', "translate3d(-" + this.index * winWidth + "px,0,0)");
      this.$list.css('transform', "translate3d(-" + this.index * winWidth + "px,0,0)");
      $(this.element).show();
      jsBridge.swipeRefresh(false);
    }
  }, {
    key: "click",
    value: function click() {
      $(this.element).hide();
      jsBridge.swipeRefresh(true);
    }
  }, {
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "image_view"], ["onTouchmove", new migi.Cb(this, this.move)], ["onSwipeLeft", new migi.Cb(this, this.left)], ["onSwipeRight", new migi.Cb(this, this.right)], ["onClick", new migi.Cb(this, this.click)]], [migi.createVd("div", [["class", "num"]], [new migi.Obj("index", this, function () {
        return this.index + 1;
      }), "/", new migi.Obj("length", this, function () {
        return this.length;
      })]), migi.createVd("div", [["class", "list fn-clear"], ["ref", "list"], ["style", "width:" + this.length + "00%;"]])]);
    }
  }, {
    key: "index",
    set: function set(v) {
      this.__setBind("index", v);this.__data("index");
    },
    get: function get() {
      if (this.__initBind("index")) this.__setBind("index", 0);return this.__getBind("index");
    }
  }, {
    key: "length",
    set: function set(v) {
      this.__setBind("length", v);this.__data("length");
    },
    get: function get() {
      if (this.__initBind("length")) this.__setBind("length", 0);return this.__getBind("length");
    }
  }]);

  return ImageView;
}(migi.Component);

migi.name(ImageView, "ImageView");exports.default = ImageView;

/***/ }),

/***/ 59:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Intro = function (_migi$Component) {
  _inherits(Intro, _migi$Component);

  function Intro() {
    var _ref;

    _classCallCheck(this, Intro);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Intro.__proto__ || Object.getPrototypeOf(Intro)).call.apply(_ref, [this].concat(data)));

    _this.on(migi.Event.DOM, function () {
      this.autoWidth();
    });
    return _this;
  }

  _createClass(Intro, [{
    key: 'autoWidth',
    value: function autoWidth() {
      var $timeline = $(this.ref.timeline.element);
      var $line = $timeline.find('.line');
      var $c = $timeline.find('.c');
      var $ul = $c.find('ul');
      var width = $ul.width() + 1;
      $c.css('width', width);
      $line.css('width', width + 10);

      var $inspiration = $(this.ref.inspiration.element);
      $inspiration.children('li').each(function (i, item) {
        var $li = $(item);
        var $placeholder = $li.find('.placeholder');
        var $slide = $li.find('.slide');
        $placeholder.css('width', $slide.width());
      });
    }
  }, {
    key: 'slide',
    value: function slide(e, vd, tvd) {
      var $slide = $(tvd.element);
      var $li = $slide.closest('li');
      var $list2 = $li.find('.list2');
      var $ul = $list2.find('ul');
      if ($slide.hasClass('on')) {
        $slide.removeClass('on');
        $list2.css('height', 0);
      } else {
        $slide.addClass('on');
        $list2.css('height', $ul.height());
      }
    }
  }, {
    key: 'show',
    value: function show() {
      $(this.element).show();
    }
  }, {
    key: 'hide',
    value: function hide() {
      $(this.element).hide();
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "intro"]], [migi.createVd("div", [["class", "tag"]], [migi.createVd("ul", [["class", "fn-clear"]], [new migi.Obj("tags", this, function () {
        return this.tags.map(function (item) {
          if (item.blank) {
            return migi.createVd("li", [["class", "blank"]], [migi.createVd("a", [["href", "#"]], ["..."])]);
          }
          return migi.createVd("li", [], [migi.createVd("a", [["href", '#' + item.Tag_ID]], [item.Tag_Name])]);
        });
      })])]), migi.createVd("div", [["class", "timeline"], ["ref", "timeline"]], [migi.createVd("b", [["class", "line"]]), migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [], [migi.createVd("li", [], [migi.createVd("span", [], ["发布"]), migi.createVd("small", [], ["2017年1月1日"])])])])]), migi.createVd("div", [["class", "inspiration"], ["ref", "inspiration"], ["onClick", [[{ ".slide": { "_v": true } }, new migi.Cb(this, this.slide)]]]], [migi.createVd("h3", [], [migi.createVd("span", [], ["创作灵感"]), migi.createVd("small", [["class", "add"]], ["添加"])]), migi.createVd("ul", [["class", "list"]], [migi.createVd("li", [], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "profile"]], [migi.createVd("img", [["class", "pic"], ["src", "http://bbs.xiguo.net/zq/zz/02.png"]]), migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name"]], ["司夏"]), migi.createVd("small", [["class", "time"]], ["昨天 18:08"])]), migi.createVd("p", [], ["努力战胜拖延症"])])]), migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["class", "zan"]], [migi.createVd("small", [], ["56"])])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [], ["非常开心可以和沈行之合作！", migi.createVd("span", [["class", "placeholder"]], [])]), migi.createVd("div", [["class", "slide"]], [migi.createVd("small", [], []), migi.createVd("span", [], ["收起"])])]), migi.createVd("div", [["class", "list2"]], [migi.createVd("ul", [], ["\
              "])])]), migi.createVd("li", [], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "profile"]], [migi.createVd("img", [["class", "pic"], ["src", "http://bbs.xiguo.net/zq/zz/01.jpg"]]), migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name"]], ["沈行之"]), migi.createVd("small", [["class", "time"]], ["昨天 12:08"])]), migi.createVd("p", [], ["沈不行"])])]), migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["class", "zan has"]], [migi.createVd("small", [], ["33"])])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [], ["特别特别荣幸可以写这首歌，强烈推荐大家去看这部动画，真的特别好看！", migi.createVd("span", [["class", "placeholder"]], [])]), migi.createVd("div", [["class", "slide"]], [migi.createVd("small", [], ["2"]), migi.createVd("span", [], ["收起"])])]), migi.createVd("div", [["class", "list2"]], [migi.createVd("ul", [], [migi.createVd("li", [], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["class", "zan has"]], [migi.createVd("small", [], ["123"])])]), migi.createVd("div", [["class", "profile"]], [migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name2"]], ["沈行之"]), migi.createVd("b", [["class", "arrow"]]), migi.createVd("small", [["class", "time"]], ["1小时前"]), migi.createVd("span", [["class", "name"]], ["海妖小马甲"])]), migi.createVd("p", [], ["我是个马甲"])]), migi.createVd("img", [["class", "pic"], ["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [], ["阿沈你好"])])]), migi.createVd("li", [], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["class", "zan has"]], [migi.createVd("small", [], ["123"])])]), migi.createVd("div", [["class", "profile"]], [migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name2"]], ["海妖小马甲"]), migi.createVd("b", [["class", "arrow"]]), migi.createVd("small", [["class", "time"]], ["3分钟前"]), migi.createVd("span", [["class", "name"]], ["阿侎"])]), migi.createVd("p", [], ["army8735"])]), migi.createVd("img", [["class", "pic"], ["src", "http://tva4.sinaimg.cn/crop.7.1.129.129.180/64319a89gw1f62p9lp7hyj203w03wq2x.jpg"]])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [], ["捕捉一只海妖"])])])])])])])])]);
    }
  }, {
    key: 'tags',
    set: function set(v) {
      this.__setBind("tags", v);this.__data("tags");
    },
    get: function get() {
      if (this.__initBind("tags")) this.__setBind("tags", []);return this.__getBind("tags");
    }
  }]);

  return Intro;
}(migi.Component);

migi.name(Intro, "Intro");exports.default = Intro;

/***/ }),

/***/ 60:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Link = function (_migi$Component) {
  _inherits(Link, _migi$Component);

  function Link() {
    var _ref;

    _classCallCheck(this, Link);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Link.__proto__ || Object.getPrototypeOf(Link)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Link, [{
    key: "show",
    value: function show() {
      $(this.element).removeClass('fn-hide');
    }
  }, {
    key: "click",
    value: function click(e, vd, tvd) {
      e.preventDefault();
      jsBridge.pushWindow(tvd.props.href, {
        titleBar: 1,
        showBack: true
      });
    }
  }, {
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "link fn-hide"]], [migi.createVd("ul", [["onClick", [[{ "a": { "_v": true } }, new migi.Cb(this, this.click)]]]], [(this.props.data || []).map(function (item) {
        return migi.createVd("li", [["class", item.type]], [migi.createVd("a", [["href", item.url]], [item.type])]);
      })])]);
    }
  }]);

  return Link;
}(migi.Component);

migi.name(Link, "Link");exports.default = Link;

/***/ }),

/***/ 61:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _itemTemplate = __webpack_require__(27);

var _itemTemplate2 = _interopRequireDefault(_itemTemplate);

var _Author = __webpack_require__(105);

var _Author2 = _interopRequireDefault(_Author);

var _Audio = __webpack_require__(24);

var _Audio2 = _interopRequireDefault(_Audio);

var _Video = __webpack_require__(25);

var _Video2 = _interopRequireDefault(_Video);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var WIDTH = $(window).width();
var currentTime = 0;
var duration = 0;
var isStart = void 0;
var isMove = void 0;

var audio = void 0;

var Media = function (_migi$Component) {
  _inherits(Media, _migi$Component);

  function Media() {
    var _ref;

    _classCallCheck(this, Media);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Media.__proto__ || Object.getPrototypeOf(Media)).call.apply(_ref, [this].concat(data)));

    var WIDTH = $(window).width();
    var style = document.createElement('style');
    style.innerText = 'body>.media>.c{height:' + WIDTH / 16 * 9 + 'px}';
    document.head.appendChild(style);
    return _this;
  }

  _createClass(Media, [{
    key: 'setCover',
    value: function setCover(url) {
      $(this.element).css('background-image', 'url(' + url + ')');
    }
  }, {
    key: 'setWorks',
    value: function setWorks(works) {
      var self = this;
      var workHash = {};
      var workList = [];
      var authorList = [];
      var mediaList = [];
      works.forEach(function (item) {
        // 先按每个小作品类型排序其作者
        util.sort(item.Works_Item_Author, (0, _itemTemplate2.default)(item.ItemType).authorSort || function () {});
        // 将每个小作品根据小类型映射到大类型上，再归类
        var bigType = (0, _itemTemplate2.default)(item.ItemType).bigType;
        workHash[bigType] = workHash[bigType] || [];
        workHash[bigType].push(item);
      });
      Object.keys(workHash).forEach(function (k) {
        workList.push({
          bigType: k,
          value: workHash[k]
        });
      });
      util.sort(workList, function (a, b) {
        return a.bigType > b.bigType;
      });
      workList.forEach(function (works) {
        var authors = [];
        works.value.forEach(function (work) {
          authors = authors.concat(work.Works_Item_Author);
        });
        // 去重
        var hash = {};
        for (var i = 0; i < authors.length; i++) {
          var author = authors[i];
          var key = author.ID + ',' + author.WorksAuthorType;
          if (hash[key]) {
            authors.splice(i--, 1);
            continue;
          } else {
            hash[key] = true;
          }
        }
        // 合并
        hash = {};
        var nAuthors = [];
        authors.forEach(function (author) {
          if (hash.hasOwnProperty(author.WorksAuthorType)) {
            nAuthors[hash[author.WorksAuthorType]].list.push(author);
          } else {
            hash[author.WorksAuthorType] = nAuthors.length;
            nAuthors.push({
              type: author.WorksAuthorType,
              list: [author]
            });
          }
        });
        authorList.push(nAuthors);
      });
      self.ref.author.setAuthor(authorList);

      workList.forEach(function (item) {
        if (item.bigType === 'audio') {
          // let fileList = item.value.map(function(item2) {
          //   return item2.FileUrl;
          // });
          audio = migi.render(migi.createCp(_Audio2.default, [["data", item.value]]), self.ref.c.element);
          audio.on('timeupdate', function (data) {
            currentTime = data;
            var percent = currentTime / duration;
            self.setBarPercent(percent);
          });
          audio.on('loadedmetadata', function (data) {
            duration = data.duration;
            self.canControl = true;
          });
        }
      });
      // this.workList = workList;
    }
  }, {
    key: 'clickTag',
    value: function clickTag(e, vd, tvd) {
      var $ul = $(vd.element);
      var $li = $(tvd.element);
      if (!$li.hasClass('cur')) {
        $ul.find('.cur').removeClass('cur');
        $li.addClass('cur');
        this.emit('tagChange', tvd.props.rel);
      }
    }
  }, {
    key: 'clickPlay',
    value: function clickPlay(e, vd) {
      var $play = $(vd.element);
      if ($play.hasClass('pause')) {
        audio.pause();
      } else {
        audio.play();
      }
      $play.toggleClass('pause');
    }
  }, {
    key: 'clickProgress',
    value: function clickProgress(e) {
      if (e.target.className !== 'point') {
        var x = e.pageX;
        var percent = x / WIDTH;
        var _currentTime = Math.floor(duration * percent);
        audio.currentTime(_currentTime);
      }
    }
  }, {
    key: 'start',
    value: function start(e) {
      if (e.touches.length === 1) {
        isStart = true;
        audio.pause();
        $(this.ref.play.element).removeClass('pause');
      }
    }
  }, {
    key: 'move',
    value: function move(e) {
      if (isStart) {
        isMove = true;
        e.preventDefault();
        var x = e.touches[0].pageX;
        var percent = x / WIDTH;
        this.setBarPercent(percent);
        currentTime = Math.floor(duration * percent);
      }
    }
  }, {
    key: 'end',
    value: function end() {
      if (isMove) {
        audio.currentTime(currentTime);
      }
      isStart = isMove = false;
    }
  }, {
    key: 'setBarPercent',
    value: function setBarPercent(percent) {
      percent *= 100;
      $(this.ref.has.element).css('width', percent + '%');
      $(this.ref.pgb.element).css('-webkit-transform', 'translate3d(' + percent + '%,0,0)');
      $(this.ref.pgb.element).css('transform', 'translate3d(' + percent + '%,0,0)');
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "media"]], [migi.createCp(_Author2.default, [["ref", "author"]]), migi.createVd("div", [["class", "c"], ["ref", "c"]], [migi.createVd("span", [["class", "popular"]], [new migi.Obj("popular", this, function () {
        return this.popular;
      })])]), migi.createVd("div", [["class", new migi.Obj("canControl", this, function () {
        return 'progress' + (this.canControl ? '' : ' dis');
      })], ["onClick", new migi.Cb(this, this.clickProgress)]], [migi.createVd("div", [["class", "has"], ["ref", "has"]]), migi.createVd("div", [["class", "pbg"], ["ref", "pgb"]], [migi.createVd("div", [["class", "point"], ["ref", "point"], ["onTouchStart", new migi.Cb(this, this.start)], ["onTouchMove", new migi.Cb(this, this.move)], ["onTouchEnd", new migi.Cb(this, this.end)]])])]), migi.createVd("div", [["class", new migi.Obj("canControl", this, function () {
        return 'bar' + (this.canControl ? '' : ' dis');
      })]], [migi.createVd("div", [["class", "prev"]]), migi.createVd("div", [["class", "play"], ["ref", "play"], ["onClick", new migi.Cb(this, this.clickPlay)]]), migi.createVd("div", [["class", "next"]])]), migi.createVd("div", [["class", "tags"], ["ref", "tags"], ["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.clickTag)]]]], [migi.createVd("ul", [], [migi.createVd("li", [["class", "cur"], ["rel", "0"]], [migi.createVd("span", [], ["简介"])]), migi.createVd("li", [["rel", "1"]], [migi.createVd("span", [], ["评论"])])])])]);
    }
  }, {
    key: 'popular',
    set: function set(v) {
      this.__setBind("popular", v);this.__data("popular");
    },
    get: function get() {
      if (this.__initBind("popular")) this.__setBind("popular", 0);return this.__getBind("popular");
    }
  }, {
    key: 'canControl',
    set: function set(v) {
      this.__setBind("canControl", v);this.__data("canControl");
    },
    get: function get() {
      return this.__getBind("canControl");
    }
  }]);

  return Media;
}(migi.Component);

migi.name(Media, "Media");exports.default = Media;

/***/ }),

/***/ 62:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var PlayList = function (_migi$Component) {
  _inherits(PlayList, _migi$Component);

  function PlayList() {
    var _ref;

    _classCallCheck(this, PlayList);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = PlayList.__proto__ || Object.getPrototypeOf(PlayList)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(PlayList, [{
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "playlist"]], [migi.createVd("div", [["class", "t"]], [migi.createVd("b", [["class", "icon"]]), migi.createVd("span", [], ["播放全部"]), migi.createVd("b", [["class", "icon2"]])])]);
    }
  }]);

  return PlayList;
}(migi.Component);

migi.name(PlayList, "PlayList");exports.default = PlayList;

/***/ }),

/***/ 63:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Comment = __webpack_require__(10);

var _Comment2 = _interopRequireDefault(_Comment);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var init = void 0;
var Skip = -1;
var Take = 10;
var Size = 0;
var loadingMore = void 0;
var isShow = void 0;
var scrollCb = void 0;

var WorkComment = function (_migi$Component) {
  _inherits(WorkComment, _migi$Component);

  function WorkComment() {
    var _ref;

    _classCallCheck(this, WorkComment);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = WorkComment.__proto__ || Object.getPrototypeOf(WorkComment)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(WorkComment, [{
    key: 'show',
    value: function show() {
      var self = this;
      isShow = true;
      $(self.element).show();
      if (!init) {
        init = true;
        self.load();
        self.ref.comment.on('chooseSubComment', function (rid, cid, name) {
          self.rootId = rid;
          self.replayId = cid;
          self.replayName = name;
        });
      }
    }
  }, {
    key: 'hide',
    value: function hide() {
      isShow = false;
      $(this.element).hide();
    }
  }, {
    key: 'load',
    value: function load() {
      var self = this;
      util.postJSON('api/works/GetToWorkMessage_List', { WorkID: self.props.workId, Skip: Skip, Take: Take }, function (res) {
        if (res.success) {
          var data = res.data;
          self.ref.comment.list = data.data || [];
          Size = data.Size;
          if (data.data.length) {
            Skip = data.data[data.data.length - 1].Send_ID;
            if (data.data.length >= Size) {
              self.ref.comment.message = '';
            } else {
              scrollCb = function scrollCb() {
                self.checkMore();
              };
              $(window).on('scroll', scrollCb);
            }
          } else {
            self.ref.comment.message = '暂无评论';
          }
        } else {
          jsBridge.toast(res.message || util.ERROR_MESSAGE);
        }
      }, function (res) {
        jsBridge.toast(res.message || util.ERROR_MESSAGE);
      });
    }
  }, {
    key: 'checkMore',
    value: function checkMore() {
      var self = this;
      var $window = $(window);
      var $body = $(document.body);
      var WIN_HEIGHT = $window.height();
      if (isShow && !loadingMore && $body.scrollTop() + WIN_HEIGHT + 30 > $body.height()) {
        loadingMore = true;
        util.postJSON('api/works/GetToWorkMessage_List', { WorkID: self.props.workId, Skip: Skip, Take: Take }, function (res) {
          if (res.success) {
            var data = res.data;
            if (data.data.length) {
              Skip = data.data[data.data.length - 1].Send_ID;
              self.ref.comment.addMore(data.data);
              if (data.data.length < Take) {
                self.ref.comment.message = '';
                $window.off('scroll', scrollCb);
              }
            } else {
              self.ref.comment.message = '';
              $window.off('scroll', scrollCb);
            }
          } else {
            jsBridge.toast(res.message || util.ERROR_MESSAGE);
          }
          loadingMore = false;
        }, function () {
          loadingMore = false;
        });
      }
    }
  }, {
    key: 'clickReplay',
    value: function clickReplay() {
      this.replayId = null;
      this.replayName = null;
    }
  }, {
    key: 'input',
    value: function input(e, vd) {
      var v = $(vd.element).val().trim();
      this.hasContent = v.length > 0;
    }
  }, {
    key: 'click',
    value: function click(e) {
      e.preventDefault();
      var self = this;
      if (self.hasContent) {
        var $input = $(this.ref.input.element);
        var Content = $input.val();
        var ParentID = self.replayId !== null ? self.replayId : -1;
        var RootID = self.rootId !== null ? self.rootId : -1;
        self.loading = true;
        util.postJSON('api/comment/AddComment', {
          ParentID: ParentID,
          RootID: RootID,
          Content: Content,
          commentType: 1,
          commentTypeID: self.props.workId
        }, function (res) {
          if (res.success) {
            $input.val('');
            if (RootID === -1) {
              self.ref.comment.addNew(res.data);
            } else {
              self.ref.comment.addChild(res.data);
            }
          } else {
            jsBridge.toast(res.message || util.ERROR_MESSAGE);
          }
          self.loading = false;
        }, function (res) {
          jsBridge.toast(res.message || util.ERROR_MESSAGE);
          self.loading = false;
        });
      }
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "comments"]], [migi.createCp(_Comment2.default, [["ref", "comment"]]), migi.createVd("div", [["class", "form"]], [migi.createVd("div", [["class", new migi.Obj("replayId", this, function () {
        return 'reply' + (this.replayId ? '' : ' fn-hide');
      })], ["onClick", new migi.Cb(this, this.clickReplay)]], [new migi.Obj("replayName", this, function () {
        return this.replayName;
      })]), migi.createVd("div", [["class", "inputs"]], [migi.createVd("input", [["ref", "input"], ["type", "text"], ["placeholder", "回复..."], ["onInput", new migi.Cb(this, this.input)]])]), migi.createVd("button", [["onClick", new migi.Cb(this, this.click)], ["class", new migi.Obj(["hasContent", "loading"], this, function () {
        return this.hasContent && !this.loading ? '' : 'dis';
      })]], ["确定"])])]);
    }
  }, {
    key: 'rootId',
    set: function set(v) {
      this.__setBind("rootId", v);this.__data("rootId");
    },
    get: function get() {
      if (this.__initBind("rootId")) this.__setBind("rootId", null);return this.__getBind("rootId");
    }
  }, {
    key: 'replayId',
    set: function set(v) {
      this.__setBind("replayId", v);this.__data("replayId");
    },
    get: function get() {
      if (this.__initBind("replayId")) this.__setBind("replayId", null);return this.__getBind("replayId");
    }
  }, {
    key: 'replayName',
    set: function set(v) {
      this.__setBind("replayName", v);this.__data("replayName");
    },
    get: function get() {
      return this.__getBind("replayName");
    }
  }, {
    key: 'hasContent',
    set: function set(v) {
      this.__setBind("hasContent", v);this.__data("hasContent");
    },
    get: function get() {
      return this.__getBind("hasContent");
    }
  }, {
    key: 'loading',
    set: function set(v) {
      this.__setBind("loading", v);this.__data("loading");
    },
    get: function get() {
      return this.__getBind("loading");
    }
  }]);

  return WorkComment;
}(migi.Component);

migi.name(WorkComment, "WorkComment");exports.default = WorkComment;

/***/ }),

/***/ 76:
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ 83:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "works.html";

/***/ }),

/***/ 9:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (authorType) {
  switch (authorType) {
    case 111:
      return {
        name: '演唱',
        abbr: '唱',
        css: 'chang',
        labelType: 11
      };
    case 121:
      return {
        name: '作曲',
        abbr: '曲',
        css: 'qu',
        labelType: 12
      };
    case 122:
      return {
        name: '编曲',
        abbr: '曲',
        css: 'qu',
        labelType: 13
      };
    case 411:
      return {
        name: '作词',
        abbr: '文',
        css: 'wen',
        labelType: 14
      };
    case 131:
      return {
        name: '混音',
        abbr: '混',
        css: 'hun',
        labelType: 15
      };
    default:
      return {
        name: authorType,
        abbr: authorType,
        css: authorType,
        labelType: -1
      };
  }
};

; /**
   * Created by army8735 on 2017/8/13.
   */

/***/ })

/******/ });