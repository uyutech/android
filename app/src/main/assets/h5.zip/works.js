/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 79);
/******/ })
/************************************************************************/
/******/ ({

/***/ 37:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Audio = function (_migi$Component) {
  _inherits(Audio, _migi$Component);

  function Audio() {
    var _ref;

    _classCallCheck(this, Audio);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Audio.__proto__ || Object.getPrototypeOf(Audio)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Audio, [{
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "audio"]], [migi.createVd("div", [["class", "wave1"]]), migi.createVd("div", [["class", "wave2"]]), migi.createVd("audio", [["controls", "controls"], ["src", 'http://192.168.100.199/github/zhuanq/h5/ysj.mp3']], ["\
        your browser does not support the audio tag\
      "])]);
    }
  }]);

  return Audio;
}(migi.Component);

migi.name(Audio, "Audio");exports.default = Audio;

/***/ }),

/***/ 38:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Authors = function (_migi$Component) {
  _inherits(Authors, _migi$Component);

  function Authors() {
    var _ref;

    _classCallCheck(this, Authors);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Authors.__proto__ || Object.getPrototypeOf(Authors)).call.apply(_ref, [this].concat(data)));

    var datas = [{
      type: '出品',
      list: [{
        uid: 1,
        img: 'http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg',
        name: '司夏'
      }, {
        uid: 2,
        img: 'http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg',
        name: '司夏2'
      }]
    }, {
      type: '出品2',
      list: [{
        uid: 3,
        img: 'http://tva4.sinaimg.cn/crop.7.1.129.129.180/64319a89gw1f62p9lp7hyj203w03wq2x.jpg',
        name: '老司机sdf'
      }, {
        uid: 4,
        img: 'http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg',
        name: '司夏换行'
      }]
    }, {
      type: '很长的',
      list: [{
        uid: 5,
        img: 'http://tva4.sinaimg.cn/crop.7.1.129.129.180/64319a89gw1f62p9lp7hyj203w03wq2x.jpg',
        name: '老司机sddf'
      }, {
        uid: 6,
        img: 'http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg',
        name: '司夏1'
      }, {
        uid: 7,
        img: 'http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg',
        name: '司夏2'
      }, {
        uid: 8,
        img: 'http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg',
        name: '司夏3'
      }, {
        uid: 9,
        img: 'http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg',
        name: '司夏4长长长长'
      }, {
        uid: 10,
        img: 'http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg',
        name: '司夏长长长长长长长'
      }]
    }];
    _this.on(migi.Event.DOM, function () {
      var c = this.ref.c.element;
      var $c = this.$c = $(c);
      var temp = [];
      for (var i = 0, len = datas.length; i < len; i++) {
        var item = datas[i];
        // 屏蔽空的
        if (item.list.length) {
          temp.push(migi.createVd("li", [["class", "label"]], [migi.createVd("div", [], [migi.createVd("span", [], [item.type])])]));
          for (var j = 0, _len2 = item.list.length; j < _len2; j++) {
            var item2 = item.list[j];
            temp.push(migi.createVd("li", [["class", "item"], ["uid", item2.uid]], [migi.createVd("img", [["src", item2.img]]), migi.createVd("span", [], [item2.name])]));
          }
        }
      }
      var placeholder = migi.createVd("li", [["class", "placeholder"]]);
      var ul = migi.createVd("ul", [["class", "fn-clear"]]);
      ul.appendTo(c);
      // 最初的2个
      if (temp[0]) {
        temp[0].appendTo(ul);
      }
      if (temp[1]) {
        temp[1].appendTo(ul);
      }
      var count = 0;
      // 循环后面挨个插入判断高度换行
      for (var _i = 2, _len3 = temp.length; _i < _len3; _i++) {
        var _item = temp[_i];
        var $ul = $(ul.element);
        var height = $ul.height();
        // 当是第3行时，尝试插入占位符，一旦产生换行，循环回退一次，同时占位符替代上一次的元素，因为占位符宽度最小所以不会产生影响
        if (count == 1) {
          placeholder.appendTo(ul);
          if ($ul.height() > height) {
            _i--;
            temp[_i].clean();
            continue;
          }
        }
        // 标签类型连续插入2个测试是否需要换行
        if (_item.props.class == 'label') {
          _item.appendTo(ul);
          temp[_i + 1].appendTo(ul);
          //换行生成新的行
          if ($ul.height() > height) {
            ul = migi.createVd("ul", [["class", "fn-clear"]]);
            ul.appendTo(c);
            _item.appendTo(ul);
            count++;
          }
        } else {
          _item.appendTo(ul);
          //换行生成新的行
          if ($ul.height() > height) {
            ul = migi.createVd("ul", [["class", "fn-clear"]]);
            ul.appendTo(c);
            _item.appendTo(ul);
            count++;
          }
        }
      }
      this.firstHeight = $(this.element).height();
      $(this.element).css('height', this.firstHeight);
    });
    return _this;
  }

  _createClass(Authors, [{
    key: 'click',
    value: function click(e, vd, tvd) {
      this.emit('choose', tvd.props.uid, e.pageX, e.pageY);
    }
  }, {
    key: 'click2',
    value: function click2() {
      this.emit('chooseNone');
    }
  }, {
    key: 'alt',
    value: function alt(e, vd) {
      var $b = $(vd.element);
      var $c = $(this.ref.c.element);
      var $root = $(this.element);
      if ($b.hasClass('on')) {
        $root.css('height', this.firstHeight);
      } else if ($root.height() < $c.height()) {
        $root.css('height', $c.height());
      }
      $b.toggleClass('on');
      $root.addClass('no_max');
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "authors"]], [migi.createVd("div", [["class", "c"], ["ref", "c"], ["onClick", [[{ "li.item": { "_v": true } }, new migi.Cb(this, this.click)], [{ "li.label": { "_v": true } }, new migi.Cb(this, this.click2)]]]]), migi.createVd("b", [["class", "slide"], ["onClick", new migi.Cb(this, this.alt)]])]);
    }
  }]);

  return Authors;
}(migi.Component);

migi.name(Authors, "Authors");exports.default = Authors;

/***/ }),

/***/ 39:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Comments = function (_migi$Component) {
  _inherits(Comments, _migi$Component);

  function Comments() {
    var _ref;

    _classCallCheck(this, Comments);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Comments.__proto__ || Object.getPrototypeOf(Comments)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Comments, [{
    key: 'click',
    value: function click(e, vd, tvd) {
      var $ul = $(vd.element);
      $ul.find('li').toggleClass('cur');
      var $con = $(this.ref.con.element);
      if ($ul.hasClass('alt')) {} else {}
      $con.toggleClass('alt');
      $ul.toggleClass('alt');
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "comments"]], [migi.createVd("ul", [["class", "tag fn-clear"], ["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.click)]]]], [migi.createVd("li", [["class", "cur"]], [migi.createVd("span", [], ["最热"])]), migi.createVd("li", [], [migi.createVd("span", [], ["最新"])])]), migi.createVd("div", [["class", "con"], ["ref", "con"]], [migi.createVd("ul", [["class", "list"]], [migi.createVd("li", [], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "profile"]], [migi.createVd("img", [["class", "pic"], ["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]]), migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name"]], ["名字"]), migi.createVd("small", [["class", "time"]], ["昨天 18:08"])]), migi.createVd("p", [], ["签名签名签名签名签名签名"])])]), migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["class", "zan has"]], [migi.createVd("small", [], ["123"])])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [], ["内容内容内容内容\n内容内容内容n内容内容内容n内容内容内容内容内容1234", migi.createVd("span", [["class", "placeholder"]], [])]), migi.createVd("div", [["class", "slide"]], [migi.createVd("small", [], ["12"]), migi.createVd("span", [], ["收起"])])]), migi.createVd("div", [["class", "list2"]], [migi.createVd("ul", [], [migi.createVd("li", [], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["class", "zan has"]], [migi.createVd("small", [], ["123"])])]), migi.createVd("div", [["class", "profile"]], [migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name2"]], ["名字22"]), migi.createVd("b", [["class", "arrow"]]), migi.createVd("small", [["class", "time"]], ["昨天 18:08"]), migi.createVd("span", [["class", "name"]], ["名字"])]), migi.createVd("p", [], ["签名签名签名签名签名签名"])]), migi.createVd("img", [["class", "pic"], ["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [], ["内容内容内容内容\n内容内容内容n内容内容内容n内容内容内容内容内容123"])])]), migi.createVd("li", [], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["class", "zan has"]], [migi.createVd("small", [], ["123"])])]), migi.createVd("div", [["class", "profile"]], [migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name2"]], ["名字22"]), migi.createVd("b", [["class", "arrow"]]), migi.createVd("small", [["class", "time"]], ["昨天 18:08"]), migi.createVd("span", [["class", "name"]], ["名字"])]), migi.createVd("p", [], ["签名签名签名签名签名签名"])]), migi.createVd("img", [["class", "pic"], ["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [], ["哈哈哈"])])])])])])]), migi.createVd("ul", [["class", "list"]], [migi.createVd("li", [], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "profile"]], [migi.createVd("img", [["class", "pic"], ["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]]), migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name"]], ["名字"]), migi.createVd("small", [["class", "time"]], ["昨天 18:08"])]), migi.createVd("p", [], ["签名签名签名签名签名签名"])])]), migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["class", "zan"]], [migi.createVd("small", [], ["123"])])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [], ["内容内容内容内容\n内容内容内容n内容内容内容n内容内容内容内容内容", migi.createVd("span", [["class", "placeholder"]], [])]), migi.createVd("div", [["class", "slide"]], [migi.createVd("small", [], ["12"]), migi.createVd("span", [], ["收起"])])]), migi.createVd("div", [["class", "list2"]], [migi.createVd("ul", [], ["\
              "])])])])])]);
    }
  }]);

  return Comments;
}(migi.Component);

migi.name(Comments, "Comments");exports.default = Comments;

/***/ }),

/***/ 40:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Image = function (_migi$Component) {
  _inherits(Image, _migi$Component);

  function Image() {
    var _ref;

    _classCallCheck(this, Image);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Image.__proto__ || Object.getPrototypeOf(Image)).call.apply(_ref, [this].concat(data)));

    var datas = _this.props.images;
    _this.on(migi.Event.DOM, function () {
      var $list = $(this.ref.list.element);
      var imgs = this.ref.imgs;
      var $imgs = $list.find('.imgs');
      var height = Math.floor($imgs.height());
      datas.forEach(function (item, i) {
        var img = migi.createVd("img", [["index", i], ["src", item], ["style", "width:" + height + "px"]]);
        img.appendTo(imgs);
      });
      $list.css('width', (height + 2) * datas.length + 2);
    });
    return _this;
  }

  _createClass(Image, [{
    key: "click",
    value: function click(e, vd, tvd) {
      this.emit('show', tvd.props.index);
    }
  }, {
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "image"]], [migi.createVd("div", [["class", "list"], ["ref", "list"]], [migi.createVd("div", [["class", "imgs"], ["ref", "imgs"], ["onClick", [[{ "img": { "_v": true } }, new migi.Cb(this, this.click)]]]])])]);
    }
  }]);

  return Image;
}(migi.Component);

migi.name(Image, "Image");exports.default = Image;

/***/ }),

/***/ 41:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var winWidth = $(window).width();

var ImageView = function (_migi$Component) {
  _inherits(ImageView, _migi$Component);

  function ImageView() {
    var _ref;

    _classCallCheck(this, ImageView);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = ImageView.__proto__ || Object.getPrototypeOf(ImageView)).call.apply(_ref, [this].concat(data)));

    var datas = _this.props.images;
    _this.length = datas.length;
    _this.on(migi.Event.DOM, function () {
      var list = this.ref.list.element;
      var $list = this.$list = $(list);
      datas.forEach(function (item, i) {
        var img = migi.createVd("img", [["index", i], ["src", item], ["style", "width:" + winWidth + "px;height:" + winWidth + "px"]]);
        img.appendTo(list);
      });
    });
    return _this;
  }

  _createClass(ImageView, [{
    key: "move",
    value: function move(e) {
      e.preventDefault();
    }
  }, {
    key: "left",
    value: function left() {
      if (this.index < this.length - 1) {
        this.index++;
        this.$list.css('-webkit-transform', "translate3d(-" + this.index * winWidth + "px,0,0)");
        this.$list.css('transform', "translate3d(-" + this.index * winWidth + "px,0,0)");
      }
    }
  }, {
    key: "right",
    value: function right() {
      if (this.index > 0) {
        this.index--;
        this.$list.css('-webkit-transform', "translate3d(-" + this.index * winWidth + "px,0,0)");
        this.$list.css('transform', "translate3d(-" + this.index * winWidth + "px,0,0)");
      }
    }
  }, {
    key: "show",
    value: function show(i) {
      this.index = i;
      this.$list.css('-webkit-transform', "translate3d(-" + this.index * winWidth + "px,0,0)");
      this.$list.css('transform', "translate3d(-" + this.index * winWidth + "px,0,0)");
      $(this.element).show();
      jsBridge.swipeRefresh(false);
    }
  }, {
    key: "click",
    value: function click() {
      $(this.element).hide();
      jsBridge.swipeRefresh(true);
    }
  }, {
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "image_view"], ["onTouchmove", new migi.Cb(this, this.move)], ["onSwipeLeft", new migi.Cb(this, this.left)], ["onSwipeRight", new migi.Cb(this, this.right)], ["onClick", new migi.Cb(this, this.click)]], [migi.createVd("div", [["class", "num"]], [new migi.Obj("index", this, function () {
        return this.index + 1;
      }), "/", new migi.Obj("length", this, function () {
        return this.length;
      })]), migi.createVd("div", [["class", "list fn-clear"], ["ref", "list"], ["style", "width:" + this.length + "00%;"]])]);
    }
  }, {
    key: "index",
    set: function set(v) {
      this.__setBind("index", v);this.__data("index");
    },
    get: function get() {
      if (this.__initBind("index")) this.__setBind("index", 0);return this.__getBind("index");
    }
  }, {
    key: "length",
    set: function set(v) {
      this.__setBind("length", v);this.__data("length");
    },
    get: function get() {
      if (this.__initBind("length")) this.__setBind("length", 0);return this.__getBind("length");
    }
  }]);

  return ImageView;
}(migi.Component);

migi.name(ImageView, "ImageView");exports.default = ImageView;

/***/ }),

/***/ 42:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Intro = function (_migi$Component) {
  _inherits(Intro, _migi$Component);

  function Intro() {
    var _ref;

    _classCallCheck(this, Intro);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Intro.__proto__ || Object.getPrototypeOf(Intro)).call.apply(_ref, [this].concat(data)));

    _this.on(migi.Event.DOM, function () {
      var $timeline = $(this.ref.timeline.element);
      var $line = $timeline.find('.line');
      var $c = $timeline.find('.c');
      var $ul = $c.find('ul');
      var width = $ul.width() + 1;
      $c.css('width', width);
      $line.css('width', width + 10);

      var $inspiration = $(this.ref.inspiration.element);
      $inspiration.children('li').each(function (i, item) {
        var $li = $(item);
        var $placeholder = $li.find('.placeholder');
        var $slide = $li.find('.slide');
        $placeholder.css('width', $slide.width());
      });
    });
    return _this;
  }

  _createClass(Intro, [{
    key: 'slide',
    value: function slide(e, vd, tvd) {
      var $slide = $(tvd.element);
      var $li = $slide.closest('li');
      var $list2 = $li.find('.list2');
      var $ul = $list2.find('ul');
      if ($slide.hasClass('on')) {
        $slide.removeClass('on');
        $list2.css('height', 0);
      } else {
        $slide.addClass('on');
        $list2.css('height', $ul.height());
      }
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "intro"]], [migi.createVd("div", [["class", "tag"]], [migi.createVd("ul", [["class", "fn-clear"]], [migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], ["王者荣耀"])]), migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], ["aaa"])]), migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], ["sdf"])]), migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], ["地方"])]), migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], ["二十多分"])]), migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], ["撒"])]), migi.createVd("li", [["class", "placeholder"]], [])]), migi.createVd("a", [["href", "#"], ["class", "config"]], [])]), migi.createVd("div", [["class", "timeline"], ["ref", "timeline"]], [migi.createVd("b", [["class", "line"]]), migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [], [migi.createVd("li", [], [migi.createVd("span", [], ["发布"]), migi.createVd("small", [], ["2017年1月1日"])])])])]), migi.createVd("div", [["class", "inspiration"], ["ref", "inspiration"], ["onClick", [[{ ".slide": { "_v": true } }, new migi.Cb(this, this.slide)]]]], [migi.createVd("h3", [], [migi.createVd("span", [], ["创作灵感"]), migi.createVd("small", [["class", "add"]], ["添加"])]), migi.createVd("ul", [["class", "list"]], [migi.createVd("li", [], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "profile"]], [migi.createVd("img", [["class", "pic"], ["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]]), migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name"]], ["名字"]), migi.createVd("small", [["class", "time"]], ["昨天 18:08"])]), migi.createVd("p", [], ["签名签名签名签名签名签名"])])]), migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["class", "zan"]], [migi.createVd("small", [], ["123"])])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [], ["内容内容内容内容\n内容内容内容n内容内容内容n内容内容内容内容内容", migi.createVd("span", [["class", "placeholder"]], [])]), migi.createVd("div", [["class", "slide"]], [migi.createVd("small", [], ["12"]), migi.createVd("span", [], ["收起"])])]), migi.createVd("div", [["class", "list2"]], [migi.createVd("ul", [], ["\
              "])])]), migi.createVd("li", [], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "profile"]], [migi.createVd("img", [["class", "pic"], ["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]]), migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name"]], ["名字"]), migi.createVd("small", [["class", "time"]], ["昨天 18:08"])]), migi.createVd("p", [], ["签名签名签名签名签名签名"])])]), migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["class", "zan has"]], [migi.createVd("small", [], ["123"])])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [], ["内容内容内容内容\n内容内容内容n内容内容内容n内容内容内容内容内容1234", migi.createVd("span", [["class", "placeholder"]], [])]), migi.createVd("div", [["class", "slide"]], [migi.createVd("small", [], ["12"]), migi.createVd("span", [], ["收起"])])]), migi.createVd("div", [["class", "list2"]], [migi.createVd("ul", [], [migi.createVd("li", [], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["class", "zan has"]], [migi.createVd("small", [], ["123"])])]), migi.createVd("div", [["class", "profile"]], [migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name2"]], ["名字22"]), migi.createVd("b", [["class", "arrow"]]), migi.createVd("small", [["class", "time"]], ["昨天 18:08"]), migi.createVd("span", [["class", "name"]], ["名字"])]), migi.createVd("p", [], ["签名签名签名签名签名签名"])]), migi.createVd("img", [["class", "pic"], ["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [], ["内容内容内容内容\n内容内容内容n内容内容内容n内容内容内容内容内容123"])])]), migi.createVd("li", [], [migi.createVd("div", [["class", "t"]], [migi.createVd("div", [["class", "fn"]], [migi.createVd("span", [["class", "zan has"]], [migi.createVd("small", [], ["123"])])]), migi.createVd("div", [["class", "profile"]], [migi.createVd("div", [["class", "txt"]], [migi.createVd("div", [], [migi.createVd("span", [["class", "name2"]], ["名字22"]), migi.createVd("b", [["class", "arrow"]]), migi.createVd("small", [["class", "time"]], ["昨天 18:08"]), migi.createVd("span", [["class", "name"]], ["名字"])]), migi.createVd("p", [], ["签名签名签名签名签名签名"])]), migi.createVd("img", [["class", "pic"], ["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]])])]), migi.createVd("div", [["class", "c"]], [migi.createVd("pre", [], ["哈哈哈"])])])])])])])])]);
    }
  }]);

  return Intro;
}(migi.Component);

migi.name(Intro, "Intro");exports.default = Intro;

/***/ }),

/***/ 43:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Link = function (_migi$Component) {
  _inherits(Link, _migi$Component);

  function Link() {
    var _ref;

    _classCallCheck(this, Link);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Link.__proto__ || Object.getPrototypeOf(Link)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Link, [{
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "link"]], []);
    }
  }]);

  return Link;
}(migi.Component);

migi.name(Link, "Link");exports.default = Link;

/***/ }),

/***/ 44:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var MediaSwitch = function (_migi$Component) {
  _inherits(MediaSwitch, _migi$Component);

  function MediaSwitch() {
    var _ref;

    _classCallCheck(this, MediaSwitch);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = MediaSwitch.__proto__ || Object.getPrototypeOf(MediaSwitch)).call.apply(_ref, [this].concat(data)));

    var self = _this;
    self.on(migi.Event.DOM, function () {
      var $window = $(window);
      var $switch = $(self.element);
      var $nav = $(self.props.nav.element);
      var top = $switch.offset().top - $nav.height();
      var winWidth = $window.width();
      var $lis = $switch.find('li.item');
      var liWidth = $lis.width();
      var perWidth = Math.round(liWidth * 1.3);
      var lefts = [];
      for (var i = 0, len = $lis.length; i < len; i++) {
        lefts.push($lis.eq(i).offset().left);
      }
      for (var _i = 0, _len2 = $lis.length; _i < _len2; _i++) {
        var $item = $lis.eq(_i);
        $item.css('-webkit-transform', 'translate3d(' + (winWidth - lefts[_i] - perWidth) + 'px,' + _i * perWidth + 'px,0)');
        $item.css('transform', 'translate3d(' + (winWidth - lefts[_i] - perWidth) + 'px,' + _i * perWidth + 'px,0)');
      }
      $window.on('scroll', function () {
        var diff = top - $window.scrollTop();
        if (diff > 0) {
          $switch.removeClass('fix');
          for (var _i2 = 0, _len3 = $lis.length; _i2 < _len3; _i2++) {
            var _$item = $lis.eq(_i2);
            _$item.css('-webkit-transform', 'translate3d(' + Math.floor((winWidth - lefts[_i2] - perWidth) * diff / top) + 'px,' + Math.floor(_i2 * perWidth * diff / top) + 'px,0)');
            _$item.css('transform', 'translate3d(' + Math.floor((winWidth - lefts[_i2] - perWidth) * diff / top) + 'px,' + Math.floor(_i2 * perWidth * diff / top) + 'px,0)');
          }
        } else {
          $switch.addClass('fix');
          $lis.removeAttr('style');
        }
      });
      setTimeout(function () {
        $switch.addClass('show');
      }, 200);
    });
    return _this;
  }

  _createClass(MediaSwitch, [{
    key: 'click',
    value: function click(e, vd, tvd) {
      var $ul = $(vd.element);
      var $li = $(tvd.element);
      if (!$li.hasClass('cur')) {
        $ul.find('.cur').removeClass('cur');
        $li.addClass('cur');
        this.emit('change', tvd.props.ref);
      }
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "switch"]], [migi.createVd("b", [["class", "bg"]]), migi.createVd("ul", [["onClick", [[{ "li.item": { "_v": true } }, new migi.Cb(this, this.click)]]]], [migi.createVd("li", [["class", "item video cur"], ["ref", 0]]), migi.createVd("li", [["class", "placeholder"]]), migi.createVd("li", [["class", "item audio"], ["ref", 1]]), migi.createVd("li", [["class", "placeholder"]]), migi.createVd("li", [["class", "item image"], ["ref", 2]]), migi.createVd("li", [["class", "placeholder"]]), migi.createVd("li", [["class", "item link"], ["ref", 3]])])]);
    }
  }]);

  return MediaSwitch;
}(migi.Component);

migi.name(MediaSwitch, "MediaSwitch");exports.default = MediaSwitch;

/***/ }),

/***/ 45:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Menu = function (_migi$Component) {
  _inherits(Menu, _migi$Component);

  function Menu() {
    var _ref;

    _classCallCheck(this, Menu);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Menu.__proto__ || Object.getPrototypeOf(Menu)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Menu, [{
    key: "len",
    value: function len(i) {
      this.num = i || 2;
    }
  }, {
    key: "pos",
    value: function pos(x, y) {
      $(this.element).css({
        left: x,
        top: y
      });
    }
  }, {
    key: "show",
    value: function show() {
      this.vis = true;
      var $ul = $(this.element).find('ul');
      setTimeout(function () {
        $ul.addClass('show');
      }, 50);
    }
  }, {
    key: "hide",
    value: function hide() {
      this.vis = false;
      var $ul = $(this.element).find('ul');
      $ul.removeClass('show');
    }
  }, {
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", new migi.Obj("vis", this, function () {
        return 'menu' + (this.vis ? '' : ' fn-hide');
      })]], [migi.createVd("ul", [["class", new migi.Obj("num", this, function () {
        return 's' + this.num;
      })]], [migi.createVd("li", [], [migi.createVd("span", [], ["取消"])]), migi.createVd("li", [], [migi.createVd("span", [], ["关注"])]), migi.createVd("li", [], [migi.createVd("span", [], ["主页"])]), migi.createVd("li", [], [migi.createVd("span", [], ["喜欢"])])])]);
    }
  }, {
    key: "num",
    set: function set(v) {
      this.__setBind("num", v);this.__data("num");
    },
    get: function get() {
      if (this.__initBind("num")) this.__setBind("num", 2);return this.__getBind("num");
    }
  }, {
    key: "vis",
    set: function set(v) {
      this.__setBind("vis", v);this.__data("vis");
    },
    get: function get() {
      return this.__getBind("vis");
    }
  }]);

  return Menu;
}(migi.Component);

migi.name(Menu, "Menu");exports.default = Menu;

/***/ }),

/***/ 46:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Nav = function (_migi$Component) {
  _inherits(Nav, _migi$Component);

  function Nav() {
    var _ref;

    _classCallCheck(this, Nav);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Nav.__proto__ || Object.getPrototypeOf(Nav)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Nav, [{
    key: "click",
    value: function click() {
      jsBridge.popWindow();
    }
  }, {
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "nav"]], [migi.createVd("b", [["class", "back"], ["onClick", new migi.Cb(this, this.click)]]), migi.createVd("h1", [], ["标题标题"]), migi.createVd("h2", [], ["副标题"]), migi.createVd("b", [["class", "play"]])]);
    }
  }]);

  return Nav;
}(migi.Component);

migi.name(Nav, "Nav");exports.default = Nav;

/***/ }),

/***/ 47:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var PlayList = function (_migi$Component) {
  _inherits(PlayList, _migi$Component);

  function PlayList() {
    var _ref;

    _classCallCheck(this, PlayList);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = PlayList.__proto__ || Object.getPrototypeOf(PlayList)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(PlayList, [{
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "playlist"]], [migi.createVd("div", [["class", "t"]], [migi.createVd("b", [["class", "icon"]]), migi.createVd("span", [], ["播放全部"]), migi.createVd("b", [["class", "icon2"]])])]);
    }
  }]);

  return PlayList;
}(migi.Component);

migi.name(PlayList, "PlayList");exports.default = PlayList;

/***/ }),

/***/ 48:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Tags = function (_migi$Component) {
  _inherits(Tags, _migi$Component);

  function Tags() {
    var _ref;

    _classCallCheck(this, Tags);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Tags.__proto__ || Object.getPrototypeOf(Tags)).call.apply(_ref, [this].concat(data)));

    _this.on(migi.Event.DOM, function () {
      var $c = $(this.ref.c.element);
      var $ul = this.$ul = $c.find('ul');
      $c.css('width', $ul.width() + 1);
    });
    return _this;
  }

  _createClass(Tags, [{
    key: 'click',
    value: function click(e, vd, tvd) {
      var $li = $(tvd.element);
      if (!$li.hasClass('cur')) {
        this.$ul.find('.cur').removeClass('cur');
        $li.addClass('cur');
        this.emit('change', tvd.props.rel);
      }
    }
  }, {
    key: 'getTagNum',
    value: function getTagNum() {
      return this.$ul.find('li').length;
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "tags"]], [migi.createVd("div", [["class", "c"], ["ref", "c"]], [migi.createVd("ul", [["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.click)]]]], [migi.createVd("li", [["class", "cur"], ["rel", 0]], [migi.createVd("span", [], ["简介", migi.createVd("b", [])])]), migi.createVd("li", [["rel", 1]], [migi.createVd("span", [], ["播放列表", migi.createVd("b", [])]), migi.createVd("small", [], ["2"])]), migi.createVd("li", [["rel", 2]], [migi.createVd("span", [], ["评论", migi.createVd("b", [])]), migi.createVd("small", [], ["23"])]), migi.createVd("li", [["rel", 3]], [migi.createVd("span", [], ["同人文", migi.createVd("b", [])]), migi.createVd("small", [], ["2333"])]), migi.createVd("li", [["rel", 4]], [migi.createVd("span", [], ["同人图", migi.createVd("b", [])]), migi.createVd("small", [], ["2.3w"])])])])]);
    }
  }]);

  return Tags;
}(migi.Component);

migi.name(Tags, "Tags");exports.default = Tags;

/***/ }),

/***/ 49:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Video = function (_migi$Component) {
  _inherits(Video, _migi$Component);

  function Video() {
    var _ref;

    _classCallCheck(this, Video);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Video.__proto__ || Object.getPrototypeOf(Video)).call.apply(_ref, [this].concat(data)));

    var self = _this;
    self.on(migi.Event.DOM, function () {
      var video = self.video = self.ref.video.element;
      var interval = setInterval(function () {
        if (video.readyState > 0) {
          clearInterval(interval);
          // console.log(video.readyState, video.duration);
        }
      }, 200);

      video.addEventListener('x5videoenterfullscreen', function () {
        self.emit('playing');
      });
      video.addEventListener('x5videoexitfullscreen', function () {
        self.emit('pause');
      });
      video.addEventListener('play', function () {});
      video.addEventListener('playing', function () {
        self.emit('playing');
      });
      video.addEventListener('pause', function () {
        self.emit('pause');
      });
    });
    return _this;
  }

  _createClass(Video, [{
    key: 'playing',
    value: function playing(e) {
      // $(this.ref.switch.element).hide();
    }
  }, {
    key: 'pause',
    value: function pause() {
      // let video = this.ref.video.element;
      // $(video).hide();
    }
  }, {
    key: 'loadedmetadata',
    value: function loadedmetadata(e) {
      var video = this.video;
      if (video.readyState > 0) {
        // console.log(video.readyState, video.duration);
      }
    }
  }, {
    key: 'togglePlay',
    value: function togglePlay(e, vd) {
      var $vd = $(vd.element);
      if ($vd.hasClass('pause')) {
        this.video.pause();
      } else {
        this.video.play();
      }
      $vd.toggleClass('pause');
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "video"]], [migi.createVd("video", [["onPlaying", new migi.Cb(this, this.playing)], ["onPause", new migi.Cb(this, this.pause)], ["onLoadedmetadata", new migi.Cb(this, this.loadedmetadata)], ["ref", "video"], ["preload", "preload"], ["playsinline", "true"], ["webkit-playsinline", "true"], ["controls", "controls"], ["x5-video-player-type", "h5"], ["x5-video-player-fullscreen", "true"], ["src", 'http://192.168.100.199/github/zhuanq/h5/ssc.mp4']], ["\
        your browser does not support the video tag\
      "])]);
    }
  }]);

  return Video;
}(migi.Component);

migi.name(Video, "Video");exports.default = Video;

/***/ }),

/***/ 57:
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ 60:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "src/works/works.html";

/***/ }),

/***/ 79:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(60);

__webpack_require__(57);

var _Nav = __webpack_require__(46);

var _Nav2 = _interopRequireDefault(_Nav);

var _Authors = __webpack_require__(38);

var _Authors2 = _interopRequireDefault(_Authors);

var _Video = __webpack_require__(49);

var _Video2 = _interopRequireDefault(_Video);

var _Audio = __webpack_require__(37);

var _Audio2 = _interopRequireDefault(_Audio);

var _Image = __webpack_require__(40);

var _Image2 = _interopRequireDefault(_Image);

var _Link = __webpack_require__(43);

var _Link2 = _interopRequireDefault(_Link);

var _MediaSwitch = __webpack_require__(44);

var _MediaSwitch2 = _interopRequireDefault(_MediaSwitch);

var _Tags = __webpack_require__(48);

var _Tags2 = _interopRequireDefault(_Tags);

var _Intro = __webpack_require__(42);

var _Intro2 = _interopRequireDefault(_Intro);

var _PlayList = __webpack_require__(47);

var _PlayList2 = _interopRequireDefault(_PlayList);

var _Comments = __webpack_require__(39);

var _Comments2 = _interopRequireDefault(_Comments);

var _Menu = __webpack_require__(45);

var _Menu2 = _interopRequireDefault(_Menu);

var _ImageView = __webpack_require__(41);

var _ImageView2 = _interopRequireDefault(_ImageView);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var $window = $(window);
var winWidth = $window.width();

jsBridge.ready(function () {
  var images = ['http://mu1.sinaimg.cn/square.240/weiyinyue.music.sina.com.cn/wpp_cover/100388475.jpg', 'http://mu1.sinaimg.cn/square.240/weiyinyue.music.sina.com.cn/wpp_cover/100222800.jpg', 'http://mu1.sinaimg.cn/square.240/weiyinyue.music.sina.com.cn/wpp_cover/100393706.jpg'];

  var nav = migi.render(migi.createCp(_Nav2.default, []), document.body);
  var authors = migi.render(migi.createCp(_Authors2.default, []), document.body);
  var menu = migi.render(migi.createCp(_Menu2.default, []), document.body);
  menu.len(3);
  authors.on('choose', function (uid, x, y) {
    menu.pos(x, y);
    menu.hide();
    setTimeout(function () {
      menu.show();
    }, 50);
  });
  authors.on('chooseNone', function () {
    menu.hide();
  });
  $(document.body).on('touchstart', function (e) {
    if ($(e.target).closest('.authors')[0]) {
      return;
    }
    menu.hide();
  });
  var medias = migi.render(migi.createVd("div", [["class", "medias"]], [migi.createVd("div", [["class", "c"]], [migi.createCp(_Video2.default, []), migi.createCp(_Audio2.default, []), migi.createCp(_Image2.default, [["images", images]]), migi.createCp(_Link2.default, [])]), migi.createCp(_MediaSwitch2.default, [["nav", nav]])]), document.body);
  var $mediasC = $(medias.element).find('.c');
  var video = medias.find(_Video2.default);
  video.on('playing', function () {
    menu.hide();
  });
  video.on('pause', function () {});
  var audio = medias.find(_Audio2.default);
  var image = medias.find(_Image2.default);
  var mediaSwitch = medias.find(_MediaSwitch2.default);
  mediaSwitch.on('change', function (i) {
    var x = i * winWidth;
    $mediasC.css('-webkit-transform', 'translate3d(' + -x + 'px,0,0)');
    $mediasC.css('transform', 'translate3d(' + -x + 'px,0,0)');
  });
  // mediaSwitch.emit('change', 2);
  var imageView = migi.render(migi.createCp(_ImageView2.default, [["images", images]]), document.body);
  image.on('show', function (i) {
    imageView.show(i);
  });

  var tags = migi.render(migi.createCp(_Tags2.default, []), document.body);
  var selects = migi.render(migi.createVd("div", [["class", "selects"], ["style", 'width:' + tags.getTagNum() + '00%']], [migi.createCp(_Intro2.default, []), migi.createCp(_PlayList2.default, []), migi.createCp(_Comments2.default, []), migi.createVd("div", [], ["empty"]), migi.createVd("div", [], ["empty"])]), document.body);
  var $selects = $(selects.element);
  // let timeout;
  tags.on('change', function (i) {
    var x = i * winWidth;
    $selects.css('-webkit-transform', 'translate3d(' + -x + 'px,0,0)');
    $selects.css('transform', 'translate3d(' + -x + 'px,0,0)');
    // $selects.children('div').removeClass('fn-zero');
    // if(timeout) {
    //   clearTimeout(timeout);
    // }
    // timeout = setTimeout(function() {
    //   $selects.children('div').addClass('fn-zero');
    //   $selects.children('div').eq(i).removeClass('fn-zero');
    // }, 200);
  });
  // tags.emit('change', 2);
});

/***/ })

/******/ });