/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 61);
/******/ })
/************************************************************************/
/******/ ({

/***/ 32:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var BottomNav = function (_migi$Component) {
  _inherits(BottomNav, _migi$Component);

  function BottomNav() {
    var _ref;

    _classCallCheck(this, BottomNav);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = BottomNav.__proto__ || Object.getPrototypeOf(BottomNav)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(BottomNav, [{
    key: 'click',
    value: function click(e, vd, tvd) {
      var $elem = $(tvd.element);
      if ($elem.hasClass('cur')) {
        return;
      }
      var rel = tvd.props.rel;
      $(this.element).find('.cur').removeClass('cur');
      $elem.addClass('cur');
      this.emit('change', rel);
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "bottom_nav"], ["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.click)]]]], [migi.createVd("ul", [], [migi.createVd("li", [["class", "follow cur"], ["rel", "0"]], [migi.createVd("b", [["class", "icon"]], []), migi.createVd("span", [], ["关注"])]), migi.createVd("li", [["class", "zhuanquan"], ["rel", "1"]], [migi.createVd("b", [["class", "icon"]], []), migi.createVd("span", [], ["转圈"])]), migi.createVd("li", [["class", "new cur"]], [migi.createVd("b", [["class", "icon"]], [])]), migi.createVd("li", [["class", "find"], ["rel", "2"]], [migi.createVd("b", [["class", "icon"]], []), migi.createVd("span", [], ["发现"])]), migi.createVd("li", [["class", "my"], ["rel", "3"]], [migi.createVd("b", [["class", "icon"]], []), migi.createVd("span", [], ["我的"])])])]);
    }
  }]);

  return BottomNav;
}(migi.Component);

migi.name(BottomNav, "BottomNav");exports.default = BottomNav;

/***/ }),

/***/ 33:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var screenWidth = window.screen.availWidth;
var itemWidth = void 0;
var itemLength = void 0;
var isStart = void 0;
var isMove = void 0;
var startX = void 0;
var endX = void 0;
var curX = 0;
var lastCur = 0;

var Carousel = function (_migi$Component) {
  _inherits(Carousel, _migi$Component);

  function Carousel() {
    var _ref;

    _classCallCheck(this, Carousel);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Carousel.__proto__ || Object.getPrototypeOf(Carousel)).call.apply(_ref, [this].concat(data)));

    _this.on(migi.Event.DOM, function () {
      var screen = this.ref.screen;
      var $screen = $(screen.element);
      var $ul = this.$ul = $screen.find('ul');
      var $lis = this.$lis = $ul.find('li');
      itemWidth = $lis.eq(0).width();
      itemLength = $lis.length;
      $screen.css('-webkit-transform', 'translateX(' + (screenWidth - itemWidth) / 2 + 'px)');
      $screen.css('transform', 'translateX(' + (screenWidth - itemWidth) / 2 + 'px)');
      $lis.eq(0).addClass('cur');

      var tag = this.ref.tag;
      var $tag = $(tag.element);
      var $tagLis = $tag.find('li');
      this.on('change', function (i) {
        $tagLis.removeClass('cur');
        $tagLis.eq(i).addClass('cur');
      });
    });
    return _this;
  }

  _createClass(Carousel, [{
    key: 'start',
    value: function start(e) {
      if (e.touches.length != 1) {
        isStart = false;
      } else {
        isStart = true;
        startX = e.touches[0].pageX;
        this.$ul.addClass('no_trans');
      }
    }
  }, {
    key: 'move',
    value: function move(e) {
      if (isStart) {
        isMove = true;
        endX = e.touches[0].pageX;
        var diff = endX - startX;
        this.$ul.css('-webkit-transform', 'translate3d(' + (curX + diff) + 'px, 0, 0)');
        this.$ul.css('transform', 'translate3d(' + (curX + diff) + 'px, 0, 0)');
      }
    }
  }, {
    key: 'end',
    value: function end(e) {
      if (isStart && isMove) {
        isStart = false;
        isMove = false;
        curX += endX - startX;
        if (curX >= -itemWidth / 2) {
          curX = 0;
          if (lastCur != 0) {
            this.$lis.removeClass('cur');
            this.$lis.eq(0).addClass('cur');
            lastCur = 0;
            this.emit('change', lastCur);
          }
        } else if (curX < -itemWidth * (itemLength - 1)) {
          curX = -itemWidth * (itemLength - 1);
          if (lastCur != itemLength - 1) {
            this.$lis.removeClass('cur');
            this.$lis.eq(itemLength - 1).addClass('cur');
            lastCur = itemLength - 1;
            this.emit('change', lastCur);
          }
        } else {
          var i = Math.abs(Math.round(curX / itemWidth));
          curX = -itemWidth * i;
          if (lastCur != i) {
            this.$lis.removeClass('cur');
            this.$lis.eq(i).addClass('cur');
            lastCur = i;
            this.emit('change', lastCur);
          }
        }
        this.$ul.removeClass('no_trans');
        this.$ul.css('-webkit-transform', 'translate3d(' + curX + 'px, 0, 0)');
        this.$ul.css('transform', 'translate3d(' + curX + 'px, 0, 0)');
      }
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "carousel"]], [migi.createVd("div", [["class", "screen"], ["ref", "screen"]], [migi.createVd("ul", [["onTouchStart", new migi.Cb(this, this.start)], ["onTouchMove", new migi.Cb(this, this.move)], ["onTouchEnd", new migi.Cb(this, this.end)], ["onTouchCancel", new migi.Cb(this, this.end)]], [migi.createVd("li", [], [migi.createVd("img", [["src", "http://mu1.sinaimg.cn/square.240/weiyinyue.music.sina.com.cn/wpp_cover/100397440.jpg"]])]), migi.createVd("li", [], [migi.createVd("img", [["src", "http://mu1.sinaimg.cn/square.240/weiyinyue.music.sina.com.cn/wpp_cover/100388475.jpg"]])]), migi.createVd("li", [], [migi.createVd("img", [["src", "http://mu1.sinaimg.cn/square.240/weiyinyue.music.sina.com.cn/wpp_cover/100222800.jpg"]])]), migi.createVd("li", [], [migi.createVd("img", [["src", "http://mu1.sinaimg.cn/square.240/weiyinyue.music.sina.com.cn/wpp_cover/100393706.jpg"]])]), migi.createVd("li", [], [migi.createVd("img", [["src", "http://mu1.sinaimg.cn/square.240/weiyinyue.music.sina.com.cn/wpp_cover/100388475.jpg"]])])])]), migi.createVd("div", [["class", "tag"], ["ref", "tag"]], [migi.createVd("ul", [], [migi.createVd("li", [["class", "cur"]], ["1"]), migi.createVd("li", [], ["2"]), migi.createVd("li", [], ["3"]), migi.createVd("li", [], ["4"]), migi.createVd("li", [], ["5"])])])]);
    }
  }]);

  return Carousel;
}(migi.Component);

migi.name(Carousel, "Carousel");exports.default = Carousel;

/***/ }),

/***/ 34:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var screenWidth = screen.availWidth;

var FollowList = function (_migi$Component) {
  _inherits(FollowList, _migi$Component);

  function FollowList() {
    var _ref;

    _classCallCheck(this, FollowList);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = FollowList.__proto__ || Object.getPrototypeOf(FollowList)).call.apply(_ref, [this].concat(data)));

    _this.on(migi.Event.DOM, function () {
      var ers = this.ref.ers;
      var $ers = $(ers.element);
      var $ersC = $ers.find('.c');
      var $ersUl = $ersC.find('ul');
      var perWidth = Math.round($ers.width() / 4.5);
      var style = document.createElement('style');
      style.innerText = '.follow_list .con .ers ul li{width:' + perWidth + 'px}';
      document.head.appendChild(style);
      $ersC.css('width', Math.ceil($ersUl.width()) + 'px');

      var tags = this.ref.tags;
      var $tags = $(tags.element);
      var $tagsC = $tags.find('.c');
      var $tagsUl = $tagsC.find('ul');
      $tagsC.css('width', Math.ceil($tagsUl.width()) + 'px');

      var $ersLi = $ersUl.find('li');
      var $ersImg = $ersLi.find('img');
      var dx = $ersLi.width() - $ersImg.width() >> 1;
      $tagsC.css('padding-left', dx + 'px');
    });
    return _this;
  }

  _createClass(FollowList, [{
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "follow_list"]], [migi.createVd("div", [["class", "ti"]], [migi.createVd("div", [["class", "config"]], ["关注列表"])]), migi.createVd("div", [["class", "con"]], [migi.createVd("div", [["class", "ers"], ["ref", "ers"]], [migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [["class", "fn-clear"]], [migi.createVd("li", [], [migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]]), migi.createVd("span", [], ["揩油哥"])]), migi.createVd("li", [], [migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]]), migi.createVd("span", [], ["揩油哥"])]), migi.createVd("li", [], [migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]]), migi.createVd("span", [], ["揩油哥"])]), migi.createVd("li", [], [migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]]), migi.createVd("span", [], ["揩油哥"])]), migi.createVd("li", [], [migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]]), migi.createVd("span", [], ["揩油哥"])]), migi.createVd("li", [], [migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]]), migi.createVd("span", [], ["揩油哥"])]), migi.createVd("li", [], [migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]]), migi.createVd("span", [], ["揩油哥"])])])])]), migi.createVd("div", [["class", "tags"], ["ref", "tags"]], [migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [], [migi.createVd("li", [], ["古风"]), migi.createVd("li", [], ["古风123"]), migi.createVd("li", [], ["古风sd"]), migi.createVd("li", [], ["古风"]), migi.createVd("li", [], ["古风asdasdfs"]), migi.createVd("li", [], ["古风"]), migi.createVd("li", [], ["古风a"])])])])])]);
    }
  }]);

  return FollowList;
}(migi.Component);

migi.name(FollowList, "FollowList");exports.default = FollowList;

/***/ }),

/***/ 35:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var News = function (_migi$Component) {
  _inherits(News, _migi$Component);

  function News() {
    var _ref;

    _classCallCheck(this, News);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = News.__proto__ || Object.getPrototypeOf(News)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(News, [{
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "news"]], [migi.createVd("ul", [], [migi.createVd("li", [], [migi.createVd("div", [["class", "con"]], [migi.createVd("div", [["class", "user"]], [migi.createVd("div", [["class", "head n5 fn-clear"]], [migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]]), migi.createVd("img", [["src", "http://tva1.sinaimg.cn/crop.0.0.180.180.50/8380d51ejw1e8qgp5bmzyj2050050aa8.jpg"]]), migi.createVd("img", [["src", "http://tva4.sinaimg.cn/crop.7.1.129.129.180/64319a89gw1f62p9lp7hyj203w03wq2x.jpg"]]), migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]]), migi.createVd("img", [["src", "http://tva4.sinaimg.cn/crop.7.1.129.129.180/64319a89gw1f62p9lp7hyj203w03wq2x.jpg"]])]), migi.createVd("div", [["class", "name"]], [migi.createVd("p", [], ["aaa、bbb、ccc、阿斯利康的方式、阿萨德了富士康、上岛咖啡"]), migi.createVd("small", [], ["1小时前"])])]), migi.createVd("p", [["class", "info"]], [migi.createVd("b", [["class", "zq"]]), "建立了合作项目", migi.createVd("a", [["href", "#"]], ["《铁拳无敌孙中山，军道杀拳周恩来》"]), "是的发生的发顺丰"])]), migi.createVd("div", [["class", "preview"]], [migi.createVd("img", [["src", "http://wx1.sinaimg.cn/mw690/68318509gy1fe7c0thqx0j20yz0k3wnw.jpg"]])])]), migi.createVd("li", [], [migi.createVd("div", [["class", "con"]], [migi.createVd("div", [["class", "user"]], [migi.createVd("div", [["class", "head fn-clear"]], [migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]])])]), migi.createVd("p", [["class", "info"]], [migi.createVd("b", [["class", "wb"]]), "建立了合作项目", migi.createVd("a", [["href", "#"]], ["《铁拳无敌孙中山，军道杀拳周恩来》"]), "是的发生的发顺丰"])]), migi.createVd("div", [["class", "preview"]], [migi.createVd("img", [["src", "http://wx1.sinaimg.cn/mw690/68318509gy1fe7c0thqx0j20yz0k3wnw.jpg"]])])]), migi.createVd("li", [], [migi.createVd("div", [["class", "con"]], [migi.createVd("div", [["class", "user"]], [migi.createVd("div", [["class", "head fn-clear"]], [migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]])])]), migi.createVd("p", [["class", "info"]], [migi.createVd("b", [["class", "bili"]]), "建立了合作项目", migi.createVd("a", [["href", "#"]], ["《铁拳无敌孙中山，军道杀拳周恩来》"]), "是的发生的发顺丰"])]), migi.createVd("div", [["class", "preview"]], [migi.createVd("img", [["src", "http://wx1.sinaimg.cn/mw690/68318509gy1fe7c0thqx0j20yz0k3wnw.jpg"]])])]), migi.createVd("li", [], [migi.createVd("div", [["class", "con"]], [migi.createVd("div", [["class", "user"]], [migi.createVd("div", [["class", "head fn-clear"]], [migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]])])]), migi.createVd("p", [["class", "info"]], [migi.createVd("b", [["class", "xmly"]]), "建立了合作项目", migi.createVd("a", [["href", "#"]], ["《铁拳无敌孙中山，军道杀拳周恩来》"]), "是的发生的发顺丰"])]), migi.createVd("div", [["class", "preview"]], [migi.createVd("img", [["src", "http://wx1.sinaimg.cn/mw690/68318509gy1fe7c0thqx0j20yz0k3wnw.jpg"]])])]), migi.createVd("li", [], [migi.createVd("div", [["class", "con"]], [migi.createVd("div", [["class", "user"]], [migi.createVd("div", [["class", "head fn-clear"]], [migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]])])]), migi.createVd("p", [["class", "info"]], [migi.createVd("b", [["class", "xmly"]]), "建立了合作项目", migi.createVd("a", [["href", "#"]], ["《铁拳无敌孙中山，军道杀拳周恩来》"]), "是的发生的发顺丰"])]), migi.createVd("div", [["class", "preview"]], [migi.createVd("img", [["src", "http://wx1.sinaimg.cn/mw690/68318509gy1fe7c0thqx0j20yz0k3wnw.jpg"]])])]), migi.createVd("li", [], [migi.createVd("div", [["class", "con"]], [migi.createVd("div", [["class", "user"]], [migi.createVd("div", [["class", "head fn-clear"]], [migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.0.0.328.328.50/6924ccf1gw1f889w9il5pj209709e0tx.jpg"]])])]), migi.createVd("p", [["class", "info"]], [migi.createVd("b", [["class", "xmly"]]), "建立了合作项目", migi.createVd("a", [["href", "#"]], ["《铁拳无敌孙中山，军道杀拳周恩来》"]), "是的发生的发顺丰"])]), migi.createVd("div", [["class", "preview"]], [migi.createVd("img", [["src", "http://wx1.sinaimg.cn/mw690/68318509gy1fe7c0thqx0j20yz0k3wnw.jpg"]])])])])]);
    }
  }]);

  return News;
}(migi.Component);

migi.name(News, "News");exports.default = News;

/***/ }),

/***/ 42:
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ 44:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "src/index/index.html";

/***/ }),

/***/ 61:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(44);

__webpack_require__(42);

var _Carousel = __webpack_require__(33);

var _Carousel2 = _interopRequireDefault(_Carousel);

var _FollowList = __webpack_require__(34);

var _FollowList2 = _interopRequireDefault(_FollowList);

var _BottomNav = __webpack_require__(32);

var _BottomNav2 = _interopRequireDefault(_BottomNav);

var _News = __webpack_require__(35);

var _News2 = _interopRequireDefault(_News);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var carousel = migi.render(migi.createCp(_Carousel2.default, []), document.body);

migi.render(migi.createCp(_FollowList2.default, []), document.body);

migi.render(migi.createCp(_News2.default, []), document.body);

migi.render(migi.createCp(_BottomNav2.default, []), document.body);

/***/ })

/******/ });