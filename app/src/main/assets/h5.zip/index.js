/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 99);
/******/ })
/************************************************************************/
/******/ ({

/***/ 100:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Profile = function (_migi$Component) {
  _inherits(Profile, _migi$Component);

  function Profile() {
    var _ref;

    _classCallCheck(this, Profile);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Profile.__proto__ || Object.getPrototypeOf(Profile)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Profile, [{
    key: 'click',
    value: function click(e, vd, tvd) {
      var $tvd = $(tvd.element);console.log($tvd.hasClass('alt'));
      if ($tvd.hasClass('alt')) {
        $(vd.element).find('.card').toggleClass('alt');
      }
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "profile"], ["onClick", [[{ ".card": { "_v": true } }, new migi.Cb(this, this.click)]]]], [migi.createVd("div", [["class", "card"]], [migi.createVd("img", [["class", "pic"], ["src", "http://bbs.xiguo.net/zq/zz/02.png"]]), migi.createVd("div", [["class", "con"]], [migi.createVd("h3", [], ["司夏", migi.createVd("span", [], ["个人身份"])]), migi.createVd("ul", [], [migi.createVd("li", [], ["Lv.5"]), migi.createVd("li", [], [migi.createVd("strong", [], ["2"]), migi.createVd("span", [], ["感兴趣"])]), migi.createVd("li", [], [migi.createVd("strong", [], ["6"]), migi.createVd("span", [], ["喜欢我"])])])])]), migi.createVd("div", [["class", "card alt"]], [migi.createVd("img", [["class", "pic"], ["src", "http://bbs.xiguo.net/zq/zz/02.png"]]), migi.createVd("div", [["class", "con"]], [migi.createVd("h3", [], ["司夏", migi.createVd("span", [], ["公众身份"])]), migi.createVd("ul", [], [migi.createVd("li", [], ["Lv.5"]), migi.createVd("li", [], [migi.createVd("strong", [], ["2"]), migi.createVd("span", [], ["感兴趣"])]), migi.createVd("li", [], [migi.createVd("strong", [], ["6"]), migi.createVd("span", [], ["喜欢我"])])])])])]);
    }
  }]);

  return Profile;
}(migi.Component);

migi.name(Profile, "Profile");exports.default = Profile;

/***/ }),

/***/ 101:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Types = function (_migi$Component) {
  _inherits(Types, _migi$Component);

  function Types() {
    var _ref;

    _classCallCheck(this, Types);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Types.__proto__ || Object.getPrototypeOf(Types)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Types, [{
    key: 'click',
    value: function click(e, vd, tvd) {
      var $item = $(tvd.element).parent();
      var $more = $item.find('.more');
      if ($item.hasClass('show')) {
        $more.css('height', 0);
      } else {
        var $c = $item.find('.c');
        $more.css('height', $c.height());
      }
      $item.toggleClass('show');
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "types"], ["onClick", [[{ "h4": { "_>": { ".item": { "_v": true } } } }, new migi.Cb(this, this.click)]]]], [migi.createVd("div", [["class", "item finance"]], [migi.createVd("h4", [], ["我的财产", migi.createVd("b", [["class", "arrow"]])]), migi.createVd("div", [["class", "more"]], [migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [["class", "fn-clear"]], [migi.createVd("li", [], [migi.createVd("div", [["class", "flower"]], [migi.createVd("span", [], ["鲜花"])]), migi.createVd("strong", [], ["10"])]), migi.createVd("li", [], [migi.createVd("div", [["class", "gift"]], [migi.createVd("span", [], ["礼物"])]), migi.createVd("strong", [], ["10"])]), migi.createVd("li", [], [migi.createVd("div", [["class", "coin"]], [migi.createVd("span", [], ["圈币"])]), migi.createVd("strong", [], ["10"])])]), migi.createVd("button", [], ["充值"])])])]), migi.createVd("div", [["class", "item success"]], [migi.createVd("h4", [], ["我的成就", migi.createVd("b", [["class", "arrow"]])]), migi.createVd("div", [["class", "more"]], [migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [], [migi.createVd("li", [], ["成就名称"]), migi.createVd("li", [], ["成就名称"])]), migi.createVd("button", [], ["成就系统"])])])]), migi.createVd("div", [["class", "item follow"]], [migi.createVd("h4", [], ["我的关注", migi.createVd("b", [["class", "arrow"]])]), migi.createVd("div", [["class", "more"]], [migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [], [migi.createVd("li", [], ["成就名称"]), migi.createVd("li", [], ["成就名称"])]), migi.createVd("button", [], ["成就系统"])])])])]);
    }
  }]);

  return Types;
}(migi.Component);

migi.name(Types, "Types");exports.default = Types;

/***/ }),

/***/ 11:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Dynamics = function (_migi$Component) {
  _inherits(Dynamics, _migi$Component);

  function Dynamics() {
    var _ref;

    _classCallCheck(this, Dynamics);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Dynamics.__proto__ || Object.getPrototypeOf(Dynamics)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Dynamics, [{
    key: "click",
    value: function click(e, vd, tvd) {
      var url = tvd.props.href;
      jsBridge.openUri(url);
    }
  }, {
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "cp_dynamic"]], [migi.createVd("ul", [["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.click)]]]], [new migi.Obj("list", this, function () {
        return this.list.map(function (item) {
          return migi.createVd("li", [["href", item.DynamicUrl]], [migi.createVd("div", [["class", "con"]], [migi.createVd("div", [["class", "user"]], [migi.createVd("div", [["class", "head fn-clear"]], [migi.createVd("img", [["src", item.AuthorHeadUrl]])]), migi.createVd("div", [["class", "name"]], [migi.createVd("p", [], [item.AuthorName]), migi.createVd("small", [], [item.SendTime])])]), migi.createVd("p", [["class", "info"]], [migi.createVd("b", [["class", "weibo"]]), item.DynamicContent])]), migi.createVd("div", [["class", "preview"]], [migi.createVd("img", [["src", item.DynamicPic]])])]);
          var info = void 0;
          var preview = void 0;
          if (item.type == 'song') {
            info = migi.createVd("p", [["class", "info"]], [migi.createVd("b", [["class", "zq"]]), item.action, migi.createVd("a", [["href", "#"]], [item.song])]);
            preview = migi.createVd("div", [["class", "preview"]], [migi.createVd("img", [["src", item.pic]])]);
          } else if (item.type == 'weibo') {
            info = migi.createVd("p", [["class", "info"]], [migi.createVd("b", [["class", "wb"]]), item.action, migi.createVd("a", [["href", "#"]], [item.txt])]);
          }
          return migi.createVd("li", [], [migi.createVd("div", [["class", "con"]], [migi.createVd("div", [["class", "user"]], [migi.createVd("div", [["class", "head n" + item.imgs.length + " fn-clear"]], [item.imgs.map(function (item2) {
            return migi.createVd("img", [["src", item2]]);
          })]), migi.createVd("div", [["class", "name"]], [migi.createVd("p", [], [item.names.join('、')]), migi.createVd("small", [], [item.time])])]), info]), preview]);
        });
      })])]);
    }
  }, {
    key: "list",
    set: function set(v) {
      this.__setBind("list", v);this.__data("list");
    },
    get: function get() {
      if (this.__initBind("list")) this.__setBind("list", []);return this.__getBind("list");
    }
  }]);

  return Dynamics;
}(migi.Component);

migi.name(Dynamics, "Dynamics");exports.default = Dynamics;

/***/ }),

/***/ 12:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var PlayList = function (_migi$Component) {
  _inherits(PlayList, _migi$Component);

  function PlayList() {
    var _ref;

    _classCallCheck(this, PlayList);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = PlayList.__proto__ || Object.getPrototypeOf(PlayList)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(PlayList, [{
    key: 'switchType',
    value: function switchType(e, vd) {
      var $ul = $(vd.element);
      $ul.toggleClass('alt');
      $ul.find('li').toggleClass('cur');
    }
  }, {
    key: 'click',
    value: function click(e, vd, tvd) {
      var id = tvd.props.workId;
      jsBridge.pushWindow('works.html?id=' + id);
    }
  }, {
    key: 'setData',
    value: function setData(data) {
      this.list = data.data || [];
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "cp_playlist"]], [migi.createVd("div", [["class", "bar"]], [migi.createVd("ul", [["class", "btn fn-clear"]], [migi.createVd("li", [["class", "all"]], ["播放全部"]), migi.createVd("li", [["class", "audio"]], []), migi.createVd("li", [["class", "video"]], [])]), migi.createVd("ul", [["class", "type fn-clear"], ["onClick", new migi.Cb(this, this.switchType)]], [migi.createVd("li", [["class", "cur"]], [migi.createVd("span", [], ["最热"])]), migi.createVd("li", [], [migi.createVd("span", [], ["最新"])])])]), migi.createVd("ul", [["class", "list"], ["onClick", [[{ ".pic": { "_v": true } }, new migi.Cb(this, this.click)], [{ ".txt": { "_v": true } }, new migi.Cb(this, this.click)]]]], [new migi.Obj("list", this, function () {
        return this.list.map(function (item) {
          return migi.createVd("li", [], [migi.createVd("div", [["workId", item.WorksID], ["class", "pic"], ["style", 'background:url(' + item.cover_Pic + ')']]), migi.createVd("div", [["class", "txt"], ["workId", item.WorksID]], [migi.createVd("div", [["class", "name"]], [item.Title]), migi.createVd("p", [["class", "intro"]], [item.sub_Title])])]
          // item.type.map(function(item2) {
          //   return <b class={ item2 }/>;
          // })

          );
        });
      })])]);
    }
  }, {
    key: 'list',
    set: function set(v) {
      this.__setBind("list", v);this.__data("list");
    },
    get: function get() {
      if (this.__initBind("list")) this.__setBind("list", []);return this.__getBind("list");
    }
  }]);

  return PlayList;
}(migi.Component);

migi.name(PlayList, "PlayList");exports.default = PlayList;

/***/ }),

/***/ 13:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var isStart = void 0;
var startX = void 0;

var HotAlbum = function (_migi$Component) {
  _inherits(HotAlbum, _migi$Component);

  function HotAlbum() {
    var _ref;

    _classCallCheck(this, HotAlbum);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = HotAlbum.__proto__ || Object.getPrototypeOf(HotAlbum)).call.apply(_ref, [this].concat(data)));

    _this.list2 = _this.props.list || [];
    return _this;
  }

  _createClass(HotAlbum, [{
    key: 'autoWidth',
    value: function autoWidth() {
      this.$root = $(this.element);
      this.list = this.ref.list.element;
      this.$list = $(this.list);
      var $c = this.$list.find('.c');
      $c.width('css', '9999rem');
      var $ul = $c.find('ul');
      $c.css('width', $ul.width() + 1);
    }
  }, {
    key: 'start',
    value: function start(e) {
      if (e.touches.length != 1) {
        isStart = false;
      } else {
        isStart = true;
        startX = e.touches[0].pageX;
        this.$list.addClass('no_trans');
        this.$list.removeAttr('style');
        jsBridge.swipeRefresh(false);
      }
    }
  }, {
    key: 'move',
    value: function move(e) {
      if (isStart) {
        var x = e.touches[0].pageX;
        if (x > startX) {
          var left = this.list.scrollLeft;
          if (left == 0) {
            e.preventDefault();
            var diff = x - startX;
            this.$list.css('transform', 'translate3d(' + diff + 'px,0,0)');
            this.$list.css('-webkit-transform', 'translate3d(' + diff + 'px,0,0)');
          }
        }
      }
    }
  }, {
    key: 'end',
    value: function end(e) {
      this.$list.removeClass('no_trans');
      this.$list.removeAttr('style');
      jsBridge.swipeRefresh(true);
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "hot_album"]], [migi.createVd("h3", [], [this.props.title]), migi.createVd("div", [["class", "list"], ["ref", "list"]], [migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [], [new migi.Obj("list2", this, function () {
        return this.list2.map(function (item) {
          if (item.type == 'audio') {
            return migi.createVd("li", [], [migi.createVd("div", [["class", "pic"]], [migi.createVd("div", [["class", "bg3"]]), migi.createVd("div", [["class", "bg2"]]), migi.createVd("div", [["class", "bg"]]), migi.createVd("div", [["class", "mask"]]), migi.createVd("div", [["class", "num"]], [migi.createVd("b", [["class", "audio"]]), "66w"]), migi.createVd("div", [["class", "ath"]], [item.author])]), migi.createVd("p", [["class", "txt"]], ["名字"])]);
          }
          return migi.createVd("li", [], [migi.createVd("div", [["class", "pic"]], [migi.createVd("div", [["class", "bg3"]]), migi.createVd("div", [["class", "bg2"]]), migi.createVd("div", [["class", "bg"]]), migi.createVd("img", [["src", item.img]]), migi.createVd("div", [["class", "mask"]]), migi.createVd("div", [["class", "num"]], [migi.createVd("b", [["class", "video"]]), item.num]), migi.createVd("div", [["class", "ath"]], [item.author])]), migi.createVd("p", [["class", "txt"]], [item.name])]);
        });
      })])])])]);
    }
  }, {
    key: 'list2',
    set: function set(v) {
      this.__setBind("list2", v);this.__data("list2");
    },
    get: function get() {
      return this.__getBind("list2");
    }
  }]);

  return HotAlbum;
}(migi.Component);

migi.name(HotAlbum, "HotAlbum");exports.default = HotAlbum;

/***/ }),

/***/ 46:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var BottomNav = function (_migi$Component) {
  _inherits(BottomNav, _migi$Component);

  function BottomNav() {
    var _ref;

    _classCallCheck(this, BottomNav);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = BottomNav.__proto__ || Object.getPrototypeOf(BottomNav)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(BottomNav, [{
    key: 'click',
    value: function click(e, vd, tvd) {
      var $elem = $(tvd.element);
      if ($elem.hasClass('cur')) {
        return;
      }
      var rel = tvd.props.rel;
      if (rel) {
        $(this.element).find('.cur').removeClass('cur');
        $elem.addClass('cur');
        this.emit('change', rel);
      }
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "bottom_nav"], ["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.click)]]]], [migi.createVd("ul", [], [migi.createVd("li", [["class", "follow cur"], ["rel", "0"]], [migi.createVd("b", [["class", "icon"]], []), migi.createVd("span", [], ["关注"])]), migi.createVd("li", [["class", "zhuanquan"], ["rel", "1"]], [migi.createVd("b", [["class", "icon"]], []), migi.createVd("span", [], ["转圈"])]), migi.createVd("li", [["class", "new cur"]], [migi.createVd("b", [["class", "icon"]], [])]), migi.createVd("li", [["class", "find"], ["rel", "2"]], [migi.createVd("b", [["class", "icon"]], []), migi.createVd("span", [], ["发现"])]), migi.createVd("li", [["class", "my"], ["rel", "3"]], [migi.createVd("b", [["class", "icon"]], []), migi.createVd("span", [], ["我的"])])])]);
    }
  }]);

  return BottomNav;
}(migi.Component);

migi.name(BottomNav, "BottomNav");exports.default = BottomNav;

/***/ }),

/***/ 47:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Nav = function (_migi$Component) {
  _inherits(Nav, _migi$Component);

  function Nav() {
    var _ref;

    _classCallCheck(this, Nav);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Nav.__proto__ || Object.getPrototypeOf(Nav)).call.apply(_ref, [this].concat(data)));

    _this.on(migi.Event.DOM, function () {
      var $window = $(window);
      var bg = this.ref.bg.element;
      $window.on('scroll', function () {
        var top = $window.scrollTop();
        var opacity = top / 100;
        if (opacity > 1) {
          opacity = 1;
        }
        bg.style.opacity = opacity;
      });
    });
    return _this;
  }

  _createClass(Nav, [{
    key: 'show',
    value: function show() {
      $(this.element).css('display', 'block');
    }
  }, {
    key: 'hide',
    value: function hide() {
      $(this.element).css('display', 'none');
    }
  }, {
    key: 'formClick',
    value: function formClick() {
      jsBridge.pushWindow('search.html');
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "nav"]], [migi.createVd("div", [["class", "bg"], ["ref", "bg"]]), migi.createVd("div", [["class", "form"], ["onClick", new migi.Cb(this, this.formClick)]], [migi.createVd("input", [["type", "text"], ["placeholder", "河图新歌发布"], ["readOnly", "readOnly"]])]), migi.createVd("b", [["class", "comment"]]), migi.createVd("b", [["class", "play"]])]);
    }
  }]);

  return Nav;
}(migi.Component);

migi.name(Nav, "Nav");exports.default = Nav;

/***/ }),

/***/ 48:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ZhuanquanCard = function (_migi$Component) {
  _inherits(ZhuanquanCard, _migi$Component);

  function ZhuanquanCard() {
    var _ref;

    _classCallCheck(this, ZhuanquanCard);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = ZhuanquanCard.__proto__ || Object.getPrototypeOf(ZhuanquanCard)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(ZhuanquanCard, [{
    key: "show",
    value: function show() {
      $(this.element).show();
    }
  }, {
    key: "hide",
    value: function hide() {
      $(this.element).hide();
    }
  }, {
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "zhuanquan_card"]], []);
    }
  }]);

  return ZhuanquanCard;
}(migi.Component);

migi.name(ZhuanquanCard, "ZhuanquanCard");exports.default = ZhuanquanCard;

/***/ }),

/***/ 49:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Banner = __webpack_require__(93);

var _Banner2 = _interopRequireDefault(_Banner);

var _Tags = __webpack_require__(96);

var _Tags2 = _interopRequireDefault(_Tags);

var _HotWorks = __webpack_require__(95);

var _HotWorks2 = _interopRequireDefault(_HotWorks);

var _HotAlbum = __webpack_require__(13);

var _HotAlbum2 = _interopRequireDefault(_HotAlbum);

var _HotAuthor = __webpack_require__(94);

var _HotAuthor2 = _interopRequireDefault(_HotAuthor);

var _PlayList = __webpack_require__(12);

var _PlayList2 = _interopRequireDefault(_PlayList);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var first = true;

var hotWorks = [{
  id: 1,
  img: 'http://bbs.xiguo.net/zq/zp/07.jpeg',
  name: '前前前世',
  num: '66w',
  author: '司夏'
}, {
  id: 2,
  img: 'http://bbs.xiguo.net/zq/zp/m01.jpg',
  name: '一生',
  num: '60w',
  author: '慕寒'
}, {
  id: 3,
  img: 'http://bbs.xiguo.net/zq/zp/y01.jpg',
  name: '山海侧',
  num: '48w',
  author: '银临'
}, {
  id: 4,
  img: 'http://bbs.xiguo.net/zq/zp/05.jpg',
  name: '千岁暖',
  num: '47w',
  author: '司夏'
}, {
  id: 5,
  img: 'http://bbs.xiguo.net/zq/zp/z04.jpg',
  name: '九曜',
  num: '36w',
  author: '慕寒'
}, {
  id: 6,
  img: 'http://bbs.xiguo.net/zq/zp/03.jpg',
  name: '晴时雨时',
  num: '34w',
  author: '司夏'
}];
var hotAlbum = [{
  id: 1,
  img: 'http://bbs.xiguo.net/zq/zj/z001.jpeg',
  name: '倾尽天下',
  num: '250w',
  author: '河图'
}, {
  id: 2,
  img: 'http://bbs.xiguo.net/zq/zj/z03.jpeg',
  name: '夏花秋实',
  num: '121w',
  author: '五色石南叶'
}, {
  id: 3,
  img: 'http://bbs.xiguo.net/zq/zj/z05.jpeg',
  name: '人间词话',
  num: '55w',
  author: '汐音社'
}, {
  id: 4,
  img: 'http://bbs.xiguo.net/zq/zj/z002.jpg',
  name: '漱愿记',
  num: '33w',
  author: '司夏'
}, {
  id: 5,
  img: 'http://bbs.xiguo.net/zq/zj/z04.jpeg',
  name: '千里丹心',
  num: '15w',
  author: '汐音社'
}];
var hotAuthor = [{
  id: 1,
  img: 'http://bbs.xiguo.net/zq/zz/01.jpg',
  name: '河图',
  info: '合作16次'
}, {
  id: 2,
  img: 'http://bbs.xiguo.net/zq/zz/03.png',
  name: '慕寒',
  info: '合作10次'
}, {
  id: 3,
  img: 'http://bbs.xiguo.net/zq/zz/07.jpg',
  name: '银临',
  info: '合作6次'
}, {
  id: 4,
  img: 'http://bbs.xiguo.net/zq/zz/04.jpg',
  name: '吾恩',
  info: '合作4次'
}, {
  id: 5,
  img: 'http://bbs.xiguo.net/zq/zz/06.jpg',
  name: '竹桑',
  info: '合作3次'
}, {
  id: 6,
  img: 'http://bbs.xiguo.net/zq/zz/05.jpg',
  name: '双笙',
  info: '合作1次'
}];

var FindCard = function (_migi$Component) {
  _inherits(FindCard, _migi$Component);

  function FindCard() {
    var _ref;

    _classCallCheck(this, FindCard);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = FindCard.__proto__ || Object.getPrototypeOf(FindCard)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(FindCard, [{
    key: 'show',
    value: function show() {
      $(this.element).show();
      if (first) {
        first = false;
        this.ref.tags.autoWidth();
        this.ref.hotWorks.autoWidth();
        this.ref.hotAlbum.autoWidth();
        this.ref.hotAuthor.autoWidth();
      }
    }
  }, {
    key: 'hide',
    value: function hide() {
      $(this.element).hide();
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "find_card"]], [migi.createCp(_Banner2.default, []), migi.createCp(_Tags2.default, [["ref", "tags"]]), migi.createCp(_HotWorks2.default, [["ref", "hotWorks"], ["list", hotWorks]]), migi.createCp(_HotAlbum2.default, [["ref", "hotAlbum"], ["list", hotAlbum], ["title", "热门专辑"]]), migi.createCp(_HotAuthor2.default, [["ref", "hotAuthor"], ["list", hotAuthor], ["title", "热门作者"]]), migi.createCp(_PlayList2.default, [])]);
    }
  }]);

  return FindCard;
}(migi.Component);

migi.name(FindCard, "FindCard");exports.default = FindCard;

/***/ }),

/***/ 50:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Carousel = __webpack_require__(97);

var _Carousel2 = _interopRequireDefault(_Carousel);

var _FollowList = __webpack_require__(98);

var _FollowList2 = _interopRequireDefault(_FollowList);

var _Dynamic = __webpack_require__(11);

var _Dynamic2 = _interopRequireDefault(_Dynamic);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var FollowCard = function (_migi$Component) {
  _inherits(FollowCard, _migi$Component);

  function FollowCard() {
    var _ref;

    _classCallCheck(this, FollowCard);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = FollowCard.__proto__ || Object.getPrototypeOf(FollowCard)).call.apply(_ref, [this].concat(data)));

    var self = _this;
    _this.on(migi.Event.DOM, function () {
      util.postJSON('api/follow/GetUserFollow', { TagSkip: 0, TagTake: 10, AuthorSkip: 0, AuthorTake: 10, WorksSkip: 0, WorksTake: 10, DynamicSkip: 0, DynamicTake: 10 }, function (res) {
        if (res.success) {
          var _data = res.data;
          self.ref.carousel.list = _data.GetUserFollowWorks.data;
          self.ref.carousel.init();
          self.ref.followList.list1 = _data.GetUserFollowTag.data;
          self.ref.followList.autoWidth1();
          self.ref.followList.list2 = _data.GetUserFollowAuthor.data;
          self.ref.followList.autoWidth2();
          self.ref.dynamic.list = _data.GetAuthorDynamic.data;
        } else {}
      });
    });
    return _this;
  }

  _createClass(FollowCard, [{
    key: 'show',
    value: function show() {
      $(this.element).show();
    }
  }, {
    key: 'hide',
    value: function hide() {
      $(this.element).hide();
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "follow_card"]], [migi.createCp(_Carousel2.default, [["ref", "carousel"]]), migi.createCp(_FollowList2.default, [["ref", "followList"]]), migi.createCp(_Dynamic2.default, [["ref", "dynamic"]])]);
    }
  }]);

  return FollowCard;
}(migi.Component);

migi.name(FollowCard, "FollowCard");exports.default = FollowCard;

/***/ }),

/***/ 51:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Profile = __webpack_require__(100);

var _Profile2 = _interopRequireDefault(_Profile);

var _Types = __webpack_require__(101);

var _Types2 = _interopRequireDefault(_Types);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var MyCard = function (_migi$Component) {
  _inherits(MyCard, _migi$Component);

  function MyCard() {
    var _ref;

    _classCallCheck(this, MyCard);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = MyCard.__proto__ || Object.getPrototypeOf(MyCard)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(MyCard, [{
    key: 'show',
    value: function show() {
      $(this.element).show();
    }
  }, {
    key: 'hide',
    value: function hide() {
      $(this.element).hide();
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "my_card"]], [migi.createCp(_Profile2.default, []), migi.createVd("p", [["class", "sign"]], ["签名"]), migi.createCp(_Types2.default, [])]);
    }
  }]);

  return MyCard;
}(migi.Component);

migi.name(MyCard, "MyCard");exports.default = MyCard;

/***/ }),

/***/ 72:
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ 79:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "index.html";

/***/ }),

/***/ 93:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Banner = function (_migi$Component) {
  _inherits(Banner, _migi$Component);

  function Banner() {
    var _ref;

    _classCallCheck(this, Banner);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Banner.__proto__ || Object.getPrototypeOf(Banner)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Banner, [{
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "banner"]], [migi.createVd("pre", [], ["转圈一周精选", migi.createVd("br", []), "Vol 01"])]);
    }
  }]);

  return Banner;
}(migi.Component);

migi.name(Banner, "Banner");exports.default = Banner;

/***/ }),

/***/ 94:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var HotAuthor = function (_migi$Component) {
  _inherits(HotAuthor, _migi$Component);

  function HotAuthor() {
    var _ref;

    _classCallCheck(this, HotAuthor);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = HotAuthor.__proto__ || Object.getPrototypeOf(HotAuthor)).call.apply(_ref, [this].concat(data)));

    _this.list2 = _this.props.list || [];
    return _this;
  }

  _createClass(HotAuthor, [{
    key: 'autoWidth',
    value: function autoWidth() {
      this.$root = $(this.element);
      this.list = this.ref.list.element;
      this.$list = $(this.list);
      var $c = this.$list.find('.c');
      $c.width('css', '9999rem');
      var $ul = $c.find('ul');
      $c.css('width', $ul.width() + 1);
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "hot_author"]], [migi.createVd("h3", [], [this.props.title]), migi.createVd("div", [["class", "list"], ["ref", "list"]], [migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [], [new migi.Obj("list2", this, function () {
        return this.list2.map(function (item) {
          return migi.createVd("li", [], [migi.createVd("div", [["class", "pic"]], [migi.createVd("img", [["src", item.img]]), migi.createVd("b", [["class", "ge"]])]), migi.createVd("div", [["class", "txt"]], [item.name]), migi.createVd("div", [["class", "info"]], [item.info])]);
        });
      })])])])]);
    }
  }, {
    key: 'list2',
    set: function set(v) {
      this.__setBind("list2", v);this.__data("list2");
    },
    get: function get() {
      return this.__getBind("list2");
    }
  }]);

  return HotAuthor;
}(migi.Component);

migi.name(HotAuthor, "HotAuthor");exports.default = HotAuthor;

/***/ }),

/***/ 95:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var isStart = void 0;
var startX = void 0;

var HotWorks = function (_migi$Component) {
  _inherits(HotWorks, _migi$Component);

  function HotWorks() {
    var _ref;

    _classCallCheck(this, HotWorks);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = HotWorks.__proto__ || Object.getPrototypeOf(HotWorks)).call.apply(_ref, [this].concat(data)));

    _this.list2 = _this.props.list || [];
    return _this;
  }

  _createClass(HotWorks, [{
    key: 'autoWidth',
    value: function autoWidth() {
      this.$root = $(this.element);
      this.list = this.ref.list.element;
      this.$list = $(this.list);
      var $c = this.$list.find('.c');
      $c.width('css', '9999rem');
      var $ul = $c.find('ul');
      $c.css('width', $ul.width() + 1);
    }
  }, {
    key: 'start',
    value: function start(e) {
      if (e.touches.length != 1) {
        isStart = false;
      } else {
        isStart = true;
        startX = e.touches[0].pageX;
        this.$list.addClass('no_trans');
        this.$list.removeAttr('style');
        jsBridge.swipeRefresh(false);
      }
    }
  }, {
    key: 'move',
    value: function move(e) {
      if (isStart) {
        var x = e.touches[0].pageX;
        if (x > startX) {
          var left = this.list.scrollLeft;
          if (left == 0) {
            e.preventDefault();
            var diff = x - startX;
            this.$list.css('transform', 'translate3d(' + diff + 'px,0,0)');
            this.$list.css('-webkit-transform', 'translate3d(' + diff + 'px,0,0)');
          }
        }
      }
    }
  }, {
    key: 'end',
    value: function end(e) {
      this.$list.removeClass('no_trans');
      this.$list.removeAttr('style');
      jsBridge.swipeRefresh(true);
    }
  }, {
    key: 'click',
    value: function click(e, vd, tvd) {
      jsBridge.pushWindow('works.html');
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "hot_works"]], [migi.createVd("h3", [], ["热门作品"]), migi.createVd("div", [["class", "list"], ["ref", "list"]], [migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.click)]]]], [new migi.Obj("list2", this, function () {
        return this.list2.map(function (item) {
          if (item.type == 'audio') {
            return migi.createVd("li", [], [migi.createVd("div", [["class", "pic"]], [migi.createVd("div", [["class", "bg"]]), migi.createVd("div", [["class", "mask"]]), migi.createVd("div", [["class", "num"]], [migi.createVd("b", [["class", "audio"]]), "66w"]), migi.createVd("div", [["class", "ath"]], [item.author])]), migi.createVd("p", [["class", "txt"]], ["名字"])]);
          }
          return migi.createVd("li", [], [migi.createVd("div", [["class", "pic"]], [migi.createVd("img", [["src", item.img]]), migi.createVd("div", [["class", "mask"]]), migi.createVd("div", [["class", "num"]], [migi.createVd("b", [["class", "video"]]), item.num]), migi.createVd("div", [["class", "ath"]], [item.author])]), migi.createVd("p", [["class", "txt"]], [item.name])]);
        });
      })])])])]);
    }
  }, {
    key: 'list2',
    set: function set(v) {
      this.__setBind("list2", v);this.__data("list2");
    },
    get: function get() {
      return this.__getBind("list2");
    }
  }]);

  return HotWorks;
}(migi.Component);

migi.name(HotWorks, "HotWorks");exports.default = HotWorks;

/***/ }),

/***/ 96:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Tags = function (_migi$Component) {
  _inherits(Tags, _migi$Component);

  function Tags() {
    var _ref;

    _classCallCheck(this, Tags);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Tags.__proto__ || Object.getPrototypeOf(Tags)).call.apply(_ref, [this].concat(data)));

    _this.on(migi.Event.DOM, function () {
      this.autoWidth();
    });
    return _this;
  }

  _createClass(Tags, [{
    key: 'clickL1',
    value: function clickL1(e, vd, tvd) {
      $(tvd.element).toggleClass('on');
    }
  }, {
    key: 'clickL2',
    value: function clickL2(e, vd, tvd) {
      $(tvd.element).toggleClass('on');
    }
  }, {
    key: 'autoWidth',
    value: function autoWidth() {
      var $li = $(this.ref.l1.element);
      var $c = $li.find('.c');
      $c.css('width', '9999rem');
      var $ul = $c.find('ul');
      $c.css('width', $ul.width() + 1);
      $li = $(this.ref.l2.element);
      $c = $li.find('.c');
      $c.css('width', '9999rem');
      $ul = $c.find('ul');
      $c.css('width', $ul.width() + 1);
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "cp_tags"]], [migi.createVd("div", [["class", "l1"], ["ref", "l1"], ["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.clickL1)]]]], [migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [], [migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], [migi.createVd("span", [], ["音乐"])])]), migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], [migi.createVd("span", [], ["广播剧"])])]), migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], [migi.createVd("span", [], ["视频"])])]), migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], [migi.createVd("span", [], ["绘画"])])]), migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], [migi.createVd("span", [], ["COS"])])]), migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], [migi.createVd("span", [], ["游戏"])])])])])]), migi.createVd("div", [["class", "l2"], ["ref", "l2"], ["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.clickL2)]]]], [migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [], [migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], [migi.createVd("span", [], ["古风"])])]), migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], [migi.createVd("span", [], ["小清新"])])]), migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], [migi.createVd("span", [], ["阴阳师"])])]), migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], [migi.createVd("span", [], ["日漫"])])]), migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], [migi.createVd("span", [], ["流行"])])]), migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], [migi.createVd("span", [], ["剑网3"])])])])])])]);
    }
  }]);

  return Tags;
}(migi.Component);

migi.name(Tags, "Tags");exports.default = Tags;

/***/ }),

/***/ 97:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var screenWidth = $(window).width();
var itemWidth = void 0;
var isStart = void 0;
var isMove = void 0;
var startX = void 0;
var startY = void 0;
var endX = void 0;
var endY = void 0;
var curX = 0;
var lastCur = 0;

var Carousel = function (_migi$Component) {
  _inherits(Carousel, _migi$Component);

  function Carousel() {
    var _ref;

    _classCallCheck(this, Carousel);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Carousel.__proto__ || Object.getPrototypeOf(Carousel)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Carousel, [{
    key: "init",
    value: function init() {
      var screen = this.ref.screen;
      var $screen = $(screen.element);
      var $ul = this.$ul = $screen.find('ul');
      var $lis = this.$lis = $ul.find('li');
      itemWidth = $lis.eq(0).width();
      $screen.css('-webkit-transform', "translateX(" + (screenWidth - itemWidth) / 2 + "px)");
      $screen.css('transform', "translateX(" + (screenWidth - itemWidth) / 2 + "px)");
      $lis.eq(0).addClass('cur');

      var tag = this.ref.tag;
      var $tag = $(tag.element);
      var $tagLis = $tag.find('li');
      this.on('change', function (i) {
        $tag.find('li').removeClass('cur');
        $tag.find('li').eq(i).addClass('cur');
      });
      $tagLis.eq(0).addClass('cur');
    }
  }, {
    key: "start",
    value: function start(e) {
      if (this.$ul) {
        this.$lis = this.$ul.find('li');
        if (e.touches.length != 1) {
          isStart = false;
        } else {
          isStart = true;
          startX = e.touches[0].pageX;
          startY = e.touches[0].pageY;
          this.$ul.addClass('no_trans');
        }
      }
    }
  }, {
    key: "move",
    value: function move(e) {
      if (isMove) {
        e.preventDefault();
        endX = e.touches[0].pageX;
        var diffX = endX - startX;
        this.$ul.css('-webkit-transform', "translate3d(" + (curX + diffX) + "px, 0, 0)");
        this.$ul.css('transform', "translate3d(" + (curX + diffX) + "px, 0, 0)");
      } else if (isStart) {
        endX = e.touches[0].pageX;
        endY = e.touches[0].pageY;
        var _diffX = endX - startX;
        var diffY = endY - startY;
        if (Math.abs(diffY) < Math.abs(_diffX)) {
          e.preventDefault();
          isMove = true;
          this.$ul.css('-webkit-transform', "translate3d(" + (curX + _diffX) + "px, 0, 0)");
          this.$ul.css('transform', "translate3d(" + (curX + _diffX) + "px, 0, 0)");
          // jsBridge.swipeRefresh(false);
        } else {
          isStart = false;
        }
      }
    }
  }, {
    key: "end",
    value: function end(e) {
      if (isMove) {
        var itemLength = this.list.length;
        isStart = false;
        isMove = false;
        curX += endX - startX;
        if (curX >= -itemWidth / 2) {
          curX = 0;
          if (lastCur != 0) {
            this.$lis.removeClass('cur');
            this.$lis.eq(0).addClass('cur');
            lastCur = 0;
            this.emit('change', lastCur);
          }
        } else if (curX < -itemWidth * (itemLength - 1)) {
          curX = -itemWidth * (itemLength - 1);
          if (lastCur != itemLength - 1) {
            this.$lis.removeClass('cur');
            this.$lis.eq(itemLength - 1).addClass('cur');
            lastCur = itemLength - 1;
            this.emit('change', lastCur);
          }
        } else {
          var i = Math.abs(Math.round(curX / itemWidth));
          curX = -itemWidth * i;
          if (lastCur != i) {
            this.$lis.removeClass('cur');
            this.$lis.eq(i).addClass('cur');
            lastCur = i;
            this.emit('change', lastCur);
          }
        }
        this.$ul.removeClass('no_trans');
        this.$ul.css('-webkit-transform', "translate3d(" + curX + "px, 0, 0)");
        this.$ul.css('transform', "translate3d(" + curX + "px, 0, 0)");
      }
      // jsBridge.swipeRefresh(true);
    }
  }, {
    key: "click",
    value: function click(e, vd, tvd) {
      e.preventDefault();
      var href = tvd.props.href;
      if (href && href != '#') {
        jsBridge.pushWindow(href, {
          transparentTitle: true,
          titleBgColor: '#99000000'
        });
      }
    }
  }, {
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "carousel"], ["onTouchStart", new migi.Cb(this, this.start)], ["onTouchMove", new migi.Cb(this, this.move)], ["onTouchEnd", new migi.Cb(this, this.end)], ["onTouchCancel", new migi.Cb(this, this.end)]], [migi.createVd("div", [["class", "screen"], ["ref", "screen"], ["onClick", [[{ "a": { "_v": true } }, new migi.Cb(this, this.click)]]]], [migi.createVd("ul", [["class", "fn-clear"]], [new migi.Obj("list", this, function () {
        return this.list.map(function (item) {
          if (item.Tag_Pic) {
            return migi.createVd("li", [], [migi.createVd("a", [["href", "works.html?id=1"], ["style", "background:url(" + item.Tag_Pic + ") no-repeat center"]], [])]);
          }
          return migi.createVd("li", [], [migi.createVd("a", [["href", "works.html?id=" + item.ID]], [])]);
        });
      })])]), migi.createVd("div", [["class", "tag"], ["ref", "tag"]], [migi.createVd("ul", [], [new migi.Obj("list", this, function () {
        return this.list.map(function (item, i) {
          return migi.createVd("li", [], [i]);
        });
      })])])]);
    }
  }, {
    key: "list",
    set: function set(v) {
      this.__setBind("list", v);this.__data("list");
    },
    get: function get() {
      if (this.__initBind("list")) this.__setBind("list", []);return this.__getBind("list");
    }
  }]);

  return Carousel;
}(migi.Component);

migi.name(Carousel, "Carousel");exports.default = Carousel;

/***/ }),

/***/ 98:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var isStart = void 0;
var isMove = void 0;
var startX = void 0;
var startY = void 0;

var FollowList = function (_migi$Component) {
  _inherits(FollowList, _migi$Component);

  function FollowList() {
    var _ref;

    _classCallCheck(this, FollowList);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = FollowList.__proto__ || Object.getPrototypeOf(FollowList)).call.apply(_ref, [this].concat(data)));

    _this.on(migi.Event.DOM, function () {
      var ers = this.ref.ers;
      var $ers = $(ers.element);
      var $ersC = $ers.find('.c');
      var $ersUl = $ersC.find('ul');
      var perWidth = Math.round($ers.width() / 4.5);
      var style = document.createElement('style');
      style.innerText = '.follow_list .ers ul li{width:' + perWidth + 'px}';
      document.head.appendChild(style);
      $ersC.css('width', $ersUl.width() + 1);
    });
    return _this;
  }

  _createClass(FollowList, [{
    key: 'start',
    value: function start(e) {
      // if(e.touches.length != 1) {
      //   isStart = false;
      // }
      // else {
      //   isStart = true;
      //   startX = e.touches[0].pageX;
      //   startY = e.touches[0].pageY;
      // }
    }
  }, {
    key: 'move',
    value: function move(e) {
      // if(isMove) {}
      // else if(isStart) {
      //   isMove = true;
      //   let x = e.touches[0].pageX;
      //   let y = e.touches[0].pageY;console.log(y + ':' + startY);
      //   if(y < startY && Math.abs(y - startY) > Math.abs(x - startX)) {
      //     jsBridge.swipeRefresh($(window).scrollTop() === 0);
      //   }
      //   else {
      //     jsBridge.swipeRefresh(false);
      //   }
      // }
    }
  }, {
    key: 'end',
    value: function end() {
      // isStart = isMove = false;
    }
  }, {
    key: 'authorClick',
    value: function authorClick(e, vd, tvd) {
      e.preventDefault();
      var href = tvd.props.href;
      jsBridge.pushWindow(href, {
        transparentTitle: true
      });
    }
  }, {
    key: 'autoWidth1',
    value: function autoWidth1() {
      var $tags = $(this.ref.tags.element);
      var $tagsC = $tags.find('.c');
      var $tagsUl = $tagsC.find('ul');
      $tagsC.css('width', $tagsUl.width() + 1);
    }
  }, {
    key: 'autoWidth2',
    value: function autoWidth2() {
      var $ers = $(this.ref.ers.element);
      var $ersC = $ers.find('.c');
      var $ersUl = $ersC.find('ul');
      $ersC.css('width', $ersUl.width() + 1);
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "follow_list"]], [migi.createVd("h3", [], [migi.createVd("span", [], ["关注列表"])]), migi.createVd("div", [["class", "tags"], ["ref", "tags"]], [migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [], [new migi.Obj("list1", this, function () {
        return this.list1.map(function (item) {
          return migi.createVd("li", [], [item.Tag_Name]);
        });
      })])])]), migi.createVd("div", [["class", "ers"], ["ref", "ers"]], [migi.createVd("div", [["class", "c"]], [migi.createVd("ul", [["onClick", [[{ "a": { "_v": true } }, new migi.Cb(this, this.authorClick)]]]], [new migi.Obj("list2", this, function () {
        return this.list2.map(function (item) {
          return migi.createVd("li", [], [migi.createVd("a", [["href", 'author.html?id=' + item.ID]], [migi.createVd("div", [["class", "pic"]], [migi.createVd("img", [["src", item.Tag_Pic || 'src/common/blank.png']]), item.vip ? migi.createVd("b", []) : '']), migi.createVd("span", [], [item.Tag_Name]), migi.createVd("b", [])])]);
        });
      })])])])]);
    }
  }, {
    key: 'list1',
    get: function get() {
      return this._list1 || [];
    },
    set: function set(v) {
      this._list1 = v;
      var $tags = $(this.ref.tags.element);
      var $tagsC = $tags.find('.c');
      $tagsC.css('width', '9999rem');
      ;this.__array("list1", v);this.__data("list1");
    }
  }, {
    key: 'list2',
    get: function get() {
      return this._list2 || [];
    },
    set: function set(v) {
      this._list2 = v;
      var $ers = $(this.ref.ers.element);
      var $ersC = $ers.find('.c');
      $ersC.css('width', '9999rem');
      ;this.__array("list2", v);this.__data("list2");
    }
  }]);

  return FollowList;
}(migi.Component);

migi.name(FollowList, "FollowList");exports.default = FollowList;

/***/ }),

/***/ 99:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(79);

__webpack_require__(72);

var _Nav = __webpack_require__(47);

var _Nav2 = _interopRequireDefault(_Nav);

var _BottomNav = __webpack_require__(46);

var _BottomNav2 = _interopRequireDefault(_BottomNav);

var _FollowCard = __webpack_require__(50);

var _FollowCard2 = _interopRequireDefault(_FollowCard);

var _ZhuanquanCard = __webpack_require__(48);

var _ZhuanquanCard2 = _interopRequireDefault(_ZhuanquanCard);

var _FindCard = __webpack_require__(49);

var _FindCard2 = _interopRequireDefault(_FindCard);

var _MyCard = __webpack_require__(51);

var _MyCard2 = _interopRequireDefault(_MyCard);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

jsBridge.ready(function () {
  jsBridge.on('back', function (e) {
    e.preventDefault();
    jsBridge.moveTaskToBack();
  });
  var nav = migi.render(migi.createCp(_Nav2.default, []), document.body);

  var followCard = void 0,
      zhuanquanCard = void 0,
      findCard = void 0,
      myCard = void 0;

  followCard = migi.render(migi.createCp(_FollowCard2.default, []), document.body);

  var bottomNav = migi.render(migi.createCp(_BottomNav2.default, []), document.body);

  var last = followCard;
  bottomNav.on('change', function (i) {
    last.hide();
    switch (i) {
      case '0':
        if (!followCard) {
          followCard = migi.render(migi.createCp(_FollowCard2.default, []), document.body);
        }
        last = followCard;
        break;
      case '1':
        if (!zhuanquanCard) {
          zhuanquanCard = migi.render(migi.createCp(_ZhuanquanCard2.default, []), document.body);
        }
        last = zhuanquanCard;
        break;
      case '2':
        if (!findCard) {
          findCard = migi.render(migi.createCp(_FindCard2.default, []), document.body);
        }
        last = findCard;
        break;
      case '3':
        if (!myCard) {
          myCard = migi.render(migi.createCp(_MyCard2.default, []), document.body);
        }
        last = myCard;
        break;
    }
    last.show();
    if (i == 3) {
      nav.hide();
    } else {
      nav.show();
    }
  });
  // bottomNav.emit('change', 3);
});

/***/ })

/******/ });