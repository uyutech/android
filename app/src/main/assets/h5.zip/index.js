/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 49);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */,
/* 1 */,
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var core = __webpack_require__(20);

module.exports = core;

/***/ }),
/* 3 */,
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


// triggers an extra global event "ajaxBeforeSend" that's like "ajaxSend" but cancelable
function ajaxBeforeSend(xhr, settings) {
  var context = settings.context;
  if (settings.beforeSend && settings.beforeSend.call(context, xhr, settings) === false) return false;
}
function ajaxSuccess(data, xhr, settings, deferred) {
  var context = settings.context,
      status = 'success';
  settings.success && settings.success.call(context, data, status, xhr);
  if (deferred) deferred.resolveWith(context, [data, status, xhr]);
  ajaxComplete(status, xhr, settings);
}
// type: "timeout", "error", "abort", "parsererror"
function ajaxError(error, type, xhr, settings, deferred) {
  var context = settings.context;
  settings.error && settings.error.call(context, xhr, type, error);
  if (deferred) deferred.rejectWith(context, [xhr, type, error]);
  ajaxComplete(type, xhr, settings);
}
// status: "success", "notmodified", "error", "timeout", "abort", "parsererror"
function ajaxComplete(status, xhr, settings) {
  var context = settings.context;
  settings.complete && settings.complete.call(context, xhr, status);
}

module.exports = {
  ajaxBeforeSend: ajaxBeforeSend,
  ajaxSuccess: ajaxSuccess,
  ajaxError: ajaxError
};

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var event = __webpack_require__(21);

module.exports = event;

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _ENV = __webpack_require__(52);

var _ENV2 = _interopRequireDefault(_ENV);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var util = {
  isIPhone: function isIPhone() {
    return navigator.appVersion.match(/iphone/gi);
  },
  goto: function goto(url) {
    location.href = url;
  },
  autoSsl: function autoSsl(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return (url || '').replace(/^https?:\/\//i, '//');
  },
  img: function img(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url.replace(/\.(\w+)-\d*_\d*_\d*/, '.$1') : url;
  },
  img1600__80: function img1600__80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-1600__80' : url;
  },
  img1296_1296_80: function img1296_1296_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-1296_1296_80' : url;
  },
  img1200__80: function img1200__80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-1200__80' : url;
  },
  img980_980_80: function img980_980_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-980_980_80' : url;
  },
  img750_750_80: function img750_750_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-750_750_80' : url;
  },
  img720__80: function img720__80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-720__80' : url;
  },
  img600_600_80: function img600_600_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-600_600_80' : url;
  },
  img600__80: function img600__80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-600__80' : url;
  },
  img480_480_80: function img480_480_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-480_480_80' : url;
  },
  img332_332_80: function img332_332_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-332_332_80' : url;
  },
  img288__80: function img288__80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-288__80' : url;
  },
  img288_288_80: function img288_288_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-288_288_80' : url;
  },
  img240_240_80: function img240_240_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-240_240_80' : url;
  },
  img220_220_80: function img220_220_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-240_240_80' : url;
  },
  img208_208_80: function img208_208_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-208_208_80' : url;
  },
  img200_200: function img200_200(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-200_200' : url;
  },
  img200_200_80: function img200_200_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-200_200_80' : url;
  },
  img192_192: function img192_192(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-192_192' : url;
  },
  img172_172_80: function img172_172_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-172_172_80' : url;
  },
  img150_150_80: function img150_150_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-150_150_80' : url;
  },
  img144_: function img144_(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-144_' : url;
  },
  img144_144: function img144_144(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-144_144' : url;
  },
  img144_144_80: function img144_144_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-144_144_80' : url;
  },
  img132_132_80: function img132_132_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-132_132_80' : url;
  },
  img128_128_80: function img128_128_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-120_120_80' : url;
  },
  img120_120: function img120_120(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-120_120' : url;
  },
  img120_120_80: function img120_120_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-120_120_80' : url;
  },
  img100_100: function img100_100(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-100_100' : url;
  },
  img96_96_80: function img96_96_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-90_90' : url;
  },
  img90_90: function img90_90(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-90_90' : url;
  },
  img64_64_80: function img64_64_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-64_64_80' : url;
  },
  img60_60: function img60_60(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-60_60' : url;
  },
  img60_60_80: function img60_60_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-60_60_80' : url;
  },
  img__60: function img__60(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-__60' : url;
  },
  img48_48_80: function img48_48_80(url) {
    if (!/\/\/zhuanquan\./i.test(url)) {
      return url;
    }
    return url ? url + '-48_48_80' : url;
  },
  decode: function decode(str) {
    return str.replace(/&lt;/g, '<').replace(/&amp;/g, '&');
  },
  formatPost: function formatPost(str) {},
  formatTime: function formatTime(time) {
    if (!time) {
      return '00:00';
    }
    var res = '';
    if (time >= 1000 * 60 * 60) {
      var hour = Math.floor(time / (1000 * 60 * 60));
      time -= 1000 * 60 * 60 * hour;
      res += hour + ':';
    }
    if (time >= 1000 * 60) {
      var minute = Math.floor(time / (1000 * 60));
      time -= 1000 * 60 * minute;
      if (minute < 10) {
        minute = '0' + minute;
      }
      res += minute + ':';
    } else {
      res += '00:';
    }
    var second = Math.floor(time / 1000);
    if (second < 10) {
      second = '0' + second;
    }
    res += second;
    return res;
  },
  formatDate: function formatDate(time) {
    time = new Date(time);
    var now = Date.now();
    var diff = now - time;
    if (diff >= 1000 * 60 * 60 * 24 * 365) {
      return Math.floor(diff / (1000 * 60 * 60 * 24 * 365)) + '年前';
    }
    if (diff >= 1000 * 60 * 60 * 24 * 30) {
      return Math.floor(diff / (1000 * 60 * 60 * 24 * 30)) + '月前';
    }
    if (diff >= 1000 * 60 * 60 * 24) {
      return Math.floor(diff / (1000 * 60 * 60 * 24)) + '天前';
    }
    if (diff >= 1000 * 60 * 60) {
      return Math.floor(diff / (1000 * 60 * 60)) + '小时前';
    }
    if (diff >= 1000 * 60) {
      return Math.floor(diff / (1000 * 60)) + '分钟前';
    }
    return '刚刚';
  },
  ERROR_MESSAGE: '人气大爆发，请稍后再试。',
  getJSON: function getJSON(url, data, success, error, type, timeout) {
    if (typeof data === 'function') {
      timeout = error;
      error = success;
      success = data;
      data = {};
    }
    if (typeof success !== 'function') {
      success = function success() {};
      timeout = error;
      error = success;
    }
    if (typeof error !== 'function') {
      timeout = error;
      error = function error() {};
    }
    return _ENV2.default.ajax(url, data, success, error, 'GET', timeout);
  },
  postJSON: function postJSON(url, data, success, error, type, timeout) {
    if (typeof data === 'function') {
      timeout = error;
      error = success;
      success = data;
      data = {};
    }
    if (typeof success !== 'function') {
      success = function success() {};
      timeout = error;
      error = success;
    }
    if (typeof error !== 'function') {
      timeout = error;
      error = function error() {};
    }
    return _ENV2.default.ajax(url, data, success, error, 'POST', timeout);
  }
}; /**
    * Created by army on 2017/5/20.
    */

exports.default = util;

/***/ }),
/* 7 */,
/* 8 */,
/* 9 */,
/* 10 */,
/* 11 */,
/* 12 */,
/* 13 */,
/* 14 */,
/* 15 */,
/* 16 */,
/* 17 */,
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var ajax = __webpack_require__(19);

module.exports = ajax;

/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var $ = __webpack_require__(2),
    util = __webpack_require__(4);

__webpack_require__(5);

__webpack_require__(22);

__webpack_require__(23);

module.exports = $;

/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var Yocto = function () {
  var undefined,
      key,
      $,
      classList,
      emptyArray = [],
      _slice = emptyArray.slice,
      _filter = emptyArray.filter,

  // [Opt:C] 增加win变量缓存window
  win = window,
      document = win.document,
      elementDisplay = {},
      classCache = {},
      fragmentRE = /^\s*<(\w+|!)[^>]*>/,
      class2type = {},
      toString = class2type.toString,
      zepto = {},
      camelize,
      uniq,

  //[Opt:B][V1.0+] 由于已经删除prop方法，因此原propMap变量一并删除

  //[Opt:C] 去掉isArray旧方法的兼容
  isArray = Array.isArray;

  zepto.matches = function (element, selector) {
    // [Opt:C] 将原本在父级作用域的变量转移至局部变量
    var tempParent = document.createElement('div');

    if (!selector || !element || element.nodeType !== 1) return false;
    // [Opt:C] 去除对moz o 的支持，一般情况下，是不会遇到以上的浏览器，不针对moz和o做专门的优化
    var matchesSelector = element.webkitMatchesSelector || element.matchesSelector;
    if (matchesSelector) return matchesSelector.call(element, selector);
    // fall back to performing a selector:
    var match,
        parent = element.parentNode,
        temp = !parent;
    if (temp) (parent = tempParent).appendChild(element);
    match = ~zepto.qsa(parent, selector).indexOf(element);
    temp && tempParent.removeChild(element);
    return match;
  };

  //opt by 完颜
  //Get string type of an object.
  //Possible types are:
  //null undefined boolean number string function array date regexp object error.
  function type(obj) {
    return obj == null ? String(obj) : class2type[toString.call(obj)] || "object";
  }

  function isFunction(value) {
    return type(value) == "function";
  }

  function isWindow(obj) {
    return obj != null && obj == obj.window;
  }

  function isDocument(obj) {
    return obj != null && obj.nodeType == obj.DOCUMENT_NODE;
  }

  function isObject(obj) {
    return type(obj) == "object";
  }

  function isPlainObject(obj) {
    return isObject(obj) && !isWindow(obj) && Object.getPrototypeOf(obj) == Object.prototype;
  }

  function likeArray(obj) {
    return typeof obj.length == 'number';
  }

  function compact(array) {
    return _filter.call(array, function (item) {
      return item != null;
    });
  }

  function flatten(array) {
    return array.length > 0 ? $.fn.concat.apply([], array) : array;
  }

  //将中划线连接符转化为驼峰字符串
  camelize = function camelize(str) {
    return str.replace(/-+(.)?/g, function (match, chr) {
      return chr ? chr.toUpperCase() : '';
    });
  };

  uniq = function uniq(array) {
    return _filter.call(array, function (item, idx) {
      return array.indexOf(item) == idx;
    });
  };

  function classRE(name) {
    return name in classCache ? classCache[name] : classCache[name] = new RegExp('(^|\\s)' + name + '(\\s|$)');
  }

  function _children(element) {
    return 'children' in element ? _slice.call(element.children) : $.map(element.childNodes, function (node) {
      if (node.nodeType == 1) return node;
    });
  }

  // `$.zepto.fragment` takes a html string and an optional tag name
  // to generate DOM nodes nodes from the given html string.
  // The generated DOM nodes are returned as an array.
  // This function can be overriden in plugins for example to make
  // it compatible with browsers that don't support the DOM fully.
  zepto.fragment = function (html, name) {
    // [Opt:C] 将原本在父级作用域的变量转移至局部变量
    var table = document.createElement('table'),
        tableRow = document.createElement('tr'),
        containers = {
      'tr': document.createElement('tbody'),
      'tbody': table, 'thead': table, 'tfoot': table,
      'td': tableRow, 'th': tableRow,
      '*': document.createElement('div')
    },
        tagExpanderRE = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/ig,
        singleTagRE = /^<(\w+)\s*\/?>(?:<\/\1>|)$/,

    // special attributes that should be get/set via method calls
    methodAttributes = ['val', 'css', 'html', 'text', 'data', 'width', 'height', 'offset'];

    var dom, nodes, container;

    // A special case optimization for a single tag
    if (singleTagRE.test(html)) dom = $(document.createElement(RegExp.$1));

    if (!dom) {
      if (html.replace) html = html.replace(tagExpanderRE, "<$1></$2>");
      if (name === undefined) name = fragmentRE.test(html) && RegExp.$1;
      if (!(name in containers)) name = '*';

      container = containers[name];
      container.innerHTML = '' + html;
      dom = $.each(_slice.call(container.childNodes), function () {
        container.removeChild(this);
      });
    }

    //[Opt:B-1][V1.0+] 移除 $(htmlString, attributes) 的api方法支持

    return dom;
  };

  // `$.zepto.Z` swaps out the prototype of the given `dom` array
  // of nodes with `$.fn` and thus supplying all the Zepto functions
  // to the array. Note that `__proto__` is not supported on Internet
  // Explorer. This method can be overriden in plugins.
  zepto.Z = function (dom, selector) {
    dom = dom || [];
    dom.__proto__ = $.fn;
    dom.selector = selector || '';
    return dom;
  };

  // `$.zepto.isZ` should return `true` if the given object is a Zepto
  // collection. This method can be overriden in plugins.
  zepto.isZ = function (object) {
    return object instanceof zepto.Z;
  };

  // `$.zepto.init` is Zepto's counterpart to jQuery's `$.fn.init` and
  // takes a CSS selector and an optional context (and handles various
  // special cases).
  // This method can be overriden in plugins.
  zepto.init = function (selector, context) {
    var dom;
    // If nothing given, return an empty Zepto collection
    if (!selector) return zepto.Z();
    // Optimize for string selectors
    else if (typeof selector == 'string') {
        selector = selector.trim();
        // If it's a html fragment, create nodes from it
        // Note: In both Chrome 21 and Firefox 15, DOM error 12
        // is thrown if the fragment doesn't begin with <
        if (selector[0] == '<' && fragmentRE.test(selector)) dom = zepto.fragment(selector, RegExp.$1, context), selector = null;
        // If there's a context, create a collection on that context first, and select
        // nodes from there
        else if (context !== undefined) return $(context).find(selector);
          // If it's a CSS selector, use it to select nodes.
          else dom = zepto.qsa(document, selector);
      }
      // If a function is given, call it when the DOM is ready
      else if (isFunction(selector)) return $(document).ready(selector);
        // If a Zepto collection is given, just return it
        else if (zepto.isZ(selector)) return selector;else {
            // normalize array if an array of nodes is given
            if (isArray(selector)) dom = compact(selector);
            // Wrap DOM nodes.
            else if (isObject(selector)) dom = [selector], selector = null;
              // If it's a html fragment, create nodes from it
              else if (fragmentRE.test(selector)) dom = zepto.fragment(selector.trim(), RegExp.$1, context), selector = null;
                // If there's a context, create a collection on that context first, and select
                // nodes from there
                else if (context !== undefined) return $(context).find(selector);
                  // And last but no least, if it's a CSS selector, use it to select nodes.
                  else dom = zepto.qsa(document, selector);
          }
    // create a new Zepto collection from the nodes found
    return zepto.Z(dom, selector);
  };

  // `$` will be the base `Zepto` object. When calling this
  // function just call `$.zepto.init, which makes the implementation
  // details of selecting nodes and creating Zepto collections
  // patchable in plugins.
  $ = function $(selector, context) {
    return zepto.init(selector, context);
  };

  // Copy all but undefined properties from one or more
  // objects to the `target` object.
  $.extend = function (target) {
    //[Opt:C] 将全局函数编程内部函数
    var extend = function extend(target, source, deep) {
      for (key in source) {
        if (deep && (isPlainObject(source[key]) || isArray(source[key]))) {
          if (isPlainObject(source[key]) && !isPlainObject(target[key])) target[key] = {};
          if (isArray(source[key]) && !isArray(target[key])) target[key] = [];
          extend(target[key], source[key], deep);
        } else if (source[key] !== undefined) target[key] = source[key];
      }
    };

    var deep,
        args = _slice.call(arguments, 1);
    if (typeof target == 'boolean') {
      deep = target;
      target = args.shift();
    }
    args.forEach(function (arg) {
      extend(target, arg, deep);
    });
    return target;
  };

  // `$.zepto.qsa` is Zepto's CSS selector implementation which
  // uses `document.querySelectorAll` and optimizes for some special cases, like `#id`.
  // This method can be overriden in plugins.
  // opt by 轩与
  zepto.qsa = function (element, selector) {
    // [Opt:C] 将全局simpleSelectorRE转到局部
    var found,
        simpleSelectorRE = /^[\w-]*$/,
        maybeID = selector[0] == '#',
        maybeClass = !maybeID && selector[0] == '.',
        nameOnly = maybeID || maybeClass ? selector.slice(1) : selector,
        // Ensure that a 1 char tag name still gets checked
    isSimple = /^[\w-]*$/.test(nameOnly);
    return isDocument(element) && isSimple && maybeID ? (found = element.getElementById(nameOnly)) ? [found] : [] : element.nodeType !== 1 && element.nodeType !== 9 ? [] : _slice.call(isSimple && !maybeID ? maybeClass ? element.getElementsByClassName(nameOnly) : // If it's simple, it could be a class
    element.getElementsByTagName(selector) : // Or a tag
    element.querySelectorAll(selector) // Or it's not simple, and we need to query all
    );
  };

  function filtered(nodes, selector) {
    return selector == null ? $(nodes) : $(nodes).filter(selector);
  }

  $.contains = function (parent, node) {
    return parent !== node && parent.contains(node);
  };

  function funcArg(context, arg, idx, payload) {
    return isFunction(arg) ? arg.call(context, idx, payload) : arg;
  }

  function setAttribute(node, name, value) {
    value == null ? node.removeAttribute(name) : node.setAttribute(name, value);
  }

  // access className property while respecting SVGAnimatedString
  function className(node, value) {
    var klass = node.className,
        svg = klass && klass.baseVal !== undefined;

    if (value === undefined) return svg ? klass.baseVal : klass;
    svg ? klass.baseVal = value : node.className = value;
  }

  // "true"  => true
  // "false" => false
  // "null"  => null
  // "42"    => 42
  // "42.5"  => 42.5
  // "08"    => "08"
  // JSON    => parse if valid
  // String  => self
  function deserializeValue(value) {
    var num;
    try {
      return value ? value == "true" || (value == "false" ? false : value == "null" ? null : !/^0/.test(value) && !isNaN(num = Number(value)) ? num : /^[\[\{]/.test(value) ? $.parseJSON(value) : value) : value;
    } catch (e) {
      return value;
    }
  }

  $.type = type;
  $.isFunction = isFunction;
  $.isWindow = isWindow;
  $.isArray = isArray;
  $.isPlainObject = isPlainObject;

  //[Opt:A] 移除$.isEmptyObject方法，官网无公开，core内无引用
  //$.isEmptyObject

  $.camelCase = camelize;
  $.trim = function (str) {
    return str == null ? "" : String.prototype.trim.call(str);
  };

  // plugin compatibility
  $.uuid = 0;
  $.support = {};
  $.expr = {};

  $.map = function (elements, callback) {
    var value,
        values = [],
        i,
        key;
    if (likeArray(elements)) for (i = 0; i < elements.length; i++) {
      value = callback(elements[i], i);
      if (value != null) values.push(value);
    } else for (key in elements) {
      value = callback(elements[key], key);
      if (value != null) values.push(value);
    }
    return flatten(values);
  };

  $.each = function (elements, callback) {
    var i, key;
    if (likeArray(elements)) {
      for (i = 0; i < elements.length; i++) {
        if (callback.call(elements[i], i, elements[i]) === false) return elements;
      }
    } else {
      for (key in elements) {
        if (callback.call(elements[key], key, elements[key]) === false) return elements;
      }
    }

    return elements;
  };

  // [Opt:C] 删除不必要的if (win.JSON)
  $.parseJSON = JSON.parse;

  // Populate the class2type map
  $.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), function (i, name) {
    class2type["[object " + name + "]"] = name.toLowerCase();
  });

  // Define methods that will be available on all
  // Zepto collections
  $.fn = {
    // Because a collection acts like an array
    // copy over these useful array functions.
    forEach: emptyArray.forEach,
    reduce: emptyArray.reduce,
    push: emptyArray.push,
    sort: emptyArray.sort,
    indexOf: emptyArray.indexOf,
    concat: emptyArray.concat,

    // `map` and `slice` in the jQuery API work differently
    // from their array counterparts
    map: function map(fn) {
      return $($.map(this, function (el, i) {
        return fn.call(el, i, el);
      }));
    },
    slice: function slice() {
      return $(_slice.apply(this, arguments));
    },
    ready: function ready(callback) {
      //[Opt:C]将原本在父级作用域的变量转移至局部变量
      var readyRE = /complete|loaded|interactive/;

      // need to check if document.body exists for IE as that browser reports
      // document ready when it hasn't yet created the body element
      // [Opt:C] 不做ie的兼容
      if (readyRE.test(document.readyState)) callback($);else document.addEventListener('DOMContentLoaded', function () {
        callback($);
      }, false);
      return this;
    },
    get: function get(idx) {
      return idx === undefined ? _slice.call(this) : this[idx >= 0 ? idx : idx + this.length];
    },
    toArray: function toArray() {
      return this.get();
    },
    size: function size() {
      return this.length;
    },
    remove: function remove() {
      return this.each(function () {
        if (this.parentNode != null) this.parentNode.removeChild(this);
      });
    },
    each: function each(callback) {
      emptyArray.every.call(this, function (el, idx) {
        return callback.call(el, idx, el) !== false;
      });
      return this;
    },
    filter: function filter(selector) {
      if (isFunction(selector)) return this.not(this.not(selector));
      return $(_filter.call(this, function (element) {
        return zepto.matches(element, selector);
      }));
    },
    add: function add(selector, context) {
      return $(uniq(this.concat($(selector, context))));
    },
    is: function is(selector) {
      return this.length > 0 && zepto.matches(this[0], selector);
    },
    not: function not(selector) {
      var nodes = [];
      if (isFunction(selector) && selector.call !== undefined) this.each(function (idx) {
        if (!selector.call(this, idx)) nodes.push(this);
      });else {
        var excludes = typeof selector == 'string' ? this.filter(selector) : likeArray(selector) && isFunction(selector.item) ? _slice.call(selector) : $(selector);
        this.forEach(function (el) {
          if (excludes.indexOf(el) < 0) nodes.push(el);
        });
      }
      return $(nodes);
    },
    has: function has(selector) {
      return this.filter(function () {
        return isObject(selector) ? $.contains(this, selector) : $(this).find(selector).size();
      });
    },
    eq: function eq(idx) {
      return idx === -1 ? this.slice(idx) : this.slice(idx, +idx + 1);
    },
    first: function first() {
      var el = this[0];
      return el && !isObject(el) ? el : $(el);
    },
    last: function last() {
      var el = this[this.length - 1];
      return el && !isObject(el) ? el : $(el);
    },
    find: function find(selector) {
      var result,
          $this = this;
      if ((typeof selector === "undefined" ? "undefined" : _typeof(selector)) == 'object') result = $(selector).filter(function () {
        var node = this;
        return emptyArray.some.call($this, function (parent) {
          return $.contains(parent, node);
        });
      });else if (this.length == 1) result = $(zepto.qsa(this[0], selector));else result = this.map(function () {
        return zepto.qsa(this, selector);
      });
      return result;
    },
    //[Opt:B][V1.0+] : closest的父级选择，代理parents，去除原有的第二个参数支持
    closest: function closest(selector) {
      if (zepto.matches(this[0], selector)) return $(this[0]);else return $(this.parents(selector).get(0));
    },
    parents: function parents(selector) {
      var ancestors = [],
          nodes = this;
      while (nodes.length > 0) {
        nodes = $.map(nodes, function (node) {
          if ((node = node.parentNode) && !isDocument(node) && ancestors.indexOf(node) < 0) {
            ancestors.push(node);
            return node;
          }
        });
      }return filtered(ancestors, selector);
    },
    parent: function parent(selector) {
      return filtered(uniq(this.pluck('parentNode')), selector);
    },
    children: function children(selector) {
      return filtered(this.map(function () {
        return _children(this);
      }), selector);
    },
    //[Opt:B][V1.0+] : contents已经转移至plugin
    siblings: function siblings(selector) {
      return filtered(this.map(function (i, el) {
        return _filter.call(_children(el.parentNode), function (child) {
          return child !== el;
        });
      }), selector);
    },
    //[Opt:A] : empty已经转移至plugin
    // `pluck` is borrowed from Prototype.js
    pluck: function pluck(property) {
      return $.map(this, function (el) {
        return el[property];
      });
    },
    show: function show() {
      // [Opt:C] 提取函数
      var getDisplay = function getDisplay(DOM) {
        return getComputedStyle(DOM, '').getPropertyValue("display");
      };
      return this.each(function () {
        this.style.display == "none" && (this.style.display = '');
        if (getDisplay(this) == "none") {
          // [Opt:C] 将defaultDisplay方法局部化
          var defaultDisplay = function defaultDisplay(nodeName) {
            var element, display;
            if (!elementDisplay[nodeName]) {
              element = document.createElement(nodeName);
              document.body.appendChild(element);
              display = getDisplay(element);
              element.parentNode.removeChild(element);
              display == "none" && (display = "block");
              elementDisplay[nodeName] = display;
            }
            return elementDisplay[nodeName];
          };
          this.style.display = defaultDisplay(this.nodeName);
        }
      });
    },
    replaceWith: function replaceWith(newContent) {
      return this.before(newContent).remove();
    },
    //[Opt:A] : wrap系列方法，已经转移至plugin
    clone: function clone() {
      return this.map(function () {
        return this.cloneNode(true);
      });
    },
    hide: function hide() {
      return this.css("display", "none");
    },
    toggle: function toggle(setting) {
      return this.each(function () {
        var el = $(this);
        (setting === undefined ? el.css("display") == "none" : setting) ? el.show() : el.hide();
      });
    },
    prev: function prev(selector) {
      return $(this.pluck('previousElementSibling')).filter(selector || '*');
    },
    next: function next(selector) {
      return $(this.pluck('nextElementSibling')).filter(selector || '*');
    },
    html: function html(_html) {
      return arguments.length === 0 ? this.length > 0 ? this[0].innerHTML : null : this.each(function (idx) {
        var originHtml = this.innerHTML;
        this.innerHTML = '';
        $(this).append(funcArg(this, _html, idx, originHtml));
      });
    },
    text: function text(_text) {
      return arguments.length === 0 ? this.length > 0 ? this[0].textContent : null : this.each(function () {
        this.textContent = _text === undefined ? '' : '' + _text;
      });
    },
    attr: function attr(name, value) {
      var result;
      return typeof name == 'string' && value === undefined ? this.length == 0 || this[0].nodeType !== 1 ? undefined : name == 'value' && this[0].nodeName == 'INPUT' ? this.val() : !(result = this[0].getAttribute(name)) && name in this[0] ? this[0][name] : result : this.each(function (idx) {
        if (this.nodeType !== 1) return;
        if (isObject(name)) for (key in name) {
          setAttribute(this, key, name[key]);
        } else setAttribute(this, name, funcArg(this, value, idx, this.getAttribute(name)));
      });
    },
    removeAttr: function removeAttr(name) {
      return this.each(function () {
        this.nodeType === 1 && setAttribute(this, name);
      });
    },
    data: function data(name, value) {
      //[Opt:C]将原本在父级作用域的变量转移至局部变量
      var capitalRE = /([A-Z])/g,
          data = this.attr('data-' + name.replace(capitalRE, '-$1').toLowerCase(), value);
      return data !== null ? deserializeValue(data) : undefined;
    },
    val: function val(value) {
      return arguments.length === 0 ? this[0] && (this[0].multiple ? $(this[0]).find('option').filter(function () {
        return this.selected;
      }).pluck('value') : this[0].value) : this.each(function (idx) {
        this.value = funcArg(this, value, idx, this.value);
      });
    },
    //[Opt:B][V1.0+] 去除offset的coordinates参数
    offset: function offset() {
      if (this.length == 0) return null;
      var obj = this[0].getBoundingClientRect();
      return {
        left: obj.left + win.pageXOffset,
        top: obj.top + win.pageYOffset,
        width: Math.round(obj.width),
        height: Math.round(obj.height)
      };
    },
    css: function css(property, value) {
      //智能补足：分析css方法中传入的value，如果name是在cssNumber清单外的纯数字，则增加px单位
      //[Opt:C] 将全局函数装到局部函数
      var maybeAddPx = function maybeAddPx(name, value) {
        //[Opt:C]将原本在父级作用域的变量转移至局部变量
        var cssNumber = {
          'column-count': 1,
          'columns': 1,
          'font-weight': 1,
          'line-height': 1,
          'opacity': 1,
          'z-index': 1,
          'zoom': 1
        };
        return typeof value == "number" && !cssNumber[dasherize(name)] ? value + "px" : value;
      };

      //将字符串(驼峰)转换为dasherized(中划线连接符形式命名)字符
      //[Opt:C] 将全局函数装到局部函数
      var dasherize = function dasherize(str) {
        return str.replace(/::/g, '/').replace(/([A-Z]+)([A-Z][a-z])/g, '$1_$2').replace(/([a-z\d])([A-Z])/g, '$1_$2').replace(/_/g, '-').toLowerCase();
      };

      if (arguments.length < 2) {
        var element = this[0];
        if (!element) return;
        var computedStyle = getComputedStyle(element, '');
        if (typeof property == 'string') return element.style[camelize(property)] || computedStyle.getPropertyValue(property);else if (isArray(property)) {
          var props = {};
          $.each(isArray(property) ? property : [property], function (_, prop) {
            props[prop] = element.style[camelize(prop)] || computedStyle.getPropertyValue(prop);
          });
          return props;
        }
      }

      var css = '';
      if (type(property) == 'string') {
        if (!value && value !== 0) this.each(function () {
          this.style.removeProperty(dasherize(property));
        });else css = dasherize(property) + ":" + maybeAddPx(property, value);
      } else {
        for (key in property) {
          if (!property[key] && property[key] !== 0) this.each(function () {
            this.style.removeProperty(dasherize(key));
          });else css += dasherize(key) + ':' + maybeAddPx(key, property[key]) + ';';
        }
      }

      return this.each(function () {
        this.style.cssText += ';' + css;
      });
    },
    index: function index(element) {
      return element ? this.indexOf($(element)[0]) : this.parent().children().indexOf(this[0]);
    },
    hasClass: function hasClass(name) {
      if (!name) return false;
      return emptyArray.some.call(this, function (el) {
        return this.test(className(el));
      }, classRE(name));
    },
    addClass: function addClass(name) {
      if (!name) return this;
      return this.each(function (idx) {
        classList = [];
        var cls = className(this),
            newName = funcArg(this, name, idx, cls);
        newName.split(/\s+/g).forEach(function (klass) {
          if (!$(this).hasClass(klass)) classList.push(klass);
        }, this);
        classList.length && className(this, cls + (cls ? " " : "") + classList.join(" "));
      });
    },
    removeClass: function removeClass(name) {
      return this.each(function (idx) {
        if (name === undefined) return className(this, '');
        classList = className(this);
        funcArg(this, name, idx, classList).split(/\s+/g).forEach(function (klass) {
          classList = classList.replace(classRE(klass), " ");
        });
        className(this, classList.trim());
      });
    },
    toggleClass: function toggleClass(name, when) {
      if (!name) return this;
      return this.each(function (idx) {
        var $this = $(this),
            names = funcArg(this, name, idx, className(this));
        names.split(/\s+/g).forEach(function (klass) {
          (when === undefined ? !$this.hasClass(klass) : when) ? $this.addClass(klass) : $this.removeClass(klass);
        });
      });
    },
    scrollTop: function scrollTop(value) {
      if (!this.length) return;
      var hasScrollTop = 'scrollTop' in this[0];
      if (value === undefined) return hasScrollTop ? this[0].scrollTop : this[0].pageYOffset;
      return this.each(hasScrollTop ? function () {
        this.scrollTop = value;
      } : function () {
        this.scrollTo(this.scrollX, value);
      });
    }
    //[Opt:A] : scrollLeft已经转移至plugin
    //[Opt:A] : position已经转移至plugin
    //[Opt:A] : offsetParent已经转移至plugin


    // for now
  };$.fn.detach = $.fn.remove

  // Generate the `width` and `height` functions
  // todo:高度值bug待修复
  ;
  ['width', 'height'].forEach(function (dimension) {
    var dimensionProperty = dimension.replace(/./, function (m) {
      return m[0].toUpperCase();
    });

    $.fn[dimension] = function (value) {
      var offset,
          el = this[0];
      if (value === undefined) return isWindow(el) ? el['inner' + dimensionProperty] : isDocument(el) ? el.documentElement['scroll' + dimensionProperty] : (offset = this.offset()) && offset[dimension];else return this.each(function (idx) {
        el = $(this);
        el.css(dimension, funcArg(this, value, idx, el[dimension]()));
      });
    };
  })

  // Generate the `after`, `prepend`, `before`, `append`,
  // `insertAfter`, `insertBefore`, `appendTo`, and `prependTo` methods.
  // [Opt:C] 将全部变量，改为局部变量
  ;
  ['after', 'prepend', 'before', 'append'].forEach(function (operator, operatorIndex) {
    var inside = operatorIndex % 2; //=> prepend, append

    $.fn[operator] = function () {
      // arguments can be nodes, arrays of nodes, Zepto objects and HTML strings
      var argType,
          nodes = $.map(arguments, function (arg) {
        argType = type(arg);
        return argType == "object" || argType == "array" || arg == null ? arg : zepto.fragment(arg);
      }),
          parent,
          copyByClone = this.length > 1;
      if (nodes.length < 1) return this;

      return this.each(function (_, target) {
        parent = inside ? target : target.parentNode;

        // convert all methods to a "before" operation
        target = operatorIndex == 0 ? target.nextSibling : operatorIndex == 1 ? target.firstChild : operatorIndex == 2 ? target : null;

        // [Opt:C] 全部变量局部化
        var traverseNode = function traverseNode(node, fun) {
          fun(node);
          for (var key in node.childNodes) {
            traverseNode(node.childNodes[key], fun);
          }
        };

        nodes.forEach(function (node) {

          if (copyByClone) node = node.cloneNode(true);else if (!parent) return $(node).remove();

          traverseNode(parent.insertBefore(node, target), function (el) {
            if (el.nodeName != null && el.nodeName.toUpperCase() === 'SCRIPT' && (!el.type || el.type === 'text/javascript') && !el.src) win['eval'].call(win, el.innerHTML);
          });
        });
      });
    };

    // after    => insertAfter
    // prepend  => prependTo
    // before   => insertBefore
    // append   => appendTo
    $.fn[inside ? operator + 'To' : 'insert' + (operatorIndex ? 'Before' : 'After')] = function (html) {
      $(html)[operator](this);
      return this;
    };
  });

  zepto.Z.prototype = $.fn;

  // Export internal API functions in the `$.zepto` namespace
  zepto.uniq = uniq;
  zepto.deserializeValue = deserializeValue;
  $.zepto = $.yocto = zepto;

  return $;
}();

module.exports = Yocto;

/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var $ = __webpack_require__(2);

// Event Module
var _zid = 1,
    undefined,
    slice = Array.prototype.slice,
    isFunction = $.isFunction,
    isString = function isString(obj) {
  return typeof obj == 'string';
},
    handlers = {},
    specialEvents = {};

specialEvents.click = specialEvents.mousedown = specialEvents.mouseup = specialEvents.mousemove = 'MouseEvents';

function zid(element) {
  return element._zid || (element._zid = _zid++);
}
function findHandlers(element, event, fn, selector) {
  event = parse(event);
  if (event.ns) var matcher = matcherFor(event.ns);
  return (handlers[zid(element)] || []).filter(function (handler) {
    return handler && (!event.e || handler.e == event.e) && (!event.ns || matcher.test(handler.ns)) && (!fn || zid(handler.fn) === zid(fn)) && (!selector || handler.sel == selector);
  });
}
function parse(event) {
  var parts = ('' + event).split('.');
  // e——事件名 ns——命名空间
  return { e: parts[0], ns: parts.slice(1).sort().join(' ') };
}
function matcherFor(ns) {
  return new RegExp('(?:^| )' + ns.replace(' ', ' .* ?') + '(?: |$)');
}

function eventCapture(handler, captureSetting) {
  return handler.del && (handler.e === 'focus' || handler.e === 'blur') || !!captureSetting;
}

function add(element, events, fn, data, selector, delegator, capture) {
  var id = zid(element),
      set = handlers[id] || (handlers[id] = []);
  events.split(/\s/).forEach(function (event) {
    if (event == 'ready') return $(document).ready(fn);
    var handler = parse(event);
    handler.fn = fn;
    handler.sel = selector;

    handler.del = delegator;
    var callback = delegator || fn;
    handler.proxy = function (e) {
      //Android下如果同时存在tap逻辑并且事件类型为click,阻止浏览器自己触发的点击事件
      if (navigator.userAgent.toLowerCase().indexOf('android') > -1 && $.gestures && $.gestures.tap && handler.e === 'click' && !e.animaClick) {
        if (e.stopImmediatePropagation) {
          e.stopImmediatePropagation();
        } else {
          e.propagationStopped = true;
        }

        e.stopPropagation();
        e.preventDefault();

        return false;
      }

      e = compatible(e);
      if (e.isImmediatePropagationStopped()) return;
      e.data = data;
      var result = callback.apply(element, e._args == undefined ? [e] : [e].concat(e._args));
      if (result === false) e.preventDefault(), e.stopPropagation();
      return result;
    };
    handler.i = set.length;
    set.push(handler);
    if ('addEventListener' in element) {
      // 自定义手势逻辑
      if ($.gestures && $.gestures.list && $.gestures.list[handler.e]) {
        $.gestures.list[handler.e](element);
      }

      element.addEventListener(handler.e, handler.proxy, eventCapture(handler, capture));
    }
  });
}
function remove(element, events, fn, selector, capture) {
  var id = zid(element);(events || '').split(/\s/).forEach(function (event) {
    findHandlers(element, event, fn, selector).forEach(function (handler) {
      delete handlers[id][handler.i];
      if ('removeEventListener' in element) element.removeEventListener(handler.e, handler.proxy, eventCapture(handler, capture));
    });
  });
}

$.event = { add: add, remove: remove };

$.proxy = function (fn, context) {
  if (isFunction(fn)) {
    var proxyFn = function proxyFn() {
      return fn.apply(context, arguments);
    };
    proxyFn._zid = zid(fn);
    return proxyFn;
  } else if (isString(context)) {
    return $.proxy(fn[context], fn);
  } else {
    throw new TypeError("expected function");
  }
};

$.fn.one = function (event, selector, data, callback) {
  return this.on(event, selector, data, callback, 1);
};

var returnTrue = function returnTrue() {
  return true;
},
    returnFalse = function returnFalse() {
  return false;
},
    ignoreProperties = /^([A-Z]|returnValue$|layer[XY]$)/,
    eventMethods = {
  preventDefault: 'isDefaultPrevented',
  stopImmediatePropagation: 'isImmediatePropagationStopped',
  stopPropagation: 'isPropagationStopped'
};

function compatible(event, source) {
  if (source || !event.isDefaultPrevented) {
    source || (source = event);

    $.each(eventMethods, function (name, predicate) {
      var sourceMethod = source[name];
      event[name] = function () {
        this[predicate] = returnTrue;
        return sourceMethod && sourceMethod.apply(source, arguments);
      };
      event[predicate] = returnFalse;
    });

    if (source.defaultPrevented !== undefined ? source.defaultPrevented : 'returnValue' in source ? source.returnValue === false : source.getPreventDefault && source.getPreventDefault()) event.isDefaultPrevented = returnTrue;
  }
  return event;
}

function createProxy(event) {
  var key,
      proxy = { originalEvent: event };
  for (key in event) {
    if (!ignoreProperties.test(key) && event[key] !== undefined) proxy[key] = event[key];
  }return compatible(proxy, event);
}

$.fn.on = function (event, selector, data, callback, one) {
  var autoRemove,
      delegator,
      $this = this;
  if (event && !isString(event)) {
    $.each(event, function (type, fn) {
      $this.on(type, selector, data, fn, one);
    });
    return $this;
  }

  if (!isString(selector) && !isFunction(callback) && callback !== false) callback = data, data = selector, selector = undefined;
  if (isFunction(data) || data === false) callback = data, data = undefined;

  if (callback === false) callback = returnFalse;

  return $this.each(function (_, element) {
    if (one) autoRemove = function autoRemove(e) {
      remove(element, e.type, callback);
      return callback.apply(this, arguments);
    };

    if (selector) delegator = function delegator(e) {
      var evt,
          match = $(e.target).closest(selector, element).get(0);
      if (match && match !== element) {
        evt = $.extend(createProxy(e), { currentTarget: match, liveFired: element });
        return (autoRemove || callback).apply(match, [evt].concat(slice.call(arguments, 1)));
      }
    };

    add(element, event, callback, data, selector, delegator || autoRemove);
  });
};
$.fn.off = function (event, selector, callback) {
  var $this = this;
  if (event && !isString(event)) {
    $.each(event, function (type, fn) {
      $this.off(type, selector, fn);
    });
    return $this;
  }

  if (!isString(selector) && !isFunction(callback) && callback !== false) callback = selector, selector = undefined;

  if (callback === false) callback = returnFalse;

  return $this.each(function () {
    remove(this, event, callback, selector);
  });
};

$.fn.trigger = function (event, args) {
  event = isString(event) || $.isPlainObject(event) ? $.Event(event) : compatible(event);
  event._args = args;
  return this.each(function () {
    // items in the collection might not be DOM elements
    if ('dispatchEvent' in this) this.dispatchEvent(event);else $(this).triggerHandler(event, args);
  });
};

// triggers event handlers on current element just as if an event occurred,
// doesn't trigger an actual event, doesn't bubble
$.fn.triggerHandler = function (event, args) {
  var e, result;
  this.each(function (i, element) {
    e = createProxy(isString(event) ? $.Event(event) : event);
    e._args = args;
    e.target = element;
    $.each(findHandlers(element, event.type || event), function (i, handler) {
      result = handler.proxy(e);
      if (e.isImmediatePropagationStopped()) return false;
    });
  });
  return result;
}

// shortcut methods for `.bind(event, fn)` for each event type
;('focusin focusout load resize scroll unload click dblclick ' +
// 'mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave '+
'change select keydown keypress keyup error').split(' ').forEach(function (event) {
  $.fn[event] = function (callback) {
    return callback ? this.on(event, callback) : this.trigger(event);
  };
});['focus', 'blur'].forEach(function (name) {
  $.fn[name] = function (callback) {
    if (callback) this.on(name, callback);else this.each(function () {
      try {
        this[name]();
      } catch (e) {}
    });
    return this;
  };
});

$.Event = function (type, props) {
  if (!isString(type)) props = type, type = props.type;
  var event = document.createEvent(specialEvents[type] || 'Events'),
      bubbles = true;
  if (props) for (var name in props) {
    name == 'bubbles' ? bubbles = !!props[name] : event[name] = props[name];
  }event.initEvent(type, bubbles, true);
  return compatible(event);
};

module.exports = $;

/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var $ = __webpack_require__(2),
    util = __webpack_require__(4);

__webpack_require__(5);

var jsonpID = Date.now(),
    document = window.document,
    ajaxBeforeSend = util.ajaxBeforeSend,
    ajaxSuccess = util.ajaxSuccess,
    ajaxError = util.ajaxError;

$.ajaxJSONP = function (options, deferred) {
  if (!('type' in options)) return $.ajax && $.ajax(options);

  var _callbackName = options.jsonpCallback,
      callbackName = ($.isFunction(_callbackName) ? _callbackName() : _callbackName) || 'jsonp' + ++jsonpID,
      script = document.createElement('script'),
      originalCallback = window[callbackName],
      responseData,
      abort = function abort(errorType) {
    $(script).triggerHandler('error', errorType || 'abort');
  },
      xhr = { abort: abort },
      abortTimeout;

  if (deferred) deferred.promise(xhr);

  $(script).on('load error', function (e, errorType) {
    clearTimeout(abortTimeout);
    $(script).off().remove();

    if (e.type == 'error' || !responseData) {
      ajaxError(null, errorType || 'error', xhr, options, deferred);
    } else {
      ajaxSuccess(responseData[0], xhr, options, deferred);
    }

    window[callbackName] = originalCallback;
    if (responseData && $.isFunction(originalCallback)) originalCallback(responseData[0]);

    originalCallback = responseData = undefined;
  });

  if (ajaxBeforeSend(xhr, options) === false) {
    abort('abort');
    return xhr;
  }

  window[callbackName] = function () {
    responseData = arguments;
  };

  script.src = options.url.replace(/\?(.+)=\?/, '?$1=' + callbackName);
  document.head.appendChild(script);

  if (options.timeout > 0) abortTimeout = setTimeout(function () {
    abort('timeout');
  }, options.timeout);

  return xhr;
};

module.exports = $;

/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var $ = __webpack_require__(2),
    util = __webpack_require__(4);

__webpack_require__(5);

var key,
    name,
    rscript = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
    scriptTypeRE = /^(?:text|application)\/javascript/i,
    xmlTypeRE = /^(?:text|application)\/xml/i,
    jsonType = 'application/json',
    htmlType = 'text/html',
    blankRE = /^\s*$/,
    ajaxBeforeSend = util.ajaxBeforeSend,
    ajaxSuccess = util.ajaxSuccess,
    ajaxError = util.ajaxError;

function empty() {}

$.ajaxSettings = {
  // Default type of request
  type: 'GET',
  // Callback that is executed before request
  beforeSend: empty,
  // Callback that is executed if the request succeeds
  success: empty,
  // Callback that is executed the the server drops error
  error: empty,
  // Callback that is executed on request complete (both: error and success)
  complete: empty,
  // The context for the callbacks
  context: null,
  // Whether to trigger "global" Ajax events
  global: true,
  // Transport
  xhr: function xhr() {
    return new window.XMLHttpRequest();
  },
  // MIME types mapping
  // IIS returns Javascript as "application/x-javascript"
  accepts: {
    script: 'text/javascript, application/javascript, application/x-javascript',
    json: jsonType,
    xml: 'application/xml, text/xml',
    html: htmlType,
    text: 'text/plain'
  },
  // Whether the request is to another domain
  crossDomain: false,
  // Default timeout
  timeout: 0,
  // Whether data should be serialized to string
  processData: true,
  // Whether the browser should be allowed to cache GET responses
  cache: true
};

function mimeToDataType(mime) {
  if (mime) mime = mime.split(';', 2)[0];
  return mime && (mime == htmlType ? 'html' : mime == jsonType ? 'json' : scriptTypeRE.test(mime) ? 'script' : xmlTypeRE.test(mime) && 'xml') || 'text';
}

function appendQuery(url, query) {
  if (query == '') return url;
  return (url + '&' + query).replace(/[&?]{1,2}/, '?');
}

// serialize payload and append it to the URL for GET requests
function serializeData(options) {
  if (options.processData && options.data && $.type(options.data) != "string") options.data = $.param(options.data, options.traditional);
  if (options.data && (!options.type || options.type.toUpperCase() == 'GET')) options.url = appendQuery(options.url, options.data), options.data = undefined;
}

$.ajax = function (options) {
  var settings = $.extend({}, options || {}),
      deferred = $.Deferred && $.Deferred();
  for (key in $.ajaxSettings) {
    if (settings[key] === undefined) settings[key] = $.ajaxSettings[key];
  }if (!settings.crossDomain) settings.crossDomain = /^([\w-]+:)?\/\/([^\/]+)/.test(settings.url) && RegExp.$2 != window.location.host;

  if (!settings.url) settings.url = window.location.toString();
  serializeData(settings);
  if (settings.cache === false) settings.url = appendQuery(settings.url, '_=' + Date.now());

  var dataType = settings.dataType,
      hasPlaceholder = /\?.+=\?/.test(settings.url);
  if (dataType == 'jsonp' || hasPlaceholder) {
    if (!hasPlaceholder) settings.url = appendQuery(settings.url, settings.jsonp ? settings.jsonp + '=?' : settings.jsonp === false ? '' : 'callback=?');
    return $.ajaxJSONP(settings, deferred);
  }

  var mime = settings.accepts[dataType],
      headers = {},
      setHeader = function setHeader(name, value) {
    headers[name.toLowerCase()] = [name, value];
  },
      protocol = /^([\w-]+:)\/\//.test(settings.url) ? RegExp.$1 : window.location.protocol,
      xhr = settings.xhr(),
      nativeSetHeader = xhr.setRequestHeader,
      abortTimeout;

  if (deferred) deferred.promise(xhr);

  if (!settings.crossDomain) setHeader('X-Requested-With', 'XMLHttpRequest');
  setHeader('Accept', mime || '*/*');
  if (mime) {
    if (mime.indexOf(',') > -1) mime = mime.split(',', 2)[0];
    xhr.overrideMimeType && xhr.overrideMimeType(mime);
  }
  if (settings.contentType || settings.contentType !== false && settings.data && settings.type.toUpperCase() != 'GET') setHeader('Content-Type', settings.contentType || 'application/x-www-form-urlencoded');

  if (settings.headers) for (name in settings.headers) {
    setHeader(name, settings.headers[name]);
  }xhr.setRequestHeader = setHeader;

  var async = 'async' in settings ? settings.async : true;
  xhr.open(settings.type, settings.url, async);

  xhr.onreadystatechange = function () {
    if (xhr.readyState == 4) {
      xhr.onreadystatechange = empty;
      clearTimeout(abortTimeout);
      var result,
          error = false;
      if (xhr.status >= 200 && xhr.status < 300 || xhr.status == 304 || xhr.status == 0 && protocol == 'file:') {
        dataType = dataType || mimeToDataType(xhr.getResponseHeader('content-type'));
        result = xhr.responseText;

        try {
          // http://perfectionkills.com/global-eval-what-are-the-options/
          if (dataType == 'script') (1, eval)(result);else if (dataType == 'xml') result = xhr.responseXML;else if (dataType == 'json') result = blankRE.test(result) ? null : $.parseJSON(result);
        } catch (e) {
          error = e;
        }

        if (error) ajaxError(error, 'parsererror', xhr, settings, deferred);else ajaxSuccess(result, xhr, settings, deferred);
      } else {
        ajaxError(xhr.statusText || null, xhr.status ? 'error' : 'abort', xhr, settings, deferred);
      }
    }
  };

  if (ajaxBeforeSend(xhr, settings) === false) {
    xhr.abort();
    ajaxError(null, 'abort', xhr, settings, deferred);
    return xhr;
  }

  for (name in headers) {
    nativeSetHeader.apply(xhr, headers[name]);
  } // if (settings.timeout > 0) abortTimeout = setTimeout(function(){
  //     xhr.onreadystatechange = empty
  //     xhr.abort()
  //     ajaxError(null, 'timeout', xhr, settings, deferred)
  //   }, settings.timeout)

  // 使用原生timeout属性
  if (settings.timeout > 0) {
    xhr.timeout = settings.timeout;
    xhr.ontimeout = function () {
      xhr.onreadystatechange = empty;
      xhr.abort();
      ajaxError(null, 'timeout', xhr, settings, deferred);
    };
  }

  // avoid sending empty string (#319)
  xhr.send(settings.data ? settings.data : null);
  return xhr;
};

// handle optional data/success arguments
function parseArguments(url, data, success, dataType) {
  if ($.isFunction(data)) dataType = success, success = data, data = undefined;
  if (!$.isFunction(success)) dataType = success, success = undefined;
  return {
    url: url,
    data: data,
    success: success,
    dataType: dataType
  };
}

$.get = function () /* url, data, success, dataType */{
  return $.ajax(parseArguments.apply(null, arguments));
};

$.post = function () /* url, data, success, dataType */{
  var options = parseArguments.apply(null, arguments);
  options.type = 'POST';
  return $.ajax(options);
};

$.getJSON = function () /* url, data, success */{
  var options = parseArguments.apply(null, arguments);
  options.dataType = 'json';
  return $.ajax(options);
};

$.fn.load = function (url, data, success) {
  if (!this.length) return this;
  var self = this,
      parts = url.split(/\s/),
      selector,
      options = parseArguments(url, data, success),
      callback = options.success;
  if (parts.length > 1) options.url = parts[0], selector = parts[1];
  options.success = function (response) {
    self.html(selector ? $('<div>').html(response.replace(rscript, "")).find(selector) : response);
    callback && callback.apply(self, arguments);
  };
  $.ajax(options);
  return this;
};

var escape = encodeURIComponent;

function serialize(params, obj, traditional, scope) {
  var type,
      array = $.isArray(obj),
      hash = $.isPlainObject(obj);
  $.each(obj, function (key, value) {
    type = $.type(value);
    if (scope) key = traditional ? scope : scope + '[' + (hash || type == 'object' || type == 'array' ? key : '') + ']';
    // handle data in serializeArray() format
    if (!scope && array) params.add(value.name, value.value);
    // recurse into nested objects
    else if (type == "array" || !traditional && type == "object") serialize(params, value, traditional, key);else params.add(key, value);
  });
}

$.param = function (obj, traditional) {
  var params = [];
  params.add = function (k, v) {
    this.push(escape(k) + '=' + escape(v));
  };
  serialize(params, obj, traditional);
  return params.join('&').replace(/%20/g, '+');
};

module.exports = $;

/***/ }),
/* 24 */,
/* 25 */,
/* 26 */,
/* 27 */,
/* 28 */,
/* 29 */,
/* 30 */,
/* 31 */,
/* 32 */,
/* 33 */,
/* 34 */,
/* 35 */,
/* 36 */,
/* 37 */,
/* 38 */,
/* 39 */,
/* 40 */,
/* 41 */,
/* 42 */,
/* 43 */,
/* 44 */,
/* 45 */,
/* 46 */,
/* 47 */,
/* 48 */,
/* 49 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(50);

__webpack_require__(51);

var _util = __webpack_require__(6);

var _util2 = _interopRequireDefault(_util);

var _BotNav = __webpack_require__(55);

var _BotNav2 = _interopRequireDefault(_BotNav);

var _Find = __webpack_require__(56);

var _Find2 = _interopRequireDefault(_Find);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

jsBridge.ready(function () {
  jsBridge.on('back', function (e) {
    e.preventDefault();
    jsBridge.moveTaskToBack();
  });

  var find = migi.render(migi.createCp(_Find2.default, []), '#page');
  var botNav = migi.render(migi.createCp(_BotNav2.default, []), '#page');

  _util2.default.postJSON('/h5/find/index', function (res) {
    if (res.success) {
      find.setData(res.data);
    }
  });
});

/***/ }),
/* 50 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "index.html";

/***/ }),
/* 51 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 52 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _animaYoctoAjax = __webpack_require__(18);

var _animaYoctoAjax2 = _interopRequireDefault(_animaYoctoAjax);

var _animaQuerystring = __webpack_require__(53);

var _animaQuerystring2 = _interopRequireDefault(_animaQuerystring);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Created by army8735 on 2017/9/15.
 */

exports.default = {
  ajax: function ajax(url, data, _success, _error, type, timeout) {
    // 兼容无host
    if (!/^http(s)?:\/\//.test(url)) {
      url = 'http://h5.dev.circling.cc2/' + url.replace(/^\//, '');
    }
    Object.keys(data).forEach(function (k) {
      if (data[k] === undefined || data[k] === null) {
        delete data[k];
      }
    });
    if (url.indexOf('?') === -1) {
      url += '?_=' + Date.now();
    } else {
      url += '&_=' + Date.now();
    }
    function load() {
      return _animaYoctoAjax2.default.ajax({
        url: url,
        data: data,
        dataType: 'json',
        crossDomain: true,
        timeout: timeout || 30000,
        type: type || 'get',
        // ajax 跨域设置必须加上
        beforeSend: function beforeSend(xhr) {
          xhr.withCredentials = true;
        },
        success: function success(data, state, xhr) {
          _success(data, state, xhr);
        },
        error: function error(data) {
          if (!_error.__hasExec) {
            _error.__hasExec = true;
            _error(data || {});
          }
        }
      });
    }
    return load();
  }
};

/***/ }),
/* 53 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(54);

/***/ }),
/* 54 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// QueryString
// ---------------
// This module provides utilities for dealing with query strings.
//
// Thanks to:
//  - http://nodejs.org/docs/v0.4.7/api/querystring.html
//  - http://developer.yahoo.com/yui/3/api/QueryString.html
//  - https://github.com/lifesinger/dew/tree/master/lib/querystring


// var QueryString = exports;

var QueryString = {};

// The escape/unescape function used by stringify/parse, provided so that it
// could be overridden if necessary. This is important in cases where
// non-standard delimiters are used, if the delimiters would not normally be
// handled properly by the built-in (en|de)codeURIComponent functions.
QueryString.escape = encodeURIComponent;

QueryString.unescape = function (s) {
    // The + character is interpreted as a space on the server side as well as
    // generated by forms with spaces in their fields.
    return decodeURIComponent(s.replace(/\+/g, ' '));
};

/**
 * Serialize an object to a query string. Optionally override the default
 * separator and assignment characters.
 *
 * stringify({foo: 'bar'})
 *   // returns 'foo=bar'
 *
 * stringify({foo: 'bar', baz: 'bob'}, ';', ':')
 *   // returns 'foo:bar;baz:bob'
 */
QueryString.stringify = function (obj, sep, eq, arrayKey) {
    if (!isPlainObject(obj)) return '';

    sep = sep || '&';
    eq = eq || '=';
    arrayKey = arrayKey || false;

    var buf = [],
        key,
        val;
    var escape = QueryString.escape;

    for (key in obj) {
        if (!hasOwnProperty.call(obj, key)) continue;

        val = obj[key];
        key = QueryString.escape(key);

        // val is primitive value
        if (isPrimitive(val)) {
            buf.push(key, eq, escape(val + ''), sep);
        }
        // val is not empty array
        else if (isArray(val) && val.length) {
                for (var i = 0; i < val.length; i++) {
                    if (isPrimitive(val[i])) {
                        buf.push(key, (arrayKey ? escape('[]') : '') + eq, escape(val[i] + ''), sep);
                    }
                }
            }
            // ignore other cases, including empty array, Function, RegExp, Date etc.
            else {
                    buf.push(key, eq, sep);
                }
    }

    buf.pop();
    return buf.join('');
};

/**
 * Deserialize a query string to an object. Optionally override the default
 * separator and assignment characters.
 *
 * parse('a=b&c=d')
 *   // returns {a: 'b', c: 'c'}
 */
QueryString.parse = function (str, sep, eq) {
    var ret = {};

    if (typeof str !== 'string' || trim(str).length === 0) {
        return ret;
    }

    var pairs = str.split(sep || '&');
    eq = eq || '=';
    var unescape = QueryString.unescape;

    for (var i = 0; i < pairs.length; i++) {

        var pair = pairs[i].split(eq);
        var key = unescape(trim(pair[0]));
        var val = unescape(trim(pair.slice(1).join(eq)));

        var m = key.match(/^(\w+)\[\]$/);
        if (m && m[1]) {
            key = m[1];
        }

        if (hasOwnProperty.call(ret, key)) {
            if (!isArray(ret[key])) {
                ret[key] = [ret[key]];
            }
            ret[key].push(val);
        } else {
            ret[key] = m ? [val] : val;
        }
    }

    return ret;
};

// Helpers

var toString = Object.prototype.toString;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var isArray = Array.isArray || function (val) {
    return toString.call(val) === '[object Array]';
};
var trim = String.prototype.trim ? function (str) {
    return str == null ? '' : String.prototype.trim.call(str);
} : function (str) {
    return str == null ? '' : str.toString().replace(/^\s+/, '').replace(/\s+$/, '');
};

/**
 * Checks to see if an object is a plain object (created using "{}" or
 * "new Object()" or "new FunctionClass()").
 */
function isPlainObject(o) {
    /**
     * NOTES:
     * isPlainObject(node = document.getElementById("xx")) -> false
     * toString.call(node):
     *   ie678 === '[object Object]', other === '[object HTMLElement]'
     * 'isPrototypeOf' in node:
     *   ie678 === false, other === true
     */
    return o && toString.call(o) === '[object Object]' && 'isPrototypeOf' in o;
}

/**
 * If the type of o is null, undefined, number, string, boolean,
 * return true.
 */
function isPrimitive(o) {
    return o !== Object(o);
}

module.exports = QueryString;

/***/ }),
/* 55 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var BotNav = function (_migi$Component) {
  _inherits(BotNav, _migi$Component);

  function BotNav() {
    var _ref;

    _classCallCheck(this, BotNav);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = BotNav.__proto__ || Object.getPrototypeOf(BotNav)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(BotNav, [{
    key: 'click',
    value: function click(e, vd, tvd) {
      var $elem = $(tvd.element);
      var rel = tvd.props.rel;
      this.cur($elem, rel);
    }
  }, {
    key: 'cur',
    value: function cur($elem, rel) {
      if ($elem.hasClass('cur')) {
        return;
      }
      if (rel) {
        $(this.element).find('.cur').removeClass('cur');
        $elem.addClass('cur');
        this.emit('change', rel);
      }
    }
  }, {
    key: 'setCurrent',
    value: function setCurrent(i) {
      this.cur($(this.element).find('li[rel="' + i + '"]'), i);
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "bot-nav"], ["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.click)]]]], [migi.createVd("ul", [], [migi.createVd("li", [["class", "find cur"], ["rel", "0"]], [migi.createVd("b", [["class", "icon"]]), migi.createVd("span", [], ["发现"])]), migi.createVd("li", [["class", "zhuanquan"], ["rel", "1"]], [migi.createVd("b", [["class", "icon"]]), migi.createVd("span", [], ["转圈"])]), migi.createVd("li", [["class", "new cur"]], [migi.createVd("b", [["class", "icon"]])]), migi.createVd("li", [["class", "follow"], ["rel", "2"]], [migi.createVd("b", [["class", "icon"]]), migi.createVd("span", [], ["关注"])]), migi.createVd("li", [["class", "my"], ["rel", "3"]], [migi.createVd("b", [["class", "icon"]]), migi.createVd("span", [], ["我的"])])])]);
    }
  }]);

  return BotNav;
}(migi.Component);

migi.name(BotNav, "BotNav");exports.default = BotNav;

/***/ }),
/* 56 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _util = __webpack_require__(6);

var _util2 = _interopRequireDefault(_util);

var _HotCircle = __webpack_require__(57);

var _HotCircle2 = _interopRequireDefault(_HotCircle);

var _HotWork = __webpack_require__(58);

var _HotWork2 = _interopRequireDefault(_HotWork);

var _HotMusicAlbum = __webpack_require__(59);

var _HotMusicAlbum2 = _interopRequireDefault(_HotMusicAlbum);

var _HotAuthor = __webpack_require__(60);

var _HotAuthor2 = _interopRequireDefault(_HotAuthor);

var _HotPost = __webpack_require__(61);

var _HotPost2 = _interopRequireDefault(_HotPost);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var take = 10;
var skip = take;

var Find = function (_migi$Component) {
  _inherits(Find, _migi$Component);

  function Find() {
    var _ref;

    _classCallCheck(this, Find);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Find.__proto__ || Object.getPrototypeOf(Find)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Find, [{
    key: 'setData',
    value: function setData(data) {
      var self = this;

      self.ref.hotCircle.dataList = data.hotCircleList;
      self.ref.hotCircle.hasData = true;
      self.ref.hotCircle.autoWidth();

      self.ref.hotWork.dataList = data.hotWorkList;
      self.ref.hotWork.hasData = true;
      self.ref.hotWork.autoWidth();

      self.ref.hotMusiceAlbum.dataList = data.hotMusicAlbumList;
      self.ref.hotMusiceAlbum.hasData = true;
      self.ref.hotMusiceAlbum.autoWidth();

      self.ref.hotAuthor.dataList = data.hotAuthorList;
      self.ref.hotAuthor.hasData = true;
      self.ref.hotAuthor.autoWidth();

      self.ref.hotPost.hasData = true;
      self.ref.hotPost.data = !!data.hotPostList.length;
      self.ref.hotPost.setData(data.hotPostList);

      var $window = $(window);
      $window.on('scroll', function () {
        self.checkMore($window);
      });
    }
  }, {
    key: 'checkMore',
    value: function checkMore($window) {
      var self = this;
      var WIN_HEIGHT = $window.height();
      var HEIGHT = $(document.body).height();
      var bool = void 0;
      bool = $window.scrollTop() + WIN_HEIGHT + 30 > HEIGHT;
      if (!self.loading && !self.loadEnd && bool) {
        self.load();
      }
    }
  }, {
    key: 'load',
    value: function load() {
      var self = this;
      var hotPost = self.ref.hotPost;
      self.loading = true;
      hotPost.message = '正在加载...';
      _util2.default.postJSON('/api/find/hotPostList', { skip: skip, take: take }, function (res) {
        if (res.success) {
          var data = res.data;
          skip += take;
          hotPost.setData(data.data);
          if (!data.data.length || data.data.length < take) {
            self.loadEnd = true;
            hotPost.message = '已经到底了';
          } else {
            hotPost.message = '';
          }
        } else {
          jsBridge.toast(res.message || _util2.default.ERROR_MESSAGE);
        }
        self.loading = false;
      }, function (res) {
        jsBridge.toast(res.message || _util2.default.ERROR_MESSAGE);
        self.loading = false;
      });
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "find"]], [migi.createVd("h4", [], ["热门圈子"]), migi.createCp(_HotCircle2.default, [["ref", "hotCircle"]]), migi.createVd("h4", [], ["热门作品"]), migi.createCp(_HotWork2.default, [["ref", "hotWork"]]), migi.createVd("h4", [], ["热门专辑"]), migi.createCp(_HotMusicAlbum2.default, [["ref", "hotMusiceAlbum"]]), migi.createVd("h4", [], ["入驻作者"]), migi.createCp(_HotAuthor2.default, [["ref", "hotAuthor"]]), migi.createVd("h4", [], ["转圈"]), migi.createCp(_HotPost2.default, [["ref", "hotPost"]])]);
    }
  }, {
    key: 'loading',
    set: function set(v) {
      this.__setBind("loading", v);this.__data("loading");
    },
    get: function get() {
      return this.__getBind("loading");
    }
  }, {
    key: 'loadEnd',
    set: function set(v) {
      this.__setBind("loadEnd", v);this.__data("loadEnd");
    },
    get: function get() {
      return this.__getBind("loadEnd");
    }
  }]);

  return Find;
}(migi.Component);

migi.name(Find, "Find");exports.default = Find;

/***/ }),
/* 57 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _util = __webpack_require__(6);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var HotCircle = function (_migi$Component) {
  _inherits(HotCircle, _migi$Component);

  function HotCircle() {
    var _ref;

    _classCallCheck(this, HotCircle);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = HotCircle.__proto__ || Object.getPrototypeOf(HotCircle)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(HotCircle, [{
    key: 'autoWidth',
    value: function autoWidth() {
      var $list = $(this.element).find('.list');
      var $c = $list.find('.c');
      $c.css('width', '9999rem');
      var $ul = $c.find('ul');
      $c.css('width', $ul.width() + 1);
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "cp-hotcircle"]], [new migi.Obj("hasData", this, function () {
        return this.hasData ? migi.createVd("div", [["class", "list"]], [migi.createVd("div", [["class", "c"]], [this.dataList && this.dataList.length ? migi.createVd("ul", [], [this.dataList.map(function (item) {
          return migi.createVd("li", [], [migi.createVd("a", [["href", '/circle/' + item.TagID], ["class", "pic"]], [migi.createVd("img", [["src", _util2.default.autoSsl(_util2.default.img288_288_80(item.TagCover)) || '/src/common/blank.png']])]), migi.createVd("a", [["href", '/circle/' + item.TagID], ["class", "txt"]], [migi.createVd("span", [["class", "name"]], [item.TagName]), migi.createVd("span", [["class", "fans"]], [item.FansNumber || 0]), migi.createVd("span", [["class", "comment"]], [item.Popular || 0])])]);
        })]) : migi.createVd("div", [["class", "empty"]], ["暂无数据"])])]) : migi.createVd("div", [["class", "placeholder"]]);
      })]);
    }
  }, {
    key: 'hasData',
    set: function set(v) {
      this.__setBind("hasData", v);this.__data("hasData");
    },
    get: function get() {
      return this.__getBind("hasData");
    }
  }, {
    key: 'dataList',
    set: function set(v) {
      this.__setBind("dataList", v);this.__data("dataList");
    },
    get: function get() {
      if (this.__initBind("dataList")) this.__setBind("dataList", []);return this.__getBind("dataList");
    }
  }]);

  return HotCircle;
}(migi.Component);

migi.name(HotCircle, "HotCircle");exports.default = HotCircle;

/***/ }),
/* 58 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _util = __webpack_require__(6);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var HotWork = function (_migi$Component) {
  _inherits(HotWork, _migi$Component);

  function HotWork() {
    var _ref;

    _classCallCheck(this, HotWork);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = HotWork.__proto__ || Object.getPrototypeOf(HotWork)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(HotWork, [{
    key: "autoWidth",
    value: function autoWidth() {
      var $list = $(this.element).find('.list');
      var $c = $list.find('.c');
      $c.css('width', '9999rem');
      var $ul = $c.find('ul');
      $c.css('width', $ul.width() + 1);
    }
  }, {
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "cp-hotwork"]], [new migi.Obj("hasData", this, function () {
        return this.hasData ? migi.createVd("div", [["class", "list"]], [migi.createVd("div", [["class", "c"]], [this.dataList && this.dataList.length ? migi.createVd("ul", [], [this.dataList.map(function (item) {
          return migi.createVd("li", [], [migi.createVd("a", [["href", "/works/" + item.WorksID], ["class", "pic"]], [migi.createVd("img", [["src", _util2.default.autoSsl(_util2.default.img200_200_80(item.cover_Pic)) || '/src/common/blank.png']]), migi.createVd("span", [["class", "num"]], [item.Popular])]), migi.createVd("a", [["href", "/works/" + item.WorksID], ["class", "txt"]], [migi.createVd("span", [], [item.Title]), migi.createVd("span", [["class", "author"]], [(item.SingerName || []).join(' ')])])]);
        })]) : migi.createVd("div", [["class", "empty"]], ["暂无数据"])])]) : migi.createVd("div", [["class", "placeholder"]]);
      })]);
    }
  }, {
    key: "hasData",
    set: function set(v) {
      this.__setBind("hasData", v);this.__data("hasData");
    },
    get: function get() {
      return this.__getBind("hasData");
    }
  }, {
    key: "dataList",
    set: function set(v) {
      this.__setBind("dataList", v);this.__data("dataList");
    },
    get: function get() {
      if (this.__initBind("dataList")) this.__setBind("dataList", []);return this.__getBind("dataList");
    }
  }]);

  return HotWork;
}(migi.Component);

migi.name(HotWork, "HotWork");exports.default = HotWork;

/***/ }),
/* 59 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _util = __webpack_require__(6);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var HotMusicAlbum = function (_migi$Component) {
  _inherits(HotMusicAlbum, _migi$Component);

  function HotMusicAlbum() {
    var _ref;

    _classCallCheck(this, HotMusicAlbum);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = HotMusicAlbum.__proto__ || Object.getPrototypeOf(HotMusicAlbum)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(HotMusicAlbum, [{
    key: 'autoWidth',
    value: function autoWidth() {
      var $list = $(this.element).find('.list');
      var $c = $list.find('.c');
      $c.css('width', '9999rem');
      var $ul = $c.find('ul');
      $c.css('width', $ul.width() + 1);
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "cp-hotmusicalbum"]], [new migi.Obj("hasData", this, function () {
        return this.hasData ? migi.createVd("div", [["class", "list"]], [migi.createVd("div", [["class", "c"]], [this.dataList && this.dataList.length ? migi.createVd("ul", [], [this.dataList.map(function (item) {
          var url = '/works/' + item.WorksID;
          return migi.createVd("li", [], [migi.createVd("b", [["class", "bg"]]), migi.createVd("a", [["href", url], ["class", "pic"]], [migi.createVd("img", [["src", _util2.default.autoSsl(_util2.default.img200_200_80(item.cover_Pic)) || '/src/common/blank.png']]), migi.createVd("span", [["class", "num"]], [item.Popular || 0])]), migi.createVd("a", [["href", url], ["class", "txt"]], [migi.createVd("span", [], [item.Title]), migi.createVd("span", [["class", "author"]], [(item.SingerName || []).join(' ')])])]);
        })]) : migi.createVd("div", [["class", "empty"]], ["暂无数据"])])]) : migi.createVd("div", [["class", "placeholder"]]);
      })]);
    }
  }, {
    key: 'hasData',
    set: function set(v) {
      this.__setBind("hasData", v);this.__data("hasData");
    },
    get: function get() {
      return this.__getBind("hasData");
    }
  }, {
    key: 'dataList',
    set: function set(v) {
      this.__setBind("dataList", v);this.__data("dataList");
    },
    get: function get() {
      if (this.__initBind("dataList")) this.__setBind("dataList", []);return this.__getBind("dataList");
    }
  }]);

  return HotMusicAlbum;
}(migi.Component);

migi.name(HotMusicAlbum, "HotMusicAlbum");exports.default = HotMusicAlbum;

/***/ }),
/* 60 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _util = __webpack_require__(6);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var HotAuthor = function (_migi$Component) {
  _inherits(HotAuthor, _migi$Component);

  function HotAuthor() {
    var _ref;

    _classCallCheck(this, HotAuthor);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = HotAuthor.__proto__ || Object.getPrototypeOf(HotAuthor)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(HotAuthor, [{
    key: 'autoWidth',
    value: function autoWidth() {
      var $list = $(this.element).find('.list');
      var $c = $list.find('.c');
      $c.css('width', '9999rem');
      var $ul = $c.find('ul');
      $c.css('width', $ul.width() + 1);
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "cp-hotauthor"]], [new migi.Obj("hasData", this, function () {
        return this.hasData ? migi.createVd("div", [["class", "list"]], [migi.createVd("div", [["class", "c"]], [this.dataList && this.dataList.length ? migi.createVd("ul", [], [this.dataList.map(function (item) {
          return migi.createVd("li", [], [migi.createVd("a", [["href", '/author/' + item.AuthorID], ["class", "pic"]], [migi.createVd("img", [["src", _util2.default.autoSsl(_util2.default.img120_120_80(item.Head_url || '//zhuanquan.xin/img/head/8fd9055b7f033087e6337e37c8959d3e.png'))]])]), migi.createVd("a", [["href", '/author/' + item.AuthorID], ["class", "txt"]], [migi.createVd("span", [["class", "name"]], [item.AuthorName]), migi.createVd("span", [["class", "fans"]], [item.FansNumber || 0]), migi.createVd("span", [["class", "comment"]], [item.Popular || 0])]), migi.createVd("div", [["class", "info"]], ["合作", item.CooperationTimes, "次"])]);
        })]) : migi.createVd("div", [["class", "empty"]], ["暂无数据"])])]) : migi.createVd("div", [["class", "placeholder"]]);
      })]);
    }
  }, {
    key: 'hasData',
    set: function set(v) {
      this.__setBind("hasData", v);this.__data("hasData");
    },
    get: function get() {
      return this.__getBind("hasData");
    }
  }, {
    key: 'dataList',
    set: function set(v) {
      this.__setBind("dataList", v);this.__data("dataList");
    },
    get: function get() {
      return this.__getBind("dataList");
    }
  }]);

  return HotAuthor;
}(migi.Component);

migi.name(HotAuthor, "HotAuthor");exports.default = HotAuthor;

/***/ }),
/* 61 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _util = __webpack_require__(6);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var take = 30;
var skip = take;

var HotPost = function (_migi$Component) {
  _inherits(HotPost, _migi$Component);

  function HotPost() {
    var _ref;

    _classCallCheck(this, HotPost);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = HotPost.__proto__ || Object.getPrototypeOf(HotPost)).call.apply(_ref, [this].concat(data)));

    var self = _this;
    if (self.props.take) {
      take = self.props.take;
      if (self.props.skip) {
        skip = self.props.skip;
      } else {
        skip = take;
      }
    } else if (self.props.skip) {
      skip = self.props.skip;
    }
    self.on(migi.Event.DOM, function () {
      var $list = $(this.element).find('.list');
      $list.on('click', '.wrap .con .snap', function () {
        $(this).closest('li').addClass('expand');
      });
      $list.on('click', '.wrap .con .shrink', function () {
        var $li = $(this).closest('li');
        $li.removeClass('expand');
        $li[0].scrollIntoView(true);
      });
      $list.on('click', '.imgs', function () {
        $(this).closest('li').addClass('expand');
      });
      $list.on('click', '.imgs2 img', function () {
        var $this = $(this);
        var index = $this.attr('rel');
        var urls = [];
        $this.parent().find('img').each(function (i, img) {
          urls.push($(img).attr('src'));
        });
        migi.eventBus.emit('choosePic', urls, index);
      });
      $list.on('click', '.favor', function () {
        if (!$CONFIG.isLogin) {
          migi.eventBus.emit('NEED_LOGIN');
          return;
        }
        var $li = $(this);
        if ($li.hasClass('loading')) {
          return;
        }
        $li.addClass('loading');
        var postID = $li.attr('rel');
        var url = '/api/post/favor';
        if ($li.hasClass('has')) {
          url = '/api/post/unFavor';
        }
        _util2.default.postJSON(url, { postID: postID }, function (res) {
          if (res.success) {
            var _data = res.data;
            if (_data.State === 'favorWork') {
              $li.addClass('has');
            } else {
              $li.removeClass('has');
            }
            $li.find('span').text(_data.FavorCount || '分享');
          } else {
            alert(res.message || _util2.default.ERROR_MESSAGE);
          }
          $li.removeClass('loading');
        }, function (res) {
          alert(res.message || _util2.default.ERROR_MESSAGE);
          $li.removeClass('loading');
        });
      });
      $list.on('click', '.share', function () {
        var postID = $(this).attr('rel');
        migi.eventBus.emit('SHARE', location.origin + '/post/' + postID);
      });
      $list.on('click', '.like', function () {
        var $li = $(this);
        if ($li.hasClass('loading')) {
          return;
        }
        $li.addClass('loading');
        var postID = $li.attr('rel');
        _util2.default.postJSON('/api/post/like', { postID: postID }, function (res) {
          if (res.success) {
            var _data2 = res.data;
            if (_data2.ISLike) {
              $li.addClass('has');
            } else {
              $li.removeClass('has');
            }
            $li.find('span').text(_data2.LikeCount || '点赞');
          } else {
            alert(res.message || _util2.default.ERROR_MESSAGE);
          }
          $li.removeClass('loading');
        }, function (res) {
          alert(res.message || _util2.default.ERROR_MESSAGE);
          $li.removeClass('loading');
        });
      });
      $list.on('click', '.comment', function () {
        var id = $(this).attr('rel');
        location.href = '/post/' + id + '#name';
      });
      $list.on('click', '.del', function () {
        if (window.confirm('确认删除吗？')) {
          var postID = $(this).attr('rel');
          var $li = $(this).closest('.wrap').closest('li');
          _util2.default.postJSON('/api/post/del', { postID: postID }, function (res) {
            if (res.success) {
              $li.remove();
            } else {
              alert(res.message || _util2.default.ERROR_MESSAGE);
            }
          }, function (res) {
            alert(res.message || _util2.default.ERROR_MESSAGE);
          });
        }
      });
    });
    return _this;
  }

  _createClass(HotPost, [{
    key: 'encode',
    value: function encode(s) {
      return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/#(\S.*?)#/g, '<strong>#$1#</strong>').replace(/(http(?:s)?:\/\/[\w-]+\.[\w]+\S*)/gi, '<a href="$1" target="_blank">$1</a>');
    }
  }, {
    key: 'genItem',
    value: function genItem(item) {
      var len = item.Content.length;
      var id = item.ID;
      var maxLen = 144;
      var imgLen = item.Image_Post.length;
      var html = len > maxLen ? item.Content.slice(0, maxLen) + '...' : item.Content;
      html = this.encode(html);
      if (len > maxLen) {
        html += '<span class="placeholder"></span><span class="more">查看全文</span>';
        var full = this.encode(item.Content) + '<span class="placeholder"></span><span class="shrink">收起全文</span>';
        html = '<p class="snap">' + html + '</p><p class="full">' + full + '</p>';
      }
      if (item.IsAuthor) {
        return migi.createVd("li", [["class", "author"]], [migi.createVd("div", [["class", "profile fn-clear"]], [migi.createVd("a", [["class", "pic"], ["href", '/author/' + item.AuthorID]], [migi.createVd("img", [["src", _util2.default.autoSsl(_util2.default.img208_208_80(item.SendUserHead_Url || '//zhuanquan.xin/head/8fd9055b7f033087e6337e37c8959d3e.png'))]])]), migi.createVd("div", [["class", "txt"]], [migi.createVd("a", [["href", '/author/' + item.AuthorID], ["class", "name"]], [item.SendUserNickName]), migi.createVd("a", [["class", "time"], ["href", '/post/' + id]], [_util2.default.formatDate(item.Createtime)])]), migi.createVd("div", [["class", "circle"]], [migi.createVd("ul", [], [(item.Taglist || []).map(function (item) {
          return migi.createVd("li", [], [migi.createVd("a", [["href", '/circle/' + item.TagID]], [item.TagName, "圈"])]);
        })])])]), migi.createVd("div", [["class", "wrap"]], [item.Title ? migi.createVd("a", [["href", '/post/' + id], ["class", "t"]], [item.Title]) : '', migi.createVd("div", [["class", "con"], ["dangerouslySetInnerHTML", html]]), item.Image_Post && imgLen ? migi.createVd("ul", [["class", 'imgs fn-clear' + (item.Image_Post.length > 4 ? '' : ' n' + item.Image_Post.length)]], [item.Image_Post.length > 9 ? item.Image_Post.slice(0, 9).map(function (item, i) {
          var cn = '';
          if (item.Width !== 0 && item.Height !== 0 && item.Width < 86 && item.Height < 86) {
            cn = 'no-scale';
          }
          if (i === 8) {
            return migi.createVd("li", [["class", 'all ' + cn], ["style", 'background-image:url(' + _util2.default.autoSsl(_util2.default.img172_172_80(item.FileUrl)) + ')']], [migi.createVd("img", [["src", _util2.default.autoSsl(_util2.default.img172_172_80(item.FileUrl))]]), migi.createVd("a", [["href", '/post/' + id]], ["查看全部"])]);
          }
          return migi.createVd("li", [["class", cn], ["style", 'background-image:url(' + _util2.default.autoSsl(_util2.default.img172_172_80(item.FileUrl)) + ')']], [migi.createVd("img", [["src", _util2.default.autoSsl(_util2.default.img172_172_80(item.FileUrl))]])]);
        }) : item.Image_Post.map(function (item) {
          var cn = '';
          if (item.Width !== 0 && item.Height !== 0 && item.Width < 86 && item.Height < 86) {
            cn = 'no-scale';
          }
          return migi.createVd("li", [["class", cn], ["style", 'background-image:url(' + _util2.default.autoSsl(_util2.default.img172_172_80(item.FileUrl)) + ')']], [migi.createVd("img", [["src", _util2.default.autoSsl(_util2.default.img172_172_80(item.FileUrl))]])]);
        })]) : '', item.Image_Post && imgLen ? migi.createVd("div", [["class", "imgs2"]], [item.Image_Post.map(function (item, i) {
          return migi.createVd("img", [["src", _util2.default.autoSsl(_util2.default.img1200__80(item.FileUrl))], ["rel", i]]);
        })]) : '', migi.createVd("b", [["class", "arrow"]]), migi.createVd("ul", [["class", "btn"]], [migi.createVd("li", [["class", "share"], ["rel", id]], [migi.createVd("b", []), migi.createVd("span", [], ["分享"])]), migi.createVd("li", [["class", 'favor' + (item.ISFavor ? ' has' : '')], ["rel", id]], [migi.createVd("b", []), migi.createVd("span", [], [item.FavorCount || '收藏'])]), migi.createVd("li", [["class", 'like' + (item.ISLike ? ' has' : '')], ["rel", id]], [migi.createVd("b", []), migi.createVd("span", [], [item.LikeCount || '点赞'])]), migi.createVd("li", [["class", "comment"], ["rel", id]], [migi.createVd("b", []), migi.createVd("span", [], [item.CommentCount || '评论'])]), item.IsOwn ? migi.createVd("li", [["class", "del"], ["rel", id]], [migi.createVd("b", [])]) : ''])])]);
      }
      return migi.createVd("li", [], [migi.createVd("div", [["class", "profile fn-clear"]], [migi.createVd("a", [["class", "pic"], ["href", '/user/' + item.SendUserID]], [migi.createVd("img", [["src", _util2.default.autoSsl(_util2.default.img208_208_80(item.SendUserHead_Url || '//zhuanquan.xin/head/8fd9055b7f033087e6337e37c8959d3e.png'))]])]), migi.createVd("div", [["class", "txt"]], [migi.createVd("a", [["class", "name"], ["href", '/user/' + item.SendUserID]], [item.SendUserNickName]), migi.createVd("a", [["class", "time"], ["href", '/post/' + id]], [_util2.default.formatDate(item.Createtime)])]), migi.createVd("div", [["class", "circle"]], [migi.createVd("ul", [], [(item.Taglist || []).map(function (item) {
        return migi.createVd("li", [], [migi.createVd("a", [["href", '/circle/' + item.TagID]], [item.TagName, "圈"])]);
      })])])]), migi.createVd("div", [["class", "wrap"]], [item.Title ? migi.createVd("a", [["href", '/post/' + id], ["class", "t"]], [item.Title]) : '', migi.createVd("div", [["class", "con"], ["dangerouslySetInnerHTML", html]]), item.Image_Post && imgLen ? migi.createVd("ul", [["class", 'imgs fn-clear' + (item.Image_Post.length > 4 ? '' : ' n' + item.Image_Post.length)]], [item.Image_Post.length > 9 ? item.Image_Post.slice(0, 9).map(function (item, i) {
        var cn = '';
        if (item.Width !== 0 && item.Height !== 0 && item.Width < 86 && item.Height < 86) {
          cn = 'no-scale';
        }
        if (i === 8) {
          return migi.createVd("li", [["class", 'all ' + cn], ["style", 'background-image:url(' + _util2.default.autoSsl(_util2.default.img172_172_80(item.FileUrl)) + ')']], [migi.createVd("img", [["src", _util2.default.autoSsl(_util2.default.img172_172_80(item.FileUrl))]]), migi.createVd("a", [["href", '/post/' + id]], ["查看全部"])]);
        }
        return migi.createVd("li", [["class", cn], ["style", 'background-image:url(' + _util2.default.autoSsl(_util2.default.img172_172_80(item.FileUrl)) + ')']], [migi.createVd("img", [["src", _util2.default.autoSsl(_util2.default.img172_172_80(item.FileUrl))]])]);
      }) : item.Image_Post.map(function (item) {
        var cn = '';
        if (item.Width !== 0 && item.Height !== 0 && item.Width < 86 && item.Height < 86) {
          cn = 'no-scale';
        }
        return migi.createVd("li", [["class", cn], ["style", 'background-image:url(' + _util2.default.autoSsl(_util2.default.img172_172_80(item.FileUrl)) + ')']], [migi.createVd("img", [["src", _util2.default.autoSsl(_util2.default.img172_172_80(item.FileUrl))]])]);
      })]) : '', item.Image_Post && imgLen ? migi.createVd("div", [["class", "imgs2"]], [item.Image_Post.map(function (item, i) {
        return migi.createVd("img", [["src", _util2.default.autoSsl(_util2.default.img1200__80(item.FileUrl))], ["rel", i]]);
      })]) : '', migi.createVd("b", [["class", "arrow"]]), migi.createVd("ul", [["class", "btn"]], [migi.createVd("li", [["class", "share"], ["rel", id]], [migi.createVd("b", []), migi.createVd("span", [], ["分享"])]), migi.createVd("li", [["class", 'favor' + (item.ISFavor ? ' has' : '')], ["rel", id]], [migi.createVd("b", []), migi.createVd("span", [], [item.FavorCount || '收藏'])]), migi.createVd("li", [["class", 'like' + (item.ISLike ? ' has' : '')], ["rel", id]], [migi.createVd("b", []), migi.createVd("span", [], [item.LikeCount || '点赞'])]), migi.createVd("li", [["class", "comment"], ["rel", id]], [migi.createVd("b", []), migi.createVd("span", [], [item.CommentCount || '评论'])]), item.IsOwn ? migi.createVd("li", [["class", "del"], ["rel", id]], [migi.createVd("b", [])]) : ''])])]);
    }
  }, {
    key: 'setData',
    value: function setData(data) {
      var self = this;
      var html = '';
      data.forEach(function (item) {
        html += self.genItem(item);
      });
      $(self.element).find('.list').append(html);
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "cp-hotpost"]], [new migi.Obj(["hasData", "data"], this, function () {
        return this.hasData ? this.data ? migi.createVd("ol", [["class", "list"]]) : migi.createVd("div", [["class", "empty"]], ["暂无内容"]) : migi.createVd("div", [["class", "placeholder"]]);
      }), migi.createVd("div", [["class", "message"]], [new migi.Obj("message", this, function () {
        return this.message;
      })])]);
    }
  }, {
    key: 'data',
    set: function set(v) {
      this.__setBind("data", v);this.__data("data");
    },
    get: function get() {
      return this.__getBind("data");
    }
  }, {
    key: 'hasData',
    set: function set(v) {
      this.__setBind("hasData", v);this.__data("hasData");
    },
    get: function get() {
      return this.__getBind("hasData");
    }
  }, {
    key: 'loading',
    set: function set(v) {
      this.__setBind("loading", v);this.__data("loading");
    },
    get: function get() {
      return this.__getBind("loading");
    }
  }, {
    key: 'loadEnd',
    set: function set(v) {
      this.__setBind("loadEnd", v);this.__data("loadEnd");
    },
    get: function get() {
      return this.__getBind("loadEnd");
    }
  }, {
    key: 'message',
    set: function set(v) {
      this.__setBind("message", v);this.__data("message");
    },
    get: function get() {
      return this.__getBind("message");
    }
  }]);

  return HotPost;
}(migi.Component);

migi.name(HotPost, "HotPost");exports.default = HotPost;

/***/ })
/******/ ]);