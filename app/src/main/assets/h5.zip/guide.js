/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 60);
/******/ })
/************************************************************************/
/******/ ({

/***/ 28:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Step0 = function (_migi$Component) {
  _inherits(Step0, _migi$Component);

  function Step0() {
    var _ref;

    _classCallCheck(this, Step0);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Step0.__proto__ || Object.getPrototypeOf(Step0)).call.apply(_ref, [this].concat(data)));

    _this.isShow = _this.props.isShow;
    return _this;
  }

  _createClass(Step0, [{
    key: "click",
    value: function click(e, vd, tvd) {
      var $o = $(tvd.element);
      if (!$o.hasClass('cur')) {
        this.isMale = !this.isMale;
      }
    }
  }, {
    key: "next",
    value: function next(e, vd) {
      var $vd = $(vd.element);
      if (!$vd.hasClass('dis')) {
        this.setDis = true;
        this.emit('next');
      }
    }
  }, {
    key: "enable",
    value: function enable() {
      this.setDis = false;
    }
  }, {
    key: "show",
    value: function show() {
      this.isShow = true;
    }
  }, {
    key: "hide",
    value: function hide() {
      this.isShow = false;
    }
  }, {
    key: "onc",
    value: function onc(e) {
      e.preventDefault();
    }
  }, {
    key: "offc",
    value: function offc(e) {
      e.preventDefault();
    }
  }, {
    key: "protocol",
    value: function protocol(e) {
      e.preventDefault();
    }
  }, {
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", new migi.Obj("isShow", this, function () {
        return 'step0' + (this.isShow ? '' : ' fn-hide');
      })]], [migi.createVd("div", [["class", "con"]], [migi.createVd("img", [["class", "logo"], ["src", "src/guide/step2.jpg"]]), migi.createVd("h2", [], ["原来是传说中的"]), migi.createVd("h4", [], ["揩油哥！"]), migi.createVd("p", [], ["欢迎来到“转圈”，热心粉丝们已经为您建立了详尽的个人主页，正恭候您的大驾！"]), migi.createVd("p", [], ["在这里，除了转圈的基本功能外（如社交、收藏作品等），您还拥有了创作者专属功能（如管理、上传您的作品、发起粉丝活动等）！"]), migi.createVd("a", [["href", "#"], ["class", "on"], ["onClick", new migi.Cb(this, this.onc)]], []), migi.createVd("a", [["href", "#"], ["class", "off"], ["onClick", new migi.Cb(this, this.offc)]], []), migi.createVd("div", [["class", "protocol"]], ["我已阅读并同意转圈的", migi.createVd("a", [["href", "#"], ["onClick", new migi.Cb(this, this.protocol)]], ["《作者协议》"])])])]);
    }
  }, {
    key: "isShow",
    set: function set(v) {
      this.__setBind("isShow", v);this.__data("isShow");
    },
    get: function get() {
      return this.__getBind("isShow");
    }
  }, {
    key: "isDis",
    set: function set(v) {
      this.__setBind("isDis", v);this.__data("isDis");
    },
    get: function get() {
      if (this.__initBind("isDis")) this.__setBind("isDis", true);return this.__getBind("isDis");
    }
  }, {
    key: "setDis",
    set: function set(v) {
      this.__setBind("setDis", v);this.__data("setDis");
    },
    get: function get() {
      if (this.__initBind("setDis")) this.__setBind("setDis", false);return this.__getBind("setDis");
    }
  }]);

  return Step0;
}(migi.Component);

migi.name(Step0, "Step0");exports.default = Step0;

/***/ }),

/***/ 29:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Step1 = function (_migi$Component) {
  _inherits(Step1, _migi$Component);

  function Step1() {
    var _ref;

    _classCallCheck(this, Step1);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Step1.__proto__ || Object.getPrototypeOf(Step1)).call.apply(_ref, [this].concat(data)));

    _this.isShow = _this.props.isShow;
    return _this;
  }

  _createClass(Step1, [{
    key: "click",
    value: function click(e, vd, tvd) {
      var $o = $(tvd.element);
      if (!$o.hasClass('cur')) {
        this.isMale = !this.isMale;
      }
    }
  }, {
    key: "input",
    value: function input(e, vd) {
      this.isDis = $(vd.element).val().length < 4;
    }
  }, {
    key: "next",
    value: function next(e, vd) {
      var $vd = $(vd.element);
      var self = this;
      if (!$vd.hasClass('dis')) {
        self.setDis = true;
        util.getJSON('register/setNickNameAndGenderOnRegister.json', {
          uid: 1000,
          nickName: 'sdf',
          gender: 1
        }, function (res) {
          if (res.success) {
            self.emit('next');
          } else {
            self.setDis = false;
            jsBridge.toast(res.message || 123);
          }
        });
      }
    }
  }, {
    key: "enable",
    value: function enable() {
      this.setDis = false;
    }
  }, {
    key: "show",
    value: function show() {
      this.isShow = true;
    }
  }, {
    key: "hide",
    value: function hide() {
      this.isShow = false;
    }
  }, {
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", new migi.Obj("isShow", this, function () {
        return 'step1' + (this.isShow ? '' : ' fn-hide');
      })]], [migi.createVd("div", [["class", "con"]], [migi.createVd("img", [["class", "logo"], ["src", "src/guide/step1.jpg"]]), migi.createVd("h2", [], ["欢迎来到转圈"]), migi.createVd("h4", [], ["我是圈娘，请问该怎么称呼你呢？"]), migi.createVd("input", [["type", "text"], ["class", "iname"], ["placeholder", "字数请超过4个"], ["maxLength", "16"], ["onInput", new migi.Cb(this, this.input)], ["value", new migi.Obj("v", this, function () {
        return this.v;
      })]]), migi.createVd("p", [["class", "error"]], []), migi.createVd("p", [["class", "qsex"]], ["请问是汉子还是妹子呢？"]), migi.createVd("ul", [["class", "sex"], ["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.click)]]]], [migi.createVd("li", [["class", new migi.Obj("isMale", this, function () {
        return 'male' + (this.isMale ? ' cur' : '');
      })]], [migi.createVd("span", [], ["汉子"])]), migi.createVd("li", [["class", new migi.Obj("isMale", this, function () {
        return 'female' + (this.isMale ? '' : ' cur');
      })]], [migi.createVd("span", [], ["妹子"])])])]), migi.createVd("button", [["ref", "next"], ["class", new migi.Obj(["isDis", "setDis"], this, function () {
        return 'sub' + (this.isDis || this.setDis ? ' dis' : '');
      })], ["onClick", new migi.Cb(this, this.next)]], ["就叫这个！"])]);
    }
  }, {
    key: "isShow",
    set: function set(v) {
      this.__setBind("isShow", v);this.__data("isShow");
    },
    get: function get() {
      return this.__getBind("isShow");
    }
  }, {
    key: "isMale",
    set: function set(v) {
      this.__setBind("isMale", v);this.__data("isMale");
    },
    get: function get() {
      if (this.__initBind("isMale")) this.__setBind("isMale", true);return this.__getBind("isMale");
    }
  }, {
    key: "isDis",
    set: function set(v) {
      this.__setBind("isDis", v);this.__data("isDis");
    },
    get: function get() {
      if (this.__initBind("isDis")) this.__setBind("isDis", true);return this.__getBind("isDis");
    }
  }, {
    key: "setDis",
    set: function set(v) {
      this.__setBind("setDis", v);this.__data("setDis");
    },
    get: function get() {
      if (this.__initBind("setDis")) this.__setBind("setDis", false);return this.__getBind("setDis");
    }
  }, {
    key: "v",
    set: function set(v) {
      this.__setBind("v", v);this.__data("v");
    },
    get: function get() {
      if (this.__initBind("v")) this.__setBind("v", '');return this.__getBind("v");
    }
  }]);

  return Step1;
}(migi.Component);

migi.name(Step1, "Step1");exports.default = Step1;

/***/ }),

/***/ 30:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Step2 = function (_migi$Component) {
  _inherits(Step2, _migi$Component);

  function Step2() {
    var _ref;

    _classCallCheck(this, Step2);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Step2.__proto__ || Object.getPrototypeOf(Step2)).call.apply(_ref, [this].concat(data)));

    _this.isShow = _this.props.isShow;
    _this.list = [];
    for (var i = 0; i < 30; i++) {
      _this.list.push(1);
    }
    _this.on(migi.Event.DOM, function () {
      util.getJSON('tag/getSuggestTags.json', {
        uid: 1000,
        pageNum: 1
      }, function (res) {
        console.log(res);
      });
    });
    return _this;
  }

  _createClass(Step2, [{
    key: "click",
    value: function click(e, vd, tvd) {
      var $li = $(tvd.element);
      $li.toggleClass('sel');
    }
  }, {
    key: "next",
    value: function next(e, vd) {
      var $vd = $(vd.element);
      if (!$vd.hasClass('dis')) {
        this.setDis = true;
        this.emit('next');
      }
    }
  }, {
    key: "enable",
    value: function enable() {
      this.setDis = false;
    }
  }, {
    key: "show",
    value: function show() {
      this.isShow = true;
    }
  }, {
    key: "hide",
    value: function hide() {
      this.isShow = false;
    }
  }, {
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", new migi.Obj("isShow", this, function () {
        return 'step2' + (this.isShow ? '' : ' fn-hide');
      })]], [migi.createVd("div", [["class", "con"]], [migi.createVd("img", [["class", "logo"], ["src", "src/guide/step2.jpg"]]), migi.createVd("h2", [], ["请选择你感兴趣的圈子"]), migi.createVd("h4", [], ["以便我们呈现更适合你的内容"]), migi.createVd("div", [["class", "list"]], [migi.createVd("ul", [["class", "fn-clear"], ["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.click)]]]], [new migi.Obj("list", this, function () {
        return this.list.map(function (item) {
          return migi.createVd("li", [], ["古风"]);
        }.bind(this));
      })])])]), migi.createVd("button", [["ref", "next"], ["class", new migi.Obj("setDis", this, function () {
        return 'sub' + (this.setDis ? ' dis' : '');
      })], ["onClick", new migi.Cb(this, this.next)]], ["我选好啦！"])]);
    }
  }, {
    key: "isShow",
    set: function set(v) {
      this.__setBind("isShow", v);this.__data("isShow");
    },
    get: function get() {
      return this.__getBind("isShow");
    }
  }, {
    key: "setDis",
    set: function set(v) {
      this.__setBind("setDis", v);this.__data("setDis");
    },
    get: function get() {
      if (this.__initBind("setDis")) this.__setBind("setDis", false);return this.__getBind("setDis");
    }
  }, {
    key: "list",
    get: function get() {
      return this._list || [];
    },
    set: function set(v) {
      this._list = v;
      ;this.__array("list", v);this.__data("list");
    }
  }]);

  return Step2;
}(migi.Component);

migi.name(Step2, "Step2");exports.default = Step2;

/***/ }),

/***/ 31:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Step3 = function (_migi$Component) {
  _inherits(Step3, _migi$Component);

  function Step3() {
    var _ref;

    _classCallCheck(this, Step3);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    var _this = _possibleConstructorReturn(this, (_ref = Step3.__proto__ || Object.getPrototypeOf(Step3)).call.apply(_ref, [this].concat(data)));

    _this.isShow = _this.props.isShow;
    return _this;
  }

  _createClass(Step3, [{
    key: "show",
    value: function show() {
      this.isShow = true;
    }
  }, {
    key: "hide",
    value: function hide() {
      this.isShow = false;
    }
  }, {
    key: "click",
    value: function click(e, vd, tvd) {
      var $li = $(tvd.element);
      $li.toggleClass('sel');
    }
  }, {
    key: "click2",
    value: function click2(e, vd, tvd) {
      var $li = $(tvd.element);
      if ($li.hasClass('remove')) {
        //
      } else if ($li.hasClass('sel')) {
        $li.addClass('remove');
        setTimeout(function () {
          $li.remove();
        }, 1000);
      } else {
        $li.addClass('sel');
      }
    }
  }, {
    key: "next",
    value: function next(e, vd) {
      var $vd = $(vd.element);
      if (!$vd.hasClass('dis')) {
        this.setDis = true;
        this.emit('next');
      }
    }
  }, {
    key: "enable",
    value: function enable() {
      this.setDis = false;
    }
  }, {
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", new migi.Obj("isShow", this, function () {
        return 'step3' + (this.isShow ? '' : ' fn-hide');
      })]], [migi.createVd("img", [["class", "logo"], ["src", "src/guide/step2.jpg"]]), migi.createVd("h2", [], ["这里有你喜欢的作者吗？"]), migi.createVd("h4", [], ["没有也没关系，之后随时可以添加"]), migi.createVd("ul", [["class", "list fn-clear"], ["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.click)]]]], [migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]]), migi.createVd("span", [], ["河图"])]), migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]]), migi.createVd("span", [], ["河图"])]), migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]]), migi.createVd("span", [], ["河图"])]), migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]]), migi.createVd("span", [], ["河图"])]), migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]]), migi.createVd("span", [], ["河图"])]), migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]]), migi.createVd("span", [], ["河图"])]), migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]]), migi.createVd("span", [], ["河图"])]), migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]]), migi.createVd("span", [], ["河图"])])]), migi.createVd("a", [["href", "#"], ["class", "change"]], [migi.createVd("span", [], ["换一换"])]), migi.createVd("div", [["class", "choose"]], [migi.createVd("div", [["class", "lists"]], [migi.createVd("ul", [["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.click2)]]]], [migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]])]), migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]])]), migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]])]), migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]])]), migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]])]), migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]])]), migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]])]), migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]])]), migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]])]), migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]])]), migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]])]), migi.createVd("li", [], [migi.createVd("img", [["src", "src/guide/step1.jpg"]])])])]), migi.createVd("button", [["ref", "next"], ["class", new migi.Obj("setDis", this, function () {
        return 'sub' + (this.setDis ? ' dis' : '');
      })], ["onClick", new migi.Cb(this, this.next)]], ["我选好啦!"])])]);
    }
  }, {
    key: "isShow",
    set: function set(v) {
      this.__setBind("isShow", v);this.__data("isShow");
    },
    get: function get() {
      return this.__getBind("isShow");
    }
  }, {
    key: "setDis",
    set: function set(v) {
      this.__setBind("setDis", v);this.__data("setDis");
    },
    get: function get() {
      if (this.__initBind("setDis")) this.__setBind("setDis", false);return this.__getBind("setDis");
    }
  }]);

  return Step3;
}(migi.Component);

migi.name(Step3, "Step3");exports.default = Step3;

/***/ }),

/***/ 36:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = __webpack_require__(50);

/***/ }),

/***/ 41:
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ 43:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "src/guide/guide.html";

/***/ }),

/***/ 50:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// QueryString
// ---------------
// This module provides utilities for dealing with query strings.
//
// Thanks to:
//  - http://nodejs.org/docs/v0.4.7/api/querystring.html
//  - http://developer.yahoo.com/yui/3/api/QueryString.html
//  - https://github.com/lifesinger/dew/tree/master/lib/querystring


// var QueryString = exports;

var QueryString = {};

// The escape/unescape function used by stringify/parse, provided so that it
// could be overridden if necessary. This is important in cases where
// non-standard delimiters are used, if the delimiters would not normally be
// handled properly by the built-in (en|de)codeURIComponent functions.
QueryString.escape = encodeURIComponent;

QueryString.unescape = function (s) {
    // The + character is interpreted as a space on the server side as well as
    // generated by forms with spaces in their fields.
    return decodeURIComponent(s.replace(/\+/g, ' '));
};

/**
 * Serialize an object to a query string. Optionally override the default
 * separator and assignment characters.
 *
 * stringify({foo: 'bar'})
 *   // returns 'foo=bar'
 *
 * stringify({foo: 'bar', baz: 'bob'}, ';', ':')
 *   // returns 'foo:bar;baz:bob'
 */
QueryString.stringify = function (obj, sep, eq, arrayKey) {
    if (!isPlainObject(obj)) return '';

    sep = sep || '&';
    eq = eq || '=';
    arrayKey = arrayKey || false;

    var buf = [],
        key,
        val;
    var escape = QueryString.escape;

    for (key in obj) {
        if (!hasOwnProperty.call(obj, key)) continue;

        val = obj[key];
        key = QueryString.escape(key);

        // val is primitive value
        if (isPrimitive(val)) {
            buf.push(key, eq, escape(val + ''), sep);
        }
        // val is not empty array
        else if (isArray(val) && val.length) {
                for (var i = 0; i < val.length; i++) {
                    if (isPrimitive(val[i])) {
                        buf.push(key, (arrayKey ? escape('[]') : '') + eq, escape(val[i] + ''), sep);
                    }
                }
            }
            // ignore other cases, including empty array, Function, RegExp, Date etc.
            else {
                    buf.push(key, eq, sep);
                }
    }

    buf.pop();
    return buf.join('');
};

/**
 * Deserialize a query string to an object. Optionally override the default
 * separator and assignment characters.
 *
 * parse('a=b&c=d')
 *   // returns {a: 'b', c: 'c'}
 */
QueryString.parse = function (str, sep, eq) {
    var ret = {};

    if (typeof str !== 'string' || trim(str).length === 0) {
        return ret;
    }

    var pairs = str.split(sep || '&');
    eq = eq || '=';
    var unescape = QueryString.unescape;

    for (var i = 0; i < pairs.length; i++) {

        var pair = pairs[i].split(eq);
        var key = unescape(trim(pair[0]));
        var val = unescape(trim(pair.slice(1).join(eq)));

        var m = key.match(/^(\w+)\[\]$/);
        if (m && m[1]) {
            key = m[1];
        }

        if (hasOwnProperty.call(ret, key)) {
            if (!isArray(ret[key])) {
                ret[key] = [ret[key]];
            }
            ret[key].push(val);
        } else {
            ret[key] = m ? [val] : val;
        }
    }

    return ret;
};

// Helpers

var toString = Object.prototype.toString;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var isArray = Array.isArray || function (val) {
    return toString.call(val) === '[object Array]';
};
var trim = String.prototype.trim ? function (str) {
    return str == null ? '' : String.prototype.trim.call(str);
} : function (str) {
    return str == null ? '' : str.toString().replace(/^\s+/, '').replace(/\s+$/, '');
};

/**
 * Checks to see if an object is a plain object (created using "{}" or
 * "new Object()" or "new FunctionClass()").
 */
function isPlainObject(o) {
    /**
     * NOTES:
     * isPlainObject(node = document.getElementById("xx")) -> false
     * toString.call(node):
     *   ie678 === '[object Object]', other === '[object HTMLElement]'
     * 'isPrototypeOf' in node:
     *   ie678 === false, other === true
     */
    return o && toString.call(o) === '[object Object]' && 'isPrototypeOf' in o;
}

/**
 * If the type of o is null, undefined, number, string, boolean,
 * return true.
 */
function isPrimitive(o) {
    return o !== Object(o);
}

module.exports = QueryString;

/***/ }),

/***/ 60:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _animaQuerystring = __webpack_require__(36);

var _animaQuerystring2 = _interopRequireDefault(_animaQuerystring);

__webpack_require__(43);

__webpack_require__(41);

var _Step = __webpack_require__(28);

var _Step2 = _interopRequireDefault(_Step);

var _Step3 = __webpack_require__(29);

var _Step4 = _interopRequireDefault(_Step3);

var _Step5 = __webpack_require__(30);

var _Step6 = _interopRequireDefault(_Step5);

var _Step7 = __webpack_require__(31);

var _Step8 = _interopRequireDefault(_Step7);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var search = _animaQuerystring2.default.parse(location.search.replace(/^\?/, ''));
var step = parseInt(search.step);
if (step === undefined || isNaN(step)) {
  step = 1;
}
var firstStep = step;

var step0 = migi.render(migi.createCp(_Step2.default, [["isShow", step == 0]]), document.body);
var step1 = migi.render(migi.createCp(_Step4.default, [["isShow", step == 1]]), document.body);
var step2 = migi.render(migi.createCp(_Step6.default, [["isShow", step == 2]]), document.body);
var step3 = migi.render(migi.createCp(_Step8.default, [["isShow", step == 3]]), document.body);

step1.on('next', function () {
  step1.hide();
  step2.show();
  step++;
  step1.enable();
});
step2.on('next', function () {
  step2.hide();
  step3.show();
  step++;
  step2.enable();
});
step3.on('next', function () {
  location.href = 'index.html';
});

switch (step) {
  case 3:
    step3.show();
    break;
  case 2:
    step2.show();
    break;
  case 0:
    break;
  default:
    step1.show();
    break;
}

jsBridge.ready(function () {
  // jsBridge.on('back', function(e) {
  //   if(step) {
  //     if(step > firstStep && step > 1) {
  //       e.preventDefault();
  //       switch (step) {
  //         case 3:
  //           step3.hide();
  //           step2.show();
  //           step--;
  //           break;
  //         case 2:
  //           step2.hide();
  //           step1.show();
  //           step--;
  //           break;
  //         case 1:
  //           s
  //           break;
  //       }
  //     }
  //   }
  // });
});

/***/ })

/******/ });