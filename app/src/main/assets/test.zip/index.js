/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 46);
/******/ })
/************************************************************************/
/******/ ({

/***/ 23:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var BottomNav = function (_migi$Component) {
  _inherits(BottomNav, _migi$Component);

  function BottomNav() {
    var _ref;

    _classCallCheck(this, BottomNav);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = BottomNav.__proto__ || Object.getPrototypeOf(BottomNav)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(BottomNav, [{
    key: 'click',
    value: function click(e, vd, tvd) {
      var $elem = $(tvd.element);
      if ($elem.hasClass('cur')) {
        return;
      }
      var rel = tvd.props.rel;
      $(this.element).find('.cur').removeClass('cur');
      $elem.addClass('cur');
      this.emit('change', rel);
    }
  }, {
    key: 'render',
    value: function render() {
      return migi.createVd("div", [["class", "bottom_nav"], ["onClick", [[{ "li": { "_v": true } }, new migi.Cb(this, this.click)]]]], [migi.createVd("ul", [], [migi.createVd("li", [["class", "follow cur"], ["rel", "0"]], [migi.createVd("b", [], []), migi.createVd("span", [], ["关注"])]), migi.createVd("li", [["class", "zhuanquan"], ["rel", "1"]], [migi.createVd("b", [], []), migi.createVd("span", [], ["转圈"])]), migi.createVd("li", [["class", "find"], ["rel", "2"]], [migi.createVd("b", [], []), migi.createVd("span", [], ["发现"])]), migi.createVd("li", [["class", "my"], ["rel", "3"]], [migi.createVd("b", [], []), migi.createVd("span", [], ["我的"])])])]);
    }
  }]);

  return BottomNav;
}(migi.Component);

migi.name(BottomNav, "BottomNav");exports.default = BottomNav;

/***/ }),

/***/ 24:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Carousel = function (_migi$Component) {
  _inherits(Carousel, _migi$Component);

  function Carousel() {
    var _ref;

    _classCallCheck(this, Carousel);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Carousel.__proto__ || Object.getPrototypeOf(Carousel)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Carousel, [{
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "carousel"]], [migi.createVd("img", [["src", "https://modao.cc/uploads2/images/804/8040490/raw_1489133599.jpeg"]])]);
    }
  }]);

  return Carousel;
}(migi.Component);

migi.name(Carousel, "Carousel");exports.default = Carousel;

/***/ }),

/***/ 25:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Follow = function (_migi$Component) {
  _inherits(Follow, _migi$Component);

  function Follow() {
    var _ref;

    _classCallCheck(this, Follow);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = Follow.__proto__ || Object.getPrototypeOf(Follow)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(Follow, [{
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "follows"]], [migi.createVd("h3", [], ["特别关注"]), migi.createVd("a", [["href", "#"], ["class", "more"]], ["关注列表"]), migi.createVd("ul", [["class", "list"]], [migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], [migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.133.113.754.754.50/684ff39bgw1f6wlmiignrj20rt0rtta8.jpg"]]), migi.createVd("span", [], ["名字"])])]), migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], [migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.133.113.754.754.50/684ff39bgw1f6wlmiignrj20rt0rtta8.jpg"]]), migi.createVd("span", [], ["名字"])])]), migi.createVd("li", [], [migi.createVd("a", [["href", "#"]], [migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.133.113.754.754.50/684ff39bgw1f6wlmiignrj20rt0rtta8.jpg"]]), migi.createVd("span", [], ["名字"])])])])]);
    }
  }]);

  return Follow;
}(migi.Component);

migi.name(Follow, "Follow");exports.default = Follow;

/***/ }),

/***/ 26:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var News = function (_migi$Component) {
  _inherits(News, _migi$Component);

  function News() {
    var _ref;

    _classCallCheck(this, News);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = News.__proto__ || Object.getPrototypeOf(News)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(News, [{
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "news_list"]], [migi.createVd("ul", [["class", "list"]], [migi.createVd("li", [], [migi.createVd("div", [["class", "t"]], [migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.133.113.754.754.50/684ff39bgw1f6wlmiignrj20rt0rtta8.jpg"]]), migi.createVd("strong", [], ["河图"]), migi.createVd("small", [], ["2017.03.16 10:00"])]), migi.createVd("div", [["class", "c"]], [migi.createVd("p", [], ["如果你无法简洁地表达你的想法，那只说明你还不够了解它。"])])]), migi.createVd("li", [], [migi.createVd("div", [["class", "t"]], [migi.createVd("img", [["src", "http://tva3.sinaimg.cn/crop.133.113.754.754.50/684ff39bgw1f6wlmiignrj20rt0rtta8.jpg"]]), migi.createVd("strong", [], ["河图"]), migi.createVd("small", [], ["2017.03.16 10:00"])]), migi.createVd("div", [["class", "c"]], [migi.createVd("p", [], ["如果你无法简洁地表达你的想法，那只说明你还不够了解它。"])])])])]);
    }
  }]);

  return News;
}(migi.Component);

migi.name(News, "News");exports.default = News;

/***/ }),

/***/ 27:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var SearchNav = function (_migi$Component) {
  _inherits(SearchNav, _migi$Component);

  function SearchNav() {
    var _ref;

    _classCallCheck(this, SearchNav);

    for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
      data[_key] = arguments[_key];
    }

    return _possibleConstructorReturn(this, (_ref = SearchNav.__proto__ || Object.getPrototypeOf(SearchNav)).call.apply(_ref, [this].concat(data)));
  }

  _createClass(SearchNav, [{
    key: "render",
    value: function render() {
      return migi.createVd("div", [["class", "search_nav"]], [migi.createVd("form", [], [migi.createVd("b", [], []), migi.createVd("input", [["type", "text"], ["placeholder", "搜索"]]), migi.createVd("button", [], [])])]);
    }
  }]);

  return SearchNav;
}(migi.Component);

migi.name(SearchNav, "SearchNav");exports.default = SearchNav;

/***/ }),

/***/ 32:
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ 33:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "index.html";

/***/ }),

/***/ 46:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(33);

__webpack_require__(32);

var _SearchNav = __webpack_require__(27);

var _SearchNav2 = _interopRequireDefault(_SearchNav);

var _Carousel = __webpack_require__(24);

var _Carousel2 = _interopRequireDefault(_Carousel);

var _Follow = __webpack_require__(25);

var _Follow2 = _interopRequireDefault(_Follow);

var _News = __webpack_require__(26);

var _News2 = _interopRequireDefault(_News);

var _BottomNav = __webpack_require__(23);

var _BottomNav2 = _interopRequireDefault(_BottomNav);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var slide = migi.render(migi.createVd("ul", [["class", "slide"]], [migi.createVd("li", [], [migi.createCp(_SearchNav2.default, []), migi.createCp(_Carousel2.default, []), migi.createCp(_Follow2.default, []), migi.createCp(_News2.default, [])]), migi.createVd("li", [], ["zhuanquan"]), migi.createVd("li", [], ["find"]), migi.createVd("li", [], ["my"])]), document.body);
var $slide = $(slide.element);
// migi.render(
//   <SearchNav/>,
//   document.body
// );
// migi.render(
//   <Carousel/>,
//   document.body
// );
{/*migi.render(*/}
{} /*<Follow/>,*/
//   document.body
// );
// migi.render(
//   <News/>,
//   document.body
// );
var bottomNav = migi.render(migi.createCp(_BottomNav2.default, []), document.body);
bottomNav.on('change', function (index) {
  $slide.removeClass('s1 s2 s3');
  $slide.addClass('s' + index);
});

/***/ })

/******/ });